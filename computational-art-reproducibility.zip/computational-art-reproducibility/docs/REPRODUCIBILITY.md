# Reproducibility scope and manuscript alignment

## Input identity

The record-level source is `Epistemic_distinctiveness_data_1427_K15_v2026-10-01.xlsx`, sheet `30_记录级主数据`. Every `doc_id` and topic label was compared, in order, against the recovered historical `Assignments.csv`. All 1,427 pairs matched. Checksums of both source material and packaged files are recorded. No K=13 or 1,429-record labels were substituted.

The supplied manuscript itself is identified by SHA-256 in `config/analysis.json`. File names do not establish model identity; the record-level comparison does.

## Coverage

| Manuscript component | Packaged support | What was verified now |
|---|---|---|
| Corpus totals and K=15 labels | `records.csv`, historical coordinates and provenance | All labels matched; KMeans rerun on original coordinates |
| Topic/axis shares, strict voids | Record-level labels; `reproduce.py` | Recomputed; two-sided Clopper–Pearson intervals |
| JSD, separation S, Fisher tests | Record-level labels and groups | Recomputed; JSD is squared Jensen–Shannon distance, base 2 |
| Journal tiers and shared journals | Derived tier evidence flags and opaque journal IDs | Recomputed; 137 core and 127 confirmed non-core records |
| Department strata and standardization | Frozen v3 department codes and rules | Recomputed; six-category and collapsed four-category results both reported |
| Subjectivity | Dictionary flags, English review labels, archived rules | 29 strict positives; 11 topics; 60 recorded author checks all agree |
| Dictionary validation | Historical summary of DEV/VAL sample | Summary retained; gold-standard record-level validation sample not revalidated |
| Within-English stratification | Department/topic labels and review outcome | MH estimates and separately seeded conditional randomization |
| Period comparisons | Frozen labels and year | Counts, point estimates, bootstrap and label tests recomputed |
| Cross-K sensitivity | Historical per-K group counts | JSD/S recomputed from archived counts; all 11 models not refitted |
| Ten-seed sensitivity | 14,270 cached record/seed assignments | Pairwise ARI and summary metrics recomputed; only seed 42 refit tested now |
| Translation designs | E1A/E1B cached assignments, recovered code | Metrics recomputed; translations and their encodings not regenerated |
| Concept anchors | Raw/postprocessed similarity matrices and original code | Matrices retained; original encoding and 5,000 anchor permutations not rerun now |
| Abstract-length sensitivity | Source-derived character/word lengths | Exact K=15 quartile specification and reported p=0.007 not established; earlier K=13 tests not substituted |
| Topic terms/coherence | Recovered term-generation and F1 scripts, historical tables | Retained; not recomputed without texts and the historical tokenization environment |
| Shared-object close reading | Manuscript reports 86 records | Exact original record list unavailable; no replacement list was fabricated |

## Upstream gaps

1. **Search history:** reported queries are recoverable from manuscript text, but platform-exported verbatim histories, execution timestamps and initial hit logs were not recovered. `docs/reported_queries.txt` is a transcription of the manuscript, not evidence of execution.
2. **Shared-object reading:** the original list of 35 ZH, 38 EN-CN and 13 EN-NC records was not recovered. A newly tuned regex list would be a different sample even if it totals 86. No synthetic sample is included.
3. **Dictionary scoring:** the bilingual regex codebook and frozen decisions are available. The original scoring program, weighting of title/abstract/keywords, and all DEV/VAL record-level adjudications were not recovered. Do not use a newly invented scoring function to claim exact replication.
4. **Frozen fitted model:** saved embeddings and UMAP coordinates exist, but the original frozen PCA/UMAP transform objects were not recovered. Saved v11 transforms belong to sensitivity refits. A perfect rerun of KMeans on saved coordinates does not resolve this upstream gap.
5. **Historical scripts:** recovered code depends on workbook sheets, private input paths, translation caches and historical environments. These scripts were preserved and syntax-checked, not executed as a complete pipeline. Only the `src/` entry points have the execution evidence described in the verification report.
6. **Embedding revision:** the weight revision recorded in the configuration belongs to v11. The historical frozen encoder revision and exact runtime truncation settings were not established by the recovered run records. The optional encoding utility uses the documented v11 revision and compares against the archived vectors.

## Manuscript statements needing correction or confirmation

### CLC definition

| Definition | J: value / total | TP: value / total |
|---|---|---|
| First CLC code | 176/391 = 45.0% | 162/378 = 42.9% |
| Any CLC code | 328/736 = 44.6% | 316/726 = 43.5% |

The manuscript uses the first row's percentages while describing overlapping categories. First-code J and TP subsets are mutually exclusive. The any-code categories overlap in 629 records. Choose the intended definition, align the Methods/Results/figure labels, and keep the alternative as a sensitivity analysis. The TP-without-J subset is 28/97 = 28.9%; it excludes J codes but can include other non-J codes. Calling this subset “only TP codes” is stronger than the actual implementation.

### Direct standardization

30.7% comes from pooling CS, BOTH and STEM into a four-category scheme (ART / TECHSIDE / HUM / UNKNOWN). Using all six categories gives 30.6%. Report the pooling explicitly. Neither estimate identifies the causal contribution of departments. Unknown groups are retained unless a separately documented sensitivity analysis removes them.

### K selection

The recovered original rebuild selects K by stability among heritage-separating candidates, with tie-breaking criteria. Historical F1 coherence and interpretability were assembled in later diagnostic stages. The manuscript's coherence-led selection narrative and the marked author-confirmation sentence should be reconciled with that chronology. No selection rule or parameter was changed to make the manuscript look more favorable.

### Topic descriptions

The recovered `terms()` function implements a custom weighting labeled `ctfidf_weight`; its IDF uses document-frequency values and a topic-dependent scaling expression. This is not automatically identical to BERTopic's `ClassTfidfTransformer`. Preserve the implementation and describe it accurately, or document a separate comparison before calling it standard c-TF-IDF. Do not silently replace the historical weights while retaining the old topic-term tables.

### Random intervals and p-values

The portable reconstruction uses aggregate multinomial bootstrapping and conditional hypergeometric randomization, equivalent in distribution to resampling/shuffling record labels under the stated margins. It uses a new explicit draw order. Consequently, Monte Carlo intervals and p-values are not promised to match historical output digit-for-digit. Topic-stratified subjectivity p-values are reported directly from the new run, not adjusted to the manuscript's rounded “approximately 0.03”. Cached historical values are retained separately.

### Manual validation and AI assistance

60 recorded author checks agree with the archived AI-assisted English decisions. This confirms agreement in the supplied records; it is not a new independent reading audit. The 60-author-check sample is distinct from the dictionary's 60-record held-out validation set. Do not combine these as one validation exercise.

## Runtime and publication boundaries

Local execution used the recovered Python 3.12 environment. A fresh dependency installation, Linux run and GitHub workflow execution were not performed. The pinned versions reflect that local evidence. A repository does not establish the study's novelty, journal fit or validity of unsupported claims, and does not guarantee journal acceptance.
