# 上传 GitHub 与获取 DOI

现在不需要先买服务或付费。当前文件夹已按仓库结构整理，尚未发生任何外部上传，也没有编造账号、网址或 DOI。

## 注册后上传

1. 在 GitHub 注册并验证邮箱，创建一个新仓库。可采用仓库名 `computational-art-reproducibility`，也可以另选名称。
2. 确认作者英文姓名、作者对公开代码与派生数据的同意，以及所选许可证。代码与数据可以使用不同许可证；本包未替作者授予许可。将 `CITATION.cff.template` 填好并改名为 `CITATION.cff`，再写入正式仓库地址和版本号。
3. 上传本文件夹内的文件和子目录，保持目录层级。上传的是解压后的仓库内容，而不是只把 ZIP 文件放在仓库首页。浏览器上传不方便时使用 GitHub Desktop。隐藏的 `.github`、`.gitignore`、`.gitattributes` 也应保留。
4. 在仓库页面核对 README、src、data、config、historical 和 docs 是否齐全。运行提供的验证流程，查看 Actions 是否成功；远程 Actions 尚未由本次任务验证。
5. 逐项处理 `docs/REPRODUCIBILITY.md` 的论文口径问题。当前版本可作为有明确范围说明的代码公开包；若要声称完整端到端复现，须先补齐上游缺口。

GitHub 操作官方说明：https://docs.github.com/en/repositories/creating-and-managing-repositories/creating-a-new-repository

上传现有项目官方说明：https://docs.github.com/en/get-started/start-your-journey/uploading-a-project-to-github

## 获取 DOI

1. 登录 Zenodo，连接 GitHub 并启用目标仓库。
2. 在 GitHub 创建实际的版本发布，例如完成核对后的 `v1.0.0`。不要把本地打包日期当成已经发布的版本日期。
3. 在 Zenodo 核对软件记录中的作者、标题、许可证及文件，再确认记录可访问。
4. 论文中引用该固定版本的 DOI；仓库地址用于查看代码，版本 DOI 用于定位此次归档的精确版本。补全 `CITATION.cff` 和 Code availability。

官方流程：https://help.zenodo.org/docs/github/archive-software/github-upload/

本次不替作者注册账号、选择作者身份或发布仓库。作者决定这些信息后，当前文件可直接用于下一步发布。

## 可用性声明

**尚未上传时：**不要把下面的现在时句子写成已经发生的事实。占位字段必须在真实发布后替换。

**实际公开后、范围与本包一致时：**

> Code availability. The analysis scripts, frozen topic assignments and derived analysis inputs are available at [GitHub repository URL]. The version accompanying this article is archived at [version-specific Zenodo DOI]. The repository documents the analyses that can be reproduced from the supplied inputs and the additional materials required for upstream reconstruction.

这段比原句 “in the same repository” 更适合当前情况：目前尚未建立一个可指称的既有数据仓库。若以后数据与代码确实同库，可再改为 “in the same repository”。

**Data availability 模板（须先确认真实公开位置与访问条件）：**

> Data availability. The derived analysis data and frozen topic assignments supporting the quantitative analyses are available at [repository DOI]. The original bibliographic records were retrieved from CNKI and the Web of Science Core Collection. The repository specifies which source fields are omitted and the access conditions applicable to obtaining the original records.

只有仓库实际写明原始数据访问方式及适用条件后才能使用最后一句；不能仅以 “available upon reasonable request” 掩盖缺失的输入。共享对象原清单尚未找回，因此不要声称所有对读清单均已公开。

Scientometrics 官方要求原创研究包含 Data Availability Statement，并说明支撑结果的数据如何获得。代码声明不能替代数据声明。来源：https://link.springer.com/journal/11192/submission-guidelines
