# Verification performed on 19 October 2026

- 30 Python source files parsed successfully; 25 are recovered historical scripts.
- Five independent boundary/count tests passed.
- Main statistics executed with 2,000 bootstraps, 5,000 distribution permutations and 10,000 stratified permutations.
- 55 point/count/seed/E1A reference comparisons passed at their stated tolerances.
- Historical KMeans on saved coordinates reproduced every frozen label (ARI=1.0).
- v11 seed-42 full-SVD/UMAP/KMeans rerun matched the archived v11 partition (ARI=1.0), while ARI against frozen manuscript labels is 0.8565905488. These are different models by design.
- Original raw vector row mapping was checked byte-for-byte against the old vector array indexed by the retained mapping.
- Source-path and common credential-pattern scans found no hits; titles, abstracts, author names and addresses were not exported as record columns.

See `verification_summary.json` and `run_metadata.json`. CSVs in this folder are newly calculated verification outputs; `data/reference/` files are historical outputs. Monte Carlo intervals are from the new explicit draw order. No fresh dependency installation, remote workflow, original encoder run or new human coding audit is claimed.
