# Data dictionary and access

`data/derived/records.csv` contains one row per included paper. It intentionally omits text, paper titles, author names, addresses, DOI and WoS UT values. `doc_id` is the original corpus-local identifier and preserves linkage across supplied files. It is not a persistent bibliographic identifier; independent source retrieval needs a separately authorized record-ID crosswalk or the original source exports.

| Column(s) | Meaning |
|---|---|
| `doc_id` | Frozen CNKI_#### / WOS_#### record identifier |
| `source`, `group` | Database and operational group. ZH denotes CNKI records, including the two English records described in the manuscript; it is not a culture label |
| `year` | Recorded publication year. The claimed day-level cutoff cannot be rechecked from this column alone |
| `topic`, `axis` | Frozen K=15 label and main axis, never re-estimated by the statistics entry point |
| `en_cn_strict` | 1 for EN-CN records retained after the recorded Hong Kong/Macau sensitivity exclusion; otherwise 0 |
| `journal_id` | Deterministic local opaque journal identifier for shared-journal comparisons |
| `dept_v3`, `dept_coding_level` | Archived six-category department code and level of evidence. `UNKNOWN` is a retained category |
| `country_group` | Archived first-author-region proxy. Empty for ZH; not nationality or cultural training |
| `clc_first_J`, `clc_first_TP` | Whether the first semicolon-delimited CLC code begins with J or TP |
| `clc_any_J`, `clc_any_TP` | Whether any CLC code begins with J or TP; overlapping subsets |
| `clc_TP_without_J` | Has a TP code and no J code; other non-J classifications may occur |
| `q2_dictionary`, `q8_dictionary` | Frozen dictionary decisions, not re-scored from text |
| `q2_verified_en` | English decision: `1` strict positive, `B` framing only, `0` negative; empty for ZH |
| `author_spotcheck` | Recorded author decision for the designated 60 English records; empty means not in that check |
| `abstract_chars`, `abstract_words` | Recomputed Python character count / whitespace-token count of source abstract; do not interpret these as a common cross-language length scale |
| `journal_tier_status` | Original journal status 是 / 否 / 待核 from the frozen historical tier payload; empty outside CNKI |
| `journal_tier_evidence_complete` | Historical evidence URL/list/matched-string fields all nonempty |
| `journal_tier_match_method` | Historical evidence matching rule, used to distinguish confirmed non-core from pending |

The tier payload `task5_analysis_payload.json` is the evidence source used by the original phase_bc script. It is distinct from a nearby workbook with a similar filename. The selected numeric variables reproduce the reported 137/127 tier denominators.

Other derived files contain frozen topic labels, documented regular expressions, coding rules, and seed/translation assignments. E1A is a supervised classification comparison in the embedding space; E1B is a paired refit comparison. Neither is the historical frozen UMAP projection.

The `.npy` model inputs are numerical arrays, loaded with `allow_pickle=False`: `e5_embeddings.npy` and `historical_postprocessed.npy` have shape (1427,1024), and `historical_umap_10d.npy` has shape (1427,10). All rows follow `records.csv`. They are analysis inputs, not pretrained model weights. The v11 E5 model revision is recorded in the configuration; the original frozen encoder revision was not established.

## Availability classification

| Material | Route in this release |
|---|---|
| Analysis code, derived variables, numerical arrays and summary tables | Prepared locally for an intended public GitHub release; not yet published |
| Original CNKI/WoS exports and full abstracts | Not included; authors must verify their institutional access terms and permitted redistribution scope |
| Public paper identifiers and source crosswalk | Not included in this code-only package; prepare a permitted metadata deposit if needed for source-level audit |
| Search histories and original shared-object list | Unrecovered; no availability promise made |
| Pretrained E5 weights | External model repository, referenced by model ID and revision |

No claim is made that every CNKI/WoS field is legally prohibited from sharing. The applicable access and reuse terms must be established before depositing those fields. A code license must not be applied automatically to third-party data. Authors have not yet selected a code/data license.
