# Licensing status

No open-source or open-data license has yet been selected by the authors. This local package does not grant a new license or assert ownership over third-party material.

Before a public release, confirm the rights to the recovered code and the intended license. Add the selected license text and identifier only after that decision. The pretrained embedding model and original CNKI/WoS material retain their own terms. Do not apply a code license to them by implication.
