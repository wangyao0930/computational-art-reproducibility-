# Recovered historical source; run only from historical/ after supplying documented inputs.
"""Translate CNKI records with the verified local Marian zh-en model."""
from __future__ import annotations
import json
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from sentence_transformers import SentenceTransformer
from transformers import MarianMTModel, MarianTokenizer
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.metrics import adjusted_rand_score
from sklearn.preprocessing import normalize
from umap import UMAP

ROOT = Path(__file__).resolve().parent.parent
RUN = ROOT / "work" / "joint_k12_revision_20260821"
MODEL_DIR = Path('./private_inputs/opus-mt-zh-en')
E5_DIR = Path('./private_inputs/model')
OUT = RUN / "translation_robustness"
OUT.mkdir(parents=True, exist_ok=True)
K = 12
SEED = 42
MAX_INPUT = 384


def translate_texts(texts: list[str]) -> list[str]:
    tokenizer = MarianTokenizer.from_pretrained(str(MODEL_DIR), local_files_only=True)
    model = MarianMTModel.from_pretrained(str(MODEL_DIR), local_files_only=True).eval()
    out = []
    torch.set_num_threads(max(1, min(12, torch.get_num_threads())))
    with torch.inference_mode():
        for start in range(0, len(texts), 24):
            batch = texts[start:start + 24]
            enc = tokenizer(batch, return_tensors="pt", padding=True, truncation=True, max_length=MAX_INPUT)
            generated = model.generate(**enc, max_new_tokens=192, num_beams=1, do_sample=False)
            out.extend(tokenizer.batch_decode(generated, skip_special_tokens=True))
            if (start // 24) % 5 == 0: print(f"translated {min(start + len(batch), len(texts))}/{len(texts)}", flush=True)
    return out


def postprocess(raw: np.ndarray) -> np.ndarray:
    centered = raw - raw.mean(axis=0, keepdims=True)
    pca = PCA(n_components=3, random_state=SEED).fit(centered)
    x = centered - (centered @ pca.components_.T) @ pca.components_
    return normalize(x).astype("float32")


def main():
    d = pd.read_csv(RUN / "document_topic_assignments_k12.csv", keep_default_na=False, encoding="utf-8-sig")
    cn_mask = d.source.eq("CNKI")
    cn = d.loc[cn_mask].copy()
    originals = [f"{r.title}. {r.abstract}" for r in cn.itertuples()]
    translated = translate_texts(originals)
    if len(translated) != len(cn) or any(not str(x).strip() for x in translated): raise RuntimeError("Translation output incomplete")
    cn["translated_title_abstract_en"] = translated
    cn["translated_model_text"] = cn.translated_title_abstract_en.map(lambda x: f"passage: {x}")
    translated_map = cn.set_index("doc_id")["translated_title_abstract_en"].to_dict()
    d["translated_title_abstract_en"] = d.doc_id.map(translated_map).fillna("")
    d["translated_model_text"] = d.doc_id.map(cn.set_index("doc_id").translated_model_text.to_dict()).fillna(d.model_text)
    d.to_csv(OUT / "document_assignments_with_translated_text.csv", index=False, encoding="utf-8-sig")
    raw = np.load(RUN.parent / "joint_full_rebuild_20260821" / "embeddings_multilingual_e5_large_raw.npy")
    encoder = SentenceTransformer(str(E5_DIR), local_files_only=True, device="cpu")
    docs = d.translated_model_text.tolist()
    embeddings = encoder.encode(docs, batch_size=16, normalize_embeddings=False, show_progress_bar=True, convert_to_numpy=True).astype("float32")
    np.save(OUT / "embeddings_english_single_language_raw.npy", embeddings)
    emb = postprocess(embeddings)
    np.save(OUT / "embeddings_english_single_language_allbuttop3.npy", emb)
    umap = UMAP(n_neighbors=100, n_components=10, min_dist=0.0, metric="cosine", random_state=SEED, low_memory=True)
    reduced = umap.fit_transform(emb)
    np.save(OUT / "umap_english_single_language_10d.npy", reduced.astype("float32"))
    model = KMeans(n_clusters=K, random_state=SEED, n_init=30)
    translated_topics = model.fit_predict(reduced)
    d["translated_topic"] = translated_topics
    d.to_csv(OUT / "document_assignments_with_translated_topics.csv", index=False, encoding="utf-8-sig")
    ari = adjusted_rand_score(d.topic, translated_topics)
    mixed_rows = []
    for topic in range(K):
        q = d[translated_topics == topic]
        source_shares = q.source.value_counts(normalize=True)
        minority = float(source_shares.min()) if len(source_shares) > 1 else 0.0
        mixed_rows.append({"translated_topic": topic, "n": len(q), "cnki_n": int((q.source == "CNKI").sum()), "wos_n": int((q.source == "WoS").sum()), "minority_source_share": minority, "mixed_ge_10pct": minority >= 0.10})
    mixed = pd.DataFrame(mixed_rows)
    mixed.to_csv(OUT / "translated_topic_source_composition.csv", index=False, encoding="utf-8-sig")
    minority_share = float(sum(min(int(r.cnki_n), int(r.wos_n)) for r in mixed.itertuples()) / len(d))
    primary = pd.read_csv(RUN / "document_topic_assignments_k12.csv", keep_default_na=False, encoding="utf-8-sig")
    primary_topic_minority = primary.groupby("topic").source.apply(lambda x: min((x == "CNKI").sum(), (x == "WoS").sum()))
    summary = pd.DataFrame([
        {"analysis": "primary multilingual K12", "ARI_vs_primary": 1.0, "mixed_topic_count_ge_10pct": int(primary.groupby("topic").source.apply(lambda x: min((x == "CNKI").sum(), (x == "WoS").sum()) / len(x) if len(x) else 0).ge(.10).sum()), "full_sample_minority_source_share": float(primary_topic_minority.sum() / len(primary))},
        {"analysis": "English-only translated robustness", "ARI_vs_primary": float(ari), "mixed_topic_count_ge_10pct": int(mixed.mixed_ge_10pct.sum()), "full_sample_minority_source_share": minority_share},
    ])
    summary.to_csv(OUT / "translation_robustness_summary.csv", index=False, encoding="utf-8-sig")
    # Optimal topic matching based on document overlap.
    overlap = np.zeros((K, K))
    for a in range(K):
        for b in range(K): overlap[a, b] = np.sum((d.topic == a) & (translated_topics == b))
    from scipy.optimize import linear_sum_assignment
    rows, cols = linear_sum_assignment(-overlap)
    match = pd.DataFrame([{"primary_topic": int(a), "translated_topic": int(b), "overlap_n": int(overlap[a, b]), "primary_n": int((d.topic == a).sum()), "translated_n": int((translated_topics == b).sum()), "overlap_share_primary": float(overlap[a, b] / max(1, (d.topic == a).sum())), "overlap_share_translated": float(overlap[a, b] / max(1, (translated_topics == b).sum()))} for a, b in zip(rows, cols)])
    match.to_csv(OUT / "translation_topic_hungarian_match.csv", index=False, encoding="utf-8-sig")
    meta = {"translation_model": str(MODEL_DIR), "embedding_model": str(E5_DIR), "n_cnki_translated": len(cn), "n_total_reembedded": len(d), "k": K, "postprocessing": "global centering, remove top 3 PCs, L2 normalization", "umap": "n_neighbors=100, n_components=10, min_dist=0, cosine", "kmeans": "n_clusters=12, n_init=30, random_state=42"}
    (OUT / "translation_robustness_metadata.json").write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"ari": float(ari), "mixed_topics": int(mixed.mixed_ge_10pct.sum()), "minority_share": minority_share}, ensure_ascii=False))


if __name__ == "__main__": main()
