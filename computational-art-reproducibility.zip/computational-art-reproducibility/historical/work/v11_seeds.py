# Recovered historical source; run only from historical/ after supplying documented inputs.
import os
os.environ.setdefault('OMP_NUM_THREADS','4')
os.environ.setdefault('MKL_NUM_THREADS','4')
from v11_common import *
from importlib.metadata import version
import subprocess
from threadpoolctl import threadpool_limits

def main():
    d,f=load()
    raw=np.load(ROOT/'work/new_inputs/embeddings_1427.npy')
    x,mean,pcs=post_fit(raw)
    for name,a in [('pp_mean',mean),('pp_pcs',pcs),('pp_original',x)]:np.save(ART/f'{name}.npy',a)
    saved=np.load(FINAL/'embeddings_postprocessed_allbuttop3.npy')
    save('PP_Check',[dict(n=1427,dimensions=1024,raw_norm_min=float(np.linalg.norm(raw,axis=1).min()),raw_norm_max=float(np.linalg.norm(raw,axis=1).max()),SVD_dtype=str(x.dtype),max_absolute_difference=float(np.max(np.abs(x-saved))),mean_absolute_difference=float(np.mean(np.abs(x-saved))),row_cosine_min=float(np.min(np.sum(x*saved,1)/np.linalg.norm(saved,axis=1))),method='float64 centered full SVD, subtract first 3 directions, row L2; historical PCA auto solver differs')])
    rows=[dict(component='Python',version=sys.version)]
    for pkg in ['umap-learn','numba','scikit-learn','numpy','sentence-transformers','torch','scipy','pandas','transformers','jieba']:
        rows.append(dict(component=pkg,version=version(pkg)))
    for key in ['NUMBA_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','PYTHONHASHSEED']:rows.append(dict(component=key,version=os.environ.get(key,'unset')))
    meta=ROOT/'work/models/multilingual-e5-large/.cache/huggingface/download/model.safetensors.metadata'
    if meta.exists(): rows.append(dict(component='E5 local weight revision',version=meta.read_text().splitlines()[0]))
    save('Env_Versions',rows)
    freeze=subprocess.run([sys.executable,'-m','pip','freeze'],capture_output=True,text=True,check=True).stdout
    (ART/'pip_freeze.txt').write_text(freeze,encoding='utf-8')
    mrows=[]; assign=[]; maps=[]; comps=[]; labels_by_seed={}
    for seed in SEEDS:
        path=ART/f'E5_original_seed{seed}_labels.npy'
        lab=np.load(path) if path.exists() else fit_cluster(x,seed,'E5_original')[0]
        labels_by_seed[seed]=lab
        aligned,mapping=align(f,lab)
        maps.extend(dict(seed=seed,**r) for r in mapping)
        cs=comparisons(d,f,lab,aligned); comps.extend(dict(seed=seed,**r) for r in cs)
        vals=metrics(d,lab,aligned)
        for c in cs:
            for key in ['raw_agreement','aligned_agreement','ARI','NMI']:vals[f'{key}_{c["subset"]}']=c[key]
        mrows.append(dict(seed=seed,**vals))
        assign.extend(dict(doc_id=doc,seed=seed,cluster=int(l),mapped_topic=f'T{a:02d}',frozen_topic=f'T{o:02d}') for doc,l,a,o in zip(d.doc_id,lab,aligned,f))
        save('Seed_Metrics',mrows); save('Seed_Assignments',assign); save('Seed_Mapping',maps); save('Seed_Alignment',comps)
        print(f'Seed {seed}: ARI={cs[0]["ARI"]:.6f} aligned={cs[0]["aligned_agreement"]:.6f} S={vals["S_ZH_vs_EN"]:.6f}',flush=True)
    frozen=metrics(d,f,f); frozen.update({f'{key}_{g}':1. for key in ['raw_agreement','aligned_agreement','ARI','NMI'] for g in ['ALL','ZH','EN']})
    mt=pd.DataFrame(mrows); summary=[]
    for key,ref in frozen.items():
        v=mt[key].to_numpy()
        if key=='D':rule='sign relative to zero'; n=int((np.sign(v)==np.sign(ref)).sum())
        elif key.endswith('_OR'):rule='OR relative to 1';n=int((np.sign(v-1)==np.sign(ref-1)).sum())
        elif key.endswith('_share'):
            axis,g=key.rsplit('_',1)[0].split('_',1)
            other='EN' if g=='ZH' else 'ZH'
            otherkey=f'{axis}_{other}_share'
            if otherkey in mt:rule=f'{g} minus {other}';n=int((np.sign(v-mt[otherkey])==np.sign(ref-frozen[otherkey])).sum())
            else:rule='not directional';n=None
        elif key.startswith(('S_','JSD_')):rule='greater than zero';n=int((v>0).sum())
        else:rule='not directional; range only';n=None
        summary.append(dict(metric=key,frozen_value=ref,minimum=float(np.min(v)),median=float(np.median(v)),maximum=float(np.max(v)),direction_consistent_seeds=n,direction_rule=rule,seeds_n=10))
    save('Seed_Summary',summary)
    pairrows=[]
    for i,s1 in enumerate(SEEDS):
        for s2 in SEEDS[i+1:]:pairrows.append(dict(seed_a=s1,seed_b=s2,ARI=float(adjusted_rand_score(labels_by_seed[s1],labels_by_seed[s2]))))
    save('Seed_Pairwise_ARI',pairrows)
    repeat,_=fit_cluster(x,42,'E5_repeat')
    ari=adjusted_rand_score(labels_by_seed[42],repeat)
    save('Reproducibility_Check',[dict(setting='current environment',seed=42,ARI=float(ari),exact_label_match=bool(np.array_equal(labels_by_seed[42],repeat)),status='PASS' if ari==1 else 'CHECK')])
    manifest()
    status('Task9','PASS' if ari==1 else 'CHECK',f'Same-seed ARI={ari}; full SVD parameters and 10 UMAP/centroid sets saved. Frozen labels unchanged. Full-SVD vs saved vectors maximum absolute difference={np.max(np.abs(x-saved)):.9g}.')
    assert all(0<=r[k]<=1 for r in mrows for k in r if k.startswith('rho_'))
    assert all(r[k]<=1 for r in mrows for k in r if k.startswith('S_'))
    status('Task8','PASS',f'10/10 seeds; seed42 ARI={mrows[0]["ARI_ALL"]:.9f}; all labels Hungarian aligned on all 1427 records.')

if __name__=='__main__':
    with threadpool_limits(limits=4):guarded('Task8_9',main)
