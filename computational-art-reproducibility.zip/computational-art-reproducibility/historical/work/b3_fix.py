# Recovered historical source; run only from historical/ after supplying documented inputs.
# -*- coding: utf-8 -*-
import pandas as pd, numpy as np, re, os, json
from pathlib import Path
ROOT=Path('.')
OUT=ROOT/'outputs'/'rerun_1427_k15'
OUT.mkdir(parents=True,exist_ok=True)
MASTER=ROOT/'output/final_rebuild_20260927_1427/computational_art_final_rebuild_1427.xlsx'
WOS=Path('./private_inputs/WoS_computational_art_final_merged.xlsx')
CNKI=Path('./private_inputs/CNKI_computational_art_unit_complete.xlsx')
BASE=Path('./private_inputs/Epistemic_distinctiveness_data_1427_K15_v2026-09-28.xlsx')
def clean(df):
 df=df.copy(); df.columns=df.columns.astype(str).str.replace('\ufeff','',regex=False); return df
def s(x): return '' if pd.isna(x) else str(x).strip()
def norm(x): return re.sub(r'\s+','',s(x))
ART_PAT=re.compile(r'art|arts|design|music|theat|cinema|film|fine|visual|creative|media art|architecture|architectural|艺术|设计|音乐|戏剧|电影|美术|视觉|传媒|动画|影视',re.I)
CS_PAT=re.compile(r'comp|comput|informat|information|software|automat|elect|electr|engin|technology|technol|ai|artificial intelligence|数学|计算机|信息|软件|自动化|电子|电气|工程|科技|人工智能|数媒|数字媒体',re.I)
ART_INST_PAT=re.compile(r'art college|college of arts|academy of art|academy of fine arts|school of art|university of the arts|conservatory|film academy|cinema academy|music academy|艺术学院|美术学院|音乐学院|戏剧学院|电影学院|传媒大学|艺术大学',re.I)
def classify(raw,source):
 raw=s(raw)
 if not raw: return ('UNKNOWN','empty institution/dept')
 # split first author address; preserve all text for Chinese semicolon lists
 segs=[z.strip() for z in re.split(r';|；',raw) if z.strip()]
 first=segs[0] if segs else raw
 # bracket-author prefix removed from English for matching
 first2=re.sub(r'^\[[^\]]*\]\s*','',first)
 # detect department-like components
 parts=[z.strip() for z in re.split(r',|，|;|；',first2) if z.strip()]
 dept_parts=[z for z in parts if re.search(r'\b(sch|school|dept|department|fac|faculty|coll|college|inst|institute|academy|lab|center|centre|研究院|学院|系|所|中心|部)\b',z,re.I)]
 dept='; '.join(dept_parts)
 has_dept=bool(dept_parts)
 txt=(dept if has_dept else first2)
 art=bool(ART_PAT.search(txt)); cs=bool(CS_PAT.search(txt))
 if not has_dept:
  # Institution-only: only dedicated arts institutions may be ART; otherwise UNKNOWN
  if ART_INST_PAT.search(first2): return ('ART','institution-only dedicated arts institution')
  return ('UNKNOWN','institution-only or no department; no dedicated arts institution signal')
 if art and cs: return ('BOTH','department contains art/design and computing/engineering signals')
 if art: return ('ART','department/art-design signal')
 if cs: return ('CS','computing/engineering signal')
 return ('UNKNOWN','department present but no ART/CS trigger')
# read
master=clean(pd.read_excel(MASTER,sheet_name='Corpus_Master'))
wos=clean(pd.read_excel(WOS,sheet_name='WoS_Included_Final'))
cn=clean(pd.read_excel(CNKI,sheet_name='Final_Corpus'))
ref=clean(pd.read_excel(BASE,sheet_name='17b_院系编码审计'))
# source maps
wos_map={s(r.get('UT (Unique WOS ID)')):r for _,r in wos.iterrows()}
cn_map={norm(r.get('Title-题名')):r for _,r in cn.iterrows()}
ref_map={s(r.get('doc_id')):r for _,r in ref.iterrows()}
rows=[]
for _,m in master.iterrows():
 doc=s(m.get('doc_id')); source=s(m.get('source')); raw=s(m.get('institution_or_address'));
 if source=='WoS':
  src=wos_map.get(s(m.get('source_record_id')),{}); raw=s(src.get('Addresses')) or raw
 else:
  src=cn_map.get(norm(m.get('title')),{}); raw=s(src.get('Organ-单位')) or raw
 v2,reason=classify(raw,source)
 old=ref_map.get(doc,{}); oldv=s(old.get('dept_fixed'))
 rows.append({'doc_id':doc,'group':s(m.get('analysis_group')),'source':source,'title':s(m.get('title')),'raw_institution':raw,'department_name_extracted':reason if False else '', 'dept_type_v2':v2,'trigger_rule':reason,'old_dept_fixed':oldv,'topic_code':s(m.get('topic_code')),'axis_main':('VALUE' if s(m.get('topic_code')) in {'T00','T03','T13'} else 'TECH' if s(m.get('topic_code')) in {'T02','T05','T08','T12'} else 'MIXED'),'year':m.get('year'),'journal':s(m.get('journal')),'clc_raw':s(m.get('clc_raw'))})
out=pd.DataFrame(rows)
# extract department separately for audit readability
def extract_dept(raw):
 raw=s(raw); seg=raw.split(';')[0].strip() if raw else '' ; seg=re.sub(r'^\[[^\]]*\]\s*','',seg); parts=[z.strip() for z in re.split(r',|，|;|；',seg) if z.strip()]; ds=[z for z in parts if re.search(r'\b(sch|school|dept|department|fac|faculty|coll|college|inst|institute|academy|lab|center|centre|研究院|学院|系|所|中心|部)\b',z,re.I)]; return '; '.join(ds)
out['department_name_extracted']=out['raw_institution'].map(extract_dept)
out['difference_flag']=np.where((out['old_dept_fixed']!='')&(out['old_dept_fixed']!=out['dept_type_v2']),'DIFF','SAME_OR_NO_REFERENCE')
out.to_csv(OUT/'B3_Dept_Doc_Level.csv',index=False,encoding='utf-8-sig')
out[out['difference_flag']=='DIFF'].to_csv(OUT/'B3_Dept_Differences.csv',index=False,encoding='utf-8-sig')
# axis summary and composition
comp=out.groupby(['group','dept_type_v2'],dropna=False).size().reset_index(name='n')
den=out.groupby('group').size().rename('group_n').reset_index(); comp=comp.merge(den,on='group'); comp['share']=comp['n']/comp['group_n']
comp.to_csv(OUT/'B3_Dept_Composition_v2.csv',index=False,encoding='utf-8-sig')
axis=out.groupby(['group','axis_main']).size().reset_index(name='all_n')
art=out[out.dept_type_v2=='ART'].groupby(['group','axis_main']).size().reset_index(name='ART_n')
axis=axis.merge(art,on=['group','axis_main'],how='left').fillna({'ART_n':0}); axis['ART_share_of_group']=axis['ART_n']/axis['all_n']; axis.to_csv(OUT/'B3_Dept_Axis_v2.csv',index=False,encoding='utf-8-sig')
artprof=out[out.dept_type_v2=='ART'].groupby(['group','axis_main']).size().unstack(fill_value=0).reset_index(); artprof.to_csv(OUT/'B3_ART_Subset_v2.csv',index=False,encoding='utf-8-sig')
# target checks old requested values
checks=[]
for g in ['EN-CN','EN-NC']:
 for t in ['ART','CS','BOTH','UNKNOWN']:
  checks.append({'group':g,'dept_type_v2':t,'n_v2':int(((out.group==g)&(out.dept_type_v2==t)).sum()),'n_old_17b':int(((ref.analysis_group==g)&(ref.dept_fixed==t)).sum())})
pd.DataFrame(checks).to_csv(OUT/'B3_ART_Target_Check.csv',index=False,encoding='utf-8-sig')
# CN 30 spotcheck
rng=np.random.RandomState(42); zh=out[out.group=='ZH'].sample(n=min(30,(out.group=='ZH').sum()),random_state=rng); zh.to_csv(OUT/'B3_CN_Spotcheck_30.csv',index=False,encoding='utf-8-sig')
summary={'n_total':len(out),'group_counts':out.group.value_counts().to_dict(),'v2_counts':out.dept_type_v2.value_counts().to_dict(),'diff_n':int((out.difference_flag=='DIFF').sum()),'cn_spot_n':len(zh)}
(OUT/'b3_fix_payload.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False))
