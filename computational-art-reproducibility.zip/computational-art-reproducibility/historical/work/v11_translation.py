# Recovered historical source; run only from historical/ after supplying documented inputs.
import os
os.environ.setdefault('OMP_NUM_THREADS','4')
from v11_common import *
from threadpoolctl import threadpool_limits
from scipy.special import xlogy

TRANSDIR=ROOT/'work/joint_k12_revision_20260821/translation_robustness'
AUTHOR_OLD=Path('./private_inputs/Epistemic_distinctiveness_data_1427_K15_v2026-09-28.xlsx')

def encode(model,texts,name):
    path=ART/f'{name}.npy'
    sig=hashlib.sha256(json.dumps(texts,ensure_ascii=False).encode()).hexdigest()
    meta=ART/f'{name}.json'
    if path.exists() and meta.exists() and json.loads(meta.read_text())['text_sha256']==sig:return np.load(path)
    out=[]
    for start in range(0,len(texts),32):
        out.extend(model.encode(texts[start:start+32],batch_size=8,normalize_embeddings=True,show_progress_bar=False))
        print(f'{name}: {min(start+32,len(texts))}/{len(texts)}',flush=True)
    arr=np.asarray(out,dtype=np.float32);np.save(path,arr)
    meta.write_text(json.dumps(dict(text_sha256=sig,max_seq_length=model.max_seq_length,normalize_embeddings=True,model='intfloat/multilingual-e5-large')),encoding='utf-8')
    return arr

def knn(train,labels,queries,self_indices=None):
    sim=queries@train.T
    if self_indices is not None:sim[np.arange(len(queries)),self_indices]=-np.inf
    order=np.argsort(-sim,axis=1,kind='stable')[:,:15]
    pred=[]
    for r,idx in enumerate(order):
        counts=np.bincount(labels[idx],minlength=15)
        cands=np.flatnonzero(counts==counts.max())
        # Remaining exact ties deterministically choose the smallest frozen topic code.
        pred.append(max(cands,key=lambda c:(float(sim[r,idx[labels[idx]==c]].sum()),-int(c))))
    return np.asarray(pred)

def bootsep(a,b,reps=2000):
    rng=np.random.default_rng(42)
    aa=rng.multinomial(len(a),np.bincount(a,minlength=15)/len(a),size=reps)
    bb=rng.multinomial(len(b),np.bincount(b,minlength=15)/len(b),size=reps)
    rho=np.minimum(aa,bb).sum(1)/(len(a)+len(b));rand=min(len(a),len(b))/(len(a)+len(b))
    pa=aa/len(a);pb=bb/len(b);mm=(pa+pb)/2
    div=np.divide(pa,mm,out=np.zeros_like(pa),where=mm>0)
    div2=np.divide(pb,mm,out=np.zeros_like(pb),where=mm>0)
    js=(xlogy(pa,div).sum(1)+xlogy(pb,div2).sum(1))/(2*np.log(2))
    out={}
    for key,arr in [('rho',rho),('S',1-rho/rand),('JSD',js)]:out[key+'_low'],out[key+'_high']=map(float,np.quantile(arr,[.025,.975]))
    return out

def main():
    import torch
    from sentence_transformers import SentenceTransformer
    torch.set_num_threads(4)
    d,f=load();zh=mask(d,'ZH');raw=np.load(ROOT/'work/new_inputs/embeddings_1427.npy')
    model=SentenceTransformer(str(ROOT/'work/models/multilingual-e5-large'),local_files_only=True,device='cpu')
    # Local E5 includes a Normalize module. Preserve the model's saved max length 512.
    orig=encode(model,d.loc[zh,'model_text'].tolist(),'E1_zh_original_reencoded')
    cosine=np.sum(orig*raw[zh],1)/(np.linalg.norm(orig,axis=1)*np.linalg.norm(raw[zh],axis=1))
    passed=float(np.mean(cosine>=.999))>=.99
    save('E1_Embed_Check',[dict(n=896,median_cosine=float(np.median(cosine)),p01_cosine=float(np.quantile(cosine,.01)),fraction_ge_0999=float(np.mean(cosine>=.999)),status='PASS' if passed else 'CHECK',max_seq_length=model.max_seq_length,raw_norm_median=float(np.median(np.linalg.norm(raw,axis=1))))])
    save('E1_Embed_Doc',pd.DataFrame(dict(doc_id=d.loc[zh,'doc_id'],cosine=cosine,pass_ge0999=cosine>=.999)))
    if not passed:
        raw=encode(model,d.model_text.tolist(),'E1_all_original_reencoded')
        base,mean,pcs=post_fit(raw)
        status('E1_Embedding','CHECK','Below 99% gate; all original and translated vectors regenerated in this environment.')
    else:
        base=np.load(ART/'pp_original.npy');mean=np.load(ART/'pp_mean.npy');pcs=np.load(ART/'pp_pcs.npy')
    t=pd.read_csv(TRANSDIR/'document_assignments_with_translated_text.csv',keep_default_na=False)
    t=t[t.source.eq('CNKI')].copy();assert t.title.is_unique
    t=t.set_index('title').loc[d.loc[zh,'title']].reset_index()
    texts=t.translated_model_text.tolist()
    assert len(texts)==896 and all(str(s).startswith('passage: ') for s in texts)
    trans=encode(model,texts,'E1_zh_translated_reencoded')
    del model
    trans_post=post_transform(trans,mean,pcs)
    words=t.translated_title_abstract_en.str.split().str.len()
    audit=pd.DataFrame(dict(doc_id=d.loc[zh,'doc_id'].to_numpy(),legacy_doc_id=t.doc_id,word_count=words,under_30_words=words<30,translated_model_text=texts,source_title=t.title))
    save('E1_Translation_Audit',audit)
    save('E1_Translation_Method',[dict(engine='local Marian opus-mt-zh-en legacy cache',translation_input='title + . + abstract; jointly translated; separate translated title/abstract unavailable',source_max_tokens=384,translation_max_new_tokens=192,matched_title_n=896,empty_translations=0,short_under30_n=int((words<30).sum()),embedding_max_tokens=512,limitation='Source and output token caps can truncate content; this is a cached joint title/abstract translation, not independently separated translated fields.')])
    # The current 09-30b file is absent. Verify older topic-table counts against frozen
    # assignments before using only its unchanged dominant_side/void definitions.
    auth=pd.read_excel(AUTHOR_OLD,sheet_name='05_主题表K15')
    assert dict(zip(auth.topic,auth.n))==d.topic_code.value_counts().to_dict()
    assert dict(zip(auth.topic,auth.ZH_n))==d.loc[zh,'topic_code'].value_counts().reindex([f'T{i:02d}' for i in range(15)],fill_value=0).to_dict()
    dominant=dict(zip(auth.topic,auth.dominant_side))
    save('E1_Definition_Source',[dict(source=str(AUTHOR_OLD),sheet='05_主题表K15',frozen_counts_verified=True,norm='strict void: two-sided CP upper<threshold; near: point share<threshold and not strict',status='CHECK',note='09-30b absent. 09-28 dominant-side definition verified against every frozen topic source count; no department coding substituted.')])
    centers=np.stack([base[f==i].mean(0) for i in range(15)]);centers/=np.linalg.norm(centers,axis=1,keepdims=True)
    np.save(ART/'E1A_frozen_label_centroids.npy',centers)
    preds={'centroid':((base[zh]@centers.T).argmax(1),(trans_post@centers.T).argmax(1)),
           'knn15':(knn(base,f,base[zh],np.flatnonzero(zh)),knn(base,f,trans_post))}
    fidelity=[];docs=[];transitions=[];metricrows=[];voids=[];migration=[]
    for classifier,(original,translated) in preds.items():
        agree=float(np.mean(original==f[zh]));ari=float(adjusted_rand_score(original,f[zh]))
        fidelity.append(dict(classifier=classifier,n=896,agreement=agree,ARI=ari,status='PASS' if agree>=.8 else 'CHECK',label_alignment='not applicable: supervised classifiers trained on frozen topic codes'))
        docs.extend(dict(classifier=classifier,doc_id=doc,frozen_topic=f'T{old:02d}',original_label=f'T{o:02d}',translated_label=f'T{tr:02d}',under_30_words=bool(short)) for doc,old,o,tr,short in zip(d.loc[zh,'doc_id'],f[zh],original,translated,words<30))
        cm=np.zeros((15,15),int);np.add.at(cm,(original,translated),1)
        transitions.extend(dict(classifier=classifier,original_topic=f'T{i:02d}',**{f'T{j:02d}':int(cm[i,j]) for j in range(15)}) for i in range(15))
        fromzh=np.array([dominant[f'T{x:02d}']=='ZH' for x in original]);toen=np.array([dominant[f'T{x:02d}']=='EN' for x in translated]);n=int((fromzh&toen).sum())
        migration.append(dict(classifier=classifier,ZH_to_EN_n=n,original_ZH_dominant_n=int(fromzh.sum()),fraction_of_original_ZH_dominant=n/fromzh.sum(),fraction_of_all_896=n/896))
        rlist=[]
        for variant,lab in [('frozen',f[zh]),('original_classifier',original),('translated_classifier',translated)]:
            all_lab=f.copy();all_lab[zh]=lab
            for a,b in PAIRS[:3]:
                aa=all_lab[mask(d,a)];bb=all_lab[mask(d,b)]
                r=dict(classifier=classifier,variant=variant,source_pair=f'{a} vs {b}',**sep(aa,bb),**bootsep(aa,bb),bootstrap_n=2000,seed=42)
                for axis,topics in [('VALUE',VALUE),('TECH',TECH)]:
                    n=int(np.isin(lab,topics).sum());lo,hi=cp(n,896)
                    r.update({f'ZH_{axis}_n':n,f'ZH_{axis}_share':n/896,f'ZH_{axis}_CI_low':lo,f'ZH_{axis}_CI_high':hi})
                rlist.append(r)
        for r in rlist:
            if r['variant']=='translated_classifier':r['S_retention']=r['S']/next(s['S'] for s in rlist if s['source_pair']==r['source_pair'] and s['variant']=='original_classifier')
        metricrows+=rlist
        all_lab=f.copy();all_lab[zh]=translated
        for threshold in [.01,.02,.03]:
            for g in ['ZH','EN-CN','EN-NC']:
                m=mask(d,g);counts=np.bincount(all_lab[m],minlength=15)
                for topic,n in enumerate(counts):
                    lo,hi=cp(int(n),int(m.sum()))
                    voids.append(dict(classifier=classifier,threshold=threshold,group=g,topic=f'T{topic:02d}',n=int(n),denominator=int(m.sum()),share=n/m.sum(),CP_low=lo,CP_high=hi,strict_void=hi<threshold,near_void=n/m.sum()<threshold and not hi<threshold))
    for name,rows in [('E1A_Fidelity',fidelity),('E1A_Doc',docs),('E1A_Transition',transitions),('E1A_Metrics',metricrows),('E1A_Voids',voids),('E1A_Migration',migration)]:save(name,rows)
    status('Task1_E1A','CHECK' if any(r['status']=='CHECK' for r in fidelity) else 'PASS',f'896 original/translation pairs; short translations={int((words<30).sum())}; bootstrap=2000; older dominant-side table count-verified; cached translation token caps documented.')
    combined=raw.copy();combined[zh]=trans;tx,tm,tp=post_fit(combined)
    for name,arr in [('pp_translated',tx),('pp_translated_mean',tm),('pp_translated_pcs',tp)]:np.save(ART/f'{name}.npy',arr)
    pairs=[];mapping=[];acomp=[];assign=[]
    for seed in SEEDS:
        origlab=np.load(ART/f'E5_original_seed{seed}_labels.npy')
        if not passed:
            status('Task1_E1B','CHECK','Original embedding gate failed; task8 uses historical originals, so exact same-environment paired E1B is unavailable without changing task8. E1A completed on regenerated originals.')
            return
        p=ART/f'E5_translated_seed{seed}_labels.npy'
        labs=np.load(p) if p.exists() else fit_cluster(tx,seed,'E5_translated')[0]
        mapped,mp=align(f,labs);mapping.extend(dict(seed=seed,**r) for r in mp)
        acomp.extend(dict(seed=seed,**r) for r in comparisons(d,f,labs,mapped))
        so=sep(origlab[zh],origlab[~zh]);st=sep(labs[zh],labs[~zh]);n=np.bincount(labs,minlength=15);nz=np.bincount(labs[zh],minlength=15)
        r=dict(seed=seed,S_T=st['S'],S_O=so['S'],S_retention=st['S']/so['S'],JSD_T=st['JSD'],JSD_O=so['JSD'],rho_T=st['rho'],rho_O=so['rho'],ZH_majority_clusters=int((nz/n>.5).sum()),ZH_VALUE_share=float(np.isin(mapped[zh],VALUE).mean()))
        for g,m in [('ALL',np.ones(1427,bool)),('ZH',zh),('EN',~zh)]:r['ARI_T_vs_O_'+g]=float(adjusted_rand_score(labs[m],origlab[m]))
        pairs.append(r);assign.extend(dict(seed=seed,doc_id=doc,cluster=int(l),mapped_topic=f'T{a:02d}') for doc,l,a in zip(d.doc_id,labs,mapped))
        save('E1B_Pairs',pairs);save('E1B_Mapping',mapping);save('E1B_Alignment',acomp);save('E1B_Assignments',assign)
        print(f'E1B seed={seed} S retention={r["S_retention"]:.4f}',flush=True)
    df=pd.DataFrame(pairs)
    save('E1B_Summary',[dict(metric=c,minimum=float(df[c].min()),median=float(df[c].median()),maximum=float(df[c].max()),seed_n=10) for c in df if c!='seed'])
    check=pd.read_csv(TABLES/'Seed_Metrics.csv').iloc[0]
    assert pairs[0]['S_O']==check['S_ZH_vs_EN'] or np.isclose(pairs[0]['S_O'],check['S_ZH_vs_EN'],atol=1e-15)
    manifest();status('Task1_E1B','PASS','10 paired seeds, original seed42 loaded directly from task8; full 1427-record alignment and all model artifacts saved.')

if __name__=='__main__':
    with threadpool_limits(limits=4):guarded('Task1',main)
