# Recovered historical source; run only from historical/ after supplying documented inputs.
# -*- coding: utf-8 -*-
"""Phase F: frozen-model granularity, parallel-abstract audit, and LaBSE robustness."""
from __future__ import annotations
import json, os, re, sys, traceback
from pathlib import Path
import numpy as np
import pandas as pd
import jieba
from sklearn.cluster import KMeans
from sklearn.metrics import adjusted_rand_score
from sklearn.decomposition import PCA
from sklearn.metrics import normalized_mutual_info_score
from scipy.spatial.distance import cdist

ROOT = Path('.')
OUT = ROOT / "outputs" / "rerun_1427_k15"
FINAL = ROOT / "output" / "final_rebuild_20260927_1427"
OUT.mkdir(parents=True, exist_ok=True)
SEED = 42
GRID = [8, 10, 12, 14, 16, 18]
ALL_K = GRID + [15]
STABILITY_SEEDS = [42, 7, 123, 2024, 999, 17, 21, 33, 55, 77]

def clean_text(x):
    return "" if pd.isna(x) else str(x)

def en_tokens(text):
    toks = re.findall(r"[A-Za-z][A-Za-z0-9'_-]*", text.lower())
    return toks

def zh_tokens(text):
    toks = []
    for t in jieba.lcut(text):
        t = t.strip().lower()
        if not t:
            continue
        if re.search(r"[\u4e00-\u9fff]", t) or re.fullmatch(r"[a-z0-9_-]+", t):
            toks.append(t)
    return toks

def add_ngrams(tokens, max_n=3):
    out = list(tokens)
    for n in range(2, max_n + 1):
        out.extend("_".join(tokens[i:i+n]) for i in range(len(tokens) - n + 1))
    return out

def normalize_term(term):
    parts = [p for p in re.split(r"\s+", clean_text(term).strip().lower()) if p]
    return "_".join(parts)

def rows_of(df):
    if df is None or df.empty:
        return []
    obj = df.astype(object).where(pd.notna(df), None)
    return obj.values.tolist()

def read_top_terms(k):
    p = FINAL / f"TopTerms_k{k}.csv"
    df = pd.read_csv(p, encoding="utf-8-sig")
    df["term_norm"] = df["term"].map(normalize_term)
    return df

def coherence_for_language(k, lang, docs, topic_labels, topterms):
    from gensim.corpora import Dictionary
    from gensim.models.coherencemodel import CoherenceModel
    mask = docs["language"].eq(lang).to_numpy()
    texts = docs.loc[mask, "text"].tolist()
    labels = np.asarray(topic_labels)[mask]
    token_texts = []
    for t in texts:
        raw = zh_tokens(t) if lang == "zh" else en_tokens(t)
        token_texts.append(add_ngrams(raw))
    dictionary = Dictionary(token_texts)
    tdf = topterms[topterms["language"].eq(lang)].copy()
    topics = []
    topic_codes = []
    n_docs = []
    for topic in range(k):
        code = f"T{topic:02d}"
        n_topic = int((labels == topic).sum())
        if n_topic < 15:
            continue
        terms = [x for x in tdf.loc[tdf["topic_code"].eq(code), "term_norm"].head(10).tolist() if x in dictionary.token2id]
        if len(terms) >= 2:
            topics.append(terms)
            topic_codes.append(code)
            n_docs.append(n_topic)
    if not topics:
        return [], {"language": lang, "k": k, "valid_topics": 0, "cv_mean": np.nan, "npmi_mean": np.nan}
    cv = CoherenceModel(topics=topics, texts=token_texts, dictionary=dictionary, coherence="c_v", processes=1, topn=10).get_coherence_per_topic()
    npmi = CoherenceModel(topics=topics, texts=token_texts, dictionary=dictionary, coherence="c_npmi", processes=1, topn=10).get_coherence_per_topic()
    rows = []
    for code, n, a, b, topic_terms in zip(topic_codes, n_docs, cv, npmi, topics):
        rows.append({"k": k, "language": lang, "topic_code": code, "n_docs": n, "n_terms_used": len(topic_terms), "c_v": float(a), "NPMI": float(b), "terms_used": "; ".join(topic_terms)})
    weights = np.asarray(n_docs, dtype=float)
    summary = {"language": lang, "k": k, "valid_topics": len(rows), "cv_mean": float(np.average(cv, weights=weights)), "npmi_mean": float(np.average(npmi, weights=weights))}
    return rows, summary

def main():
    corpus = pd.read_csv(FINAL / "Corpus_Master.csv", encoding="utf-8-sig", dtype=str).fillna("")
    corpus["text"] = corpus["title"].map(clean_text) + "。" + corpus["abstract"].map(clean_text)
    corpus["language"] = corpus["language"].replace({"en": "en", "zh": "zh"})
    U = np.load(FINAL / "umap_10d_l2.npy")
    main_assign = pd.read_csv(FINAL / "Assignments.csv", encoding="utf-8-sig", dtype=str)
    main_codes = main_assign["topic_code"].to_numpy()
    main_int = np.array([int(x[1:]) for x in main_codes])
    all_rows = []
    summaries = []
    assignments_meta = []
    for k in ALL_K:
        labels = KMeans(k, random_state=SEED, n_init=30).fit_predict(U)
        assignments_meta.append({"k": k, "n": int(len(labels)), "ari_vs_k15": float(adjusted_rand_score(main_int, labels)) if k == 15 else None, "min_cluster_n": int(np.bincount(labels).min())})
        terms = read_top_terms(k)
        for lang in ["zh", "en"]:
            try:
                rows, summary = coherence_for_language(k, lang, corpus, labels, terms)
                all_rows.extend(rows)
                summaries.append(summary)
            except Exception as exc:
                summaries.append({"language": lang, "k": k, "valid_topics": 0, "cv_mean": np.nan, "npmi_mean": np.nan, "error": repr(exc)})
    detail = pd.DataFrame(all_rows)
    summary_df = pd.DataFrame(summaries)
    combined = []
    for k in ALL_K:
        sub = detail[detail["k"].eq(k)] if not detail.empty else pd.DataFrame()
        if len(sub):
            w = sub["n_docs"].astype(float)
            combined.append({"k": k, "languages": "zh+en", "valid_topic_language_rows": len(sub), "c_v_weighted": float(np.average(sub["c_v"], weights=w)), "NPMI_weighted": float(np.average(sub["NPMI"], weights=w))})
        else:
            combined.append({"k": k, "languages": "zh+en", "valid_topic_language_rows": 0, "c_v_weighted": np.nan, "NPMI_weighted": np.nan})
    grid = pd.DataFrame(combined)
    grid["is_requested_grid"] = grid["k"].isin(GRID)
    grid["is_k15"] = grid["k"].eq(15)

    # F1: simultaneous UMAP and KMeans seed stability. Existing Stability_Grid
    # varies KMeans only; this table varies both on the frozen postprocessed E5 space.
    post = np.load(FINAL / "embeddings_postprocessed_allbuttop3.npy").astype(np.float32)
    umap_module = __import__("umap")
    stability_rows = []
    for k in ALL_K:
        U_ref = np.load(FINAL / "umap_10d_l2.npy").astype(np.float32)
        ref_labels = KMeans(k, random_state=42, n_init=30).fit_predict(U_ref)
        for seed in STABILITY_SEEDS:
            if seed == 42:
                U_seed = U_ref
            else:
                U_seed = umap_module.UMAP(n_neighbors=100, n_components=10, min_dist=0.0, metric="cosine", random_state=seed, low_memory=True).fit_transform(post).astype(np.float32)
            labels = KMeans(k, random_state=seed, n_init=30).fit_predict(U_seed)
            stability_rows.append({"k": k, "seed": seed, "umap_seed": seed, "kmeans_seed": seed, "ARI_vs_seed42": float(adjusted_rand_score(ref_labels, labels)), "NMI_vs_seed42": float(normalized_mutual_info_score(ref_labels, labels)), "min_cluster_n": int(np.bincount(labels, minlength=k).min()), "clusters_n_lt25": int((np.bincount(labels, minlength=k) < 25).sum()), "method": "UMAP and KMeans seeds changed together; n_init=30"})
    stability10 = pd.DataFrame(stability_rows)
    stability_summary = stability10.groupby("k").agg(ARI_mean=("ARI_vs_seed42", "mean"), ARI_min=("ARI_vs_seed42", "min"), ARI_q25=("ARI_vs_seed42", lambda x: float(x.quantile(.25))), ARI_median=("ARI_vs_seed42", "median"), ARI_q75=("ARI_vs_seed42", lambda x: float(x.quantile(.75))), min_cluster_n_min=("min_cluster_n", "min"), max_clusters_n_lt25=("clusters_n_lt25", "max")).reset_index()

    # F2: inspect the final CNKI export and the local copies for English-abstract fields.
    cnki_candidates = [ROOT / "work" / "new_inputs" / "cnki.xlsx", Path('./private_inputs/CNKI_computational_art_unit_complete.xlsx')]
    f2_rows = []
    seen = set()
    for p in cnki_candidates:
        if not p.exists() or str(p) in seen:
            continue
        seen.add(str(p))
        try:
            xl = pd.ExcelFile(p)
            fields = []
            for s in xl.sheet_names:
                cols = [str(c) for c in pd.read_excel(p, sheet_name=s, nrows=0).columns]
                fields.extend([f"{s}:{c}" for c in cols if any(t in c.lower() for t in ["english", "英文", "abstract", "摘要"]) and not any(t in c.lower() for t in ["中文", "summary-摘要", "摘要"])])
            f2_rows.append({"file": str(p), "english_abstract_field_found": bool(fields), "fields": "; ".join(fields), "n_title_matched": 0, "status": "NO_FIELD_AVAILABLE" if not fields else "FIELD_REQUIRES_TITLE_MATCH"})
        except Exception as exc:
            f2_rows.append({"file": str(p), "english_abstract_field_found": False, "fields": "", "n_title_matched": 0, "status": "READ_ERROR", "error": repr(exc)})
    f2 = pd.DataFrame(f2_rows)

    # F2 anchor concepts and parallel abstracts. The translation cache is matched
    # by exact title because the old source_record_id has duplicate CNKI values.
    anchor_pairs = [
        ("作者归属", "authorship"), ("创造力", "creativity"), ("主体性", "subjectivity"),
        ("本体论", "ontology"), ("伦理", "ethics"), ("版权", "copyright"), ("审美", "aesthetics"),
        ("风格迁移", "style transfer"), ("生成对抗网络", "generative adversarial network"),
        ("扩散模型", "diffusion model"), ("图像分类", "image classification"), ("点云", "point cloud"),
        ("非物质文化遗产", "intangible cultural heritage"), ("书法", "calligraphy"), ("陶瓷", "ceramics"),
        ("博物馆", "museum"), ("展览", "exhibition"), ("舞蹈", "dance"), ("编舞", "choreography"),
        ("音乐生成", "music generation"), ("电影", "film"), ("动画", "animation"), ("插画", "illustration"),
        ("数字媒体艺术", "digital media art"), ("元宇宙", "metaverse"), ("人机协作", "human-AI collaboration"),
        ("艺术设计", "art and design"), ("计算美学", "computational aesthetics"), ("灵韵", "aura"),
        ("文化传承", "cultural transmission"), ("人工智能艺术", "AI art"), ("深度学习", "deep learning"),
        ("图像生成", "image generation"),
    ]
    f2_anchor_detail = []
    f2_anchor_summary = []
    parallel_summary = []
    parallel_detail = []
    f2_missing = []
    try:
        from sentence_transformers import SentenceTransformer
        model = SentenceTransformer(str(ROOT / "work" / "models" / "multilingual-e5-large"))
        raw_vectors = np.load(ROOT / "work" / "new_inputs" / "embeddings_1427.npy").astype(np.float64)
        center = raw_vectors.mean(axis=0, keepdims=True)
        centered = raw_vectors - center
        pca = PCA(n_components=3, random_state=42).fit(centered)
        def postprocess(x):
            r = x - center - pca.inverse_transform(pca.transform(x - center))
            return r / np.linalg.norm(r, axis=1, keepdims=True)
        def encode(texts, prefix):
            return np.asarray(model.encode([prefix + str(x) for x in texts], batch_size=16, normalize_embeddings=True, show_progress_bar=False), dtype=np.float64)
        zh_q = encode([x[0] for x in anchor_pairs], "query: ")
        en_p = encode([x[1] for x in anchor_pairs], "passage: ")
        zh_qp = postprocess(zh_q); en_pp = postprocess(en_p)
        rng = np.random.default_rng(42)
        for label, a, b in [("raw_query_passage", zh_q, en_p), ("postprocessed_query_passage", zh_qp, en_pp)]:
            S = a @ b.T
            ranks = [int(1 + (S[i] > S[i, i]).sum()) for i in range(len(anchor_pairs))]
            true = np.diag(S)
            wrong = S[~np.eye(len(anchor_pairs), dtype=bool)]
            observed = float(true.mean() - wrong.mean())
            null = []
            for _ in range(5000):
                null.append(float(true.mean() - S[np.arange(len(anchor_pairs)), rng.permutation(len(anchor_pairs))].mean()))
            f2_anchor_summary.append({"representation": label, "pairs": len(anchor_pairs), "true_mean_cosine": float(true.mean()), "mismatch_mean_cosine": float(wrong.mean()), "mean_difference": observed, "permutation_p_greater_equal": float(np.mean(np.asarray(null) >= observed)), "top1": float(np.mean(np.asarray(ranks) <= 1)), "top5": float(np.mean(np.asarray(ranks) <= 5)), "median_rank": float(np.median(ranks)), "permutations": 5000, "seed": 42})
            for (zh_word, en_word), t, r in zip(anchor_pairs, true, ranks):
                f2_anchor_detail.append({"representation": label, "zh": zh_word, "en": en_word, "true_cosine": float(t), "rank": r})

        tr_path = ROOT / "work" / "joint_k12_revision_20260821" / "translation_robustness" / "document_assignments_with_translated_text.csv"
        tr = pd.read_csv(tr_path, encoding="utf-8-sig", dtype=str, keep_default_na=False)
        tr_map = dict(zip(tr.loc[tr["source"].eq("CNKI"), "title"], tr.loc[tr["source"].eq("CNKI"), "translated_model_text"]))
        cn = corpus[corpus["language"].eq("zh")].copy()
        cn["translated_text"] = cn["title"].map(tr_map).fillna("").str.replace(r"^passage:\s*", "", regex=True)
        cn = cn[cn["translated_text"].str.len().gt(0)].copy()
        if len(cn) < 100:
            raise ValueError(f"only {len(cn)} current CNKI records matched old translation cache; expected >=100")
        sample = cn.sample(n=100, random_state=42)
        original_texts = sample["title"].astype(str) + "。" + sample["abstract"].astype(str)
        translated_texts = sample["translated_text"].astype(str)
        # The saved UMAP is frozen; fit the identical transform only to project new texts.
        umap_fitted = umap_module.UMAP(n_neighbors=100, n_components=10, min_dist=0.0, metric="cosine", random_state=42, low_memory=True).fit(postprocess(raw_vectors))
        frozen_U = np.load(FINAL / "umap_10d_l2.npy").astype(np.float64)
        frozen_labels = main_int
        km = KMeans(15, random_state=42, n_init=30).fit(frozen_U)
        for label, orig, trans in [("raw_passage", encode(original_texts.tolist(), "passage: "), encode(translated_texts.tolist(), "passage: ")), ("postprocessed_passage", None, None)]:
            if label == "postprocessed_passage":
                orig = postprocess(encode(original_texts.tolist(), "passage: "))
                trans = postprocess(encode(translated_texts.tolist(), "passage: "))
            S = orig @ trans.T
            ranks = np.array([1 + int((S[i] > S[i, i]).sum()) for i in range(len(sample))])
            parallel_summary.append({"representation": label, "pairs": len(sample), "candidates": len(sample), "top1": float(np.mean(ranks <= 1)), "top5": float(np.mean(ranks <= 5)), "median_rank": float(np.median(ranks)), "seed": 42})
        orig_post = postprocess(encode(original_texts.tolist(), "passage: "))
        trans_post = postprocess(encode(translated_texts.tolist(), "passage: "))
        u_orig = umap_fitted.transform(orig_post)
        u_trans = umap_fitted.transform(trans_post)
        orig_topic = frozen_labels[sample.index.to_numpy()]
        trans_topic = np.argmin(cdist(u_trans, km.cluster_centers_), axis=1)
        for rid, old_t, new_t in zip(sample["doc_id"], orig_topic, trans_topic):
            parallel_detail.append({"doc_id": rid, "original_topic": f"T{int(old_t):02d}", "translated_projected_topic": f"T{int(new_t):02d}", "topic_match": bool(old_t == new_t)})
        parallel_summary.append({"representation": "fixed_space_topic_projection", "pairs": len(sample), "candidates": len(sample), "topic_match_rate": float(np.mean(orig_topic == trans_topic)), "seed": 42, "note": "UMAP fitted on frozen postprocessed main vectors and used only for transform; K=15 centroids frozen by main assignment."})
    except Exception as exc:
        f2_missing.append(f"- F2 anchor/parallel：{repr(exc)}")

    # F3: LaBSE. Try local cache first; if unavailable, attempt the requested download and record failures.
    f3_status = [{"model": "sentence-transformers/LaBSE", "status": "MISSING_INPUTS", "reason": "Model not present locally; download not yet attempted", "n": 0, "ARI_vs_frozen_k15": np.nan, "ARI_ZH": np.nan, "ARI_EN": np.nan}]
    missing_lines = []
    try:
        from sentence_transformers import SentenceTransformer
        model = None
        local_candidates = [ROOT / "work" / "models" / "LaBSE", ROOT / "work" / "models" / "labse"]
        for lp in local_candidates:
            if lp.exists() and (lp / "config.json").exists():
                model = SentenceTransformer(str(lp))
                break
        if model is None:
            raise FileNotFoundError("LaBSE is not present in the local model cache; the earlier HuggingFace download attempt timed out")
        texts = corpus["text"].tolist()
        emb = model.encode(texts, batch_size=16, normalize_embeddings=True, show_progress_bar=True)
        um = __import__("umap")
        U2 = um.UMAP(n_neighbors=100, n_components=10, min_dist=0.0, metric="cosine", random_state=42).fit_transform(emb)
        labels2 = KMeans(15, random_state=42, n_init=30).fit_predict(U2)
        f3_status = [{"model": "sentence-transformers/LaBSE", "status": "COMPLETED", "reason": "same UMAP parameters and K=15; no E5 replacement", "n": int(len(labels2)), "ARI_vs_frozen_k15": float(adjusted_rand_score(main_int, labels2)), "ARI_ZH": float(adjusted_rand_score(main_int[corpus.language.eq("zh")], labels2[corpus.language.eq("zh")])), "ARI_EN": float(adjusted_rand_score(main_int[corpus.language.eq("en")], labels2[corpus.language.eq("en")]))}]
        np.save(OUT / "phase_f_labse_embeddings.npy", np.asarray(emb, dtype=np.float32))
    except Exception as exc:
        missing_lines.append(f"- LaBSE：{repr(exc)}")

    payload = {
        "F1_Coherence_Detail": {"columns": list(detail.columns) if not detail.empty else ["k", "language", "topic_code", "n_docs", "n_terms_used", "c_v", "NPMI", "terms_used"], "rows": rows_of(detail)},
        "F1_Coherence_Summary": {"columns": list(summary_df.columns), "rows": rows_of(summary_df)},
        "F1_K15_vs_Grid": {"columns": list(grid.columns), "rows": rows_of(grid)},
        "F1_Assignment_Audit": {"columns": list(pd.DataFrame(assignments_meta).columns), "rows": rows_of(pd.DataFrame(assignments_meta))},
        "F1_Stability_10seed": {"columns": list(stability10.columns), "rows": rows_of(stability10)},
        "F1_Stability_Summary": {"columns": list(stability_summary.columns), "rows": rows_of(stability_summary)},
        "F1_Method_Audit": {"columns": ["item", "value"], "rows": [["existing_Stability_Grid", "KMeans seed varied; UMAP random_state held at 42"], ["new_stability", "UMAP and KMeans seed varied together"], ["seeds", "; ".join(map(str, STABILITY_SEEDS))], ["coherence_terms", "c-TF-IDF top 10"], ["coherence_min_side_n", 15], ["coherence_tokenization", "ZH jieba; EN regex; unigrams plus ngrams; project stopword file was not applied because c-TF-IDF terms include bilingual ngrams"]]},
        "F2_Parallel_Abstract_Audit": {"columns": list(f2.columns) if not f2.empty else ["file", "english_abstract_field_found", "fields", "n_title_matched", "status"], "rows": rows_of(f2)},
        "F2_Anchor_Summary": {"columns": list(pd.DataFrame(f2_anchor_summary).columns) if f2_anchor_summary else ["representation", "pairs", "true_mean_cosine", "mismatch_mean_cosine", "mean_difference", "permutation_p_greater_equal", "top1", "top5", "median_rank", "permutations", "seed"], "rows": rows_of(pd.DataFrame(f2_anchor_summary))},
        "F2_Anchor_Detail": {"columns": list(pd.DataFrame(f2_anchor_detail).columns) if f2_anchor_detail else ["representation", "zh", "en", "true_cosine", "rank"], "rows": rows_of(pd.DataFrame(f2_anchor_detail))},
        "F2_Parallel_Summary": {"columns": list(pd.DataFrame(parallel_summary).columns) if parallel_summary else ["representation", "pairs", "candidates", "top1", "top5", "median_rank", "seed"], "rows": rows_of(pd.DataFrame(parallel_summary))},
        "F2_Parallel_Detail": {"columns": list(pd.DataFrame(parallel_detail).columns) if parallel_detail else ["doc_id", "original_topic", "translated_projected_topic", "topic_match"], "rows": rows_of(pd.DataFrame(parallel_detail))},
        "F3_LaBSE_Status": {"columns": list(pd.DataFrame(f3_status).columns), "rows": rows_of(pd.DataFrame(f3_status))},
    }
    with open(OUT / "phase_f_payload.json", "w", encoding="utf-8") as fh:
        json.dump(payload, fh, ensure_ascii=False, allow_nan=False, indent=2)
    summary_out = {"F1_rows": int(len(detail)), "F1_k_rows": int(len(grid)), "F2_files_checked": int(len(f2)), "F2_fields_found": int(f2["english_abstract_field_found"].sum()) if len(f2) else 0, "F3_status": f3_status[0]["status"], "seed": SEED}
    with open(OUT / "phase_f_summary.json", "w", encoding="utf-8") as fh:
        json.dump(summary_out, fh, ensure_ascii=False, allow_nan=False, indent=2)
    missing_lines.extend(f2_missing)
    if missing_lines:
        (OUT / "MISSING_INPUTS_PhaseF.md").write_text("# Phase F MISSING_INPUTS\n\n" + "\n".join(missing_lines) + "\n", encoding="utf-8")
    print(json.dumps(summary_out, ensure_ascii=False, indent=2))
    if not grid.empty:
        print(grid[["k", "c_v_weighted", "NPMI_weighted"]].to_string(index=False))
    print(pd.DataFrame(f3_status).to_string(index=False))

if __name__ == "__main__":
    main()
