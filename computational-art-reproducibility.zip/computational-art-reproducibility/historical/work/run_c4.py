# Recovered historical source; run only from historical/ after supplying documented inputs.
# -*- coding: utf-8 -*-
import pandas as pd, numpy as np, json, re, math, os
from pathlib import Path
from scipy.stats import fisher_exact, chi2, norm
from scipy.spatial.distance import jensenshannon
from statsmodels.stats.contingency_tables import Table2x2, StratifiedTable
import statsmodels.api as sm
from scipy.special import expit
ROOT=Path('.')
OUT=ROOT/'outputs'/'rerun_1427_k15'
BASE=Path('./private_inputs/Epistemic_distinctiveness_data_1427_K15_v2026-09-28.xlsx')
SEED=42
rng=np.random.default_rng(SEED)
def clean(d): d=d.copy(); d.columns=d.columns.astype(str).str.replace('\ufeff','',regex=False); return d
def asnum(x):
 try: return float(x)
 except: return np.nan
def add_row(rows,version,metric,group_a,group_b,a_pos,a_n,b_pos,b_n,orv,pv,ci=None,test='Fisher exact'):
 rows.append({'version':version,'metric':metric,'group_a':group_a,'group_b':group_b,'a_positive':int(a_pos),'a_n':int(a_n),'b_positive':int(b_pos),'b_n':int(b_n),'estimate_OR':float(orv) if np.isfinite(orv) else None,'CI95_low':float(ci[0]) if ci else None,'CI95_high':float(ci[1]) if ci else None,'p_value':float(pv) if np.isfinite(pv) else None,'test':test})
def fisher_row(df,y,version,metric='Q2 strict',ga='EN-CN',gb='EN-NC'):
 a=df.loc[df.group.eq(ga),y].astype(int); b=df.loc[df.group.eq(gb),y].astype(int); tab=np.array([[int(a.sum()),int((1-a).sum())],[int(b.sum()),int((1-b).sum())]])
 orv,p=fisher_exact(tab,alternative='two-sided'); ci=Table2x2(tab).oddsratio_confint(method='normal')
 return {'version':version,'metric':metric,'group_a':ga,'group_b':gb,'a_positive':int(a.sum()),'a_n':len(a),'b_positive':int(b.sum()),'b_n':len(b),'estimate_OR':float(orv),'CI95_low':float(ci[0]),'CI95_high':float(ci[1]),'p_value':float(p),'test':'Fisher exact'}
def mh_result(df,y,dept_col,version,metric):
 tabs=[]; strata=[]
 for dep,g in df.groupby(dept_col,dropna=False):
  a=int(((g.group=='EN-CN')&(g[y]==1)).sum()); b=int(((g.group=='EN-CN')&(g[y]==0)).sum()); c=int(((g.group=='EN-NC')&(g[y]==1)).sum()); d=int(((g.group=='EN-NC')&(g[y]==0)).sum());
  if a+b+c+d: tabs.append(np.array([[a,b],[c,d]])); strata.append(str(dep))
 arr=np.stack(tabs,axis=2); st=StratifiedTable(arr); ci=st.oddsratio_pooled_confint(); test=st.test_null_odds(correction=True)
 return {'version':version,'metric':metric,'estimate_OR':float(st.oddsratio_pooled),'CI95_low':float(ci[0]),'CI95_high':float(ci[1]),'p_value':float(test.pvalue),'test':'Mantel-Haenszel with continuity correction','strata':'; '.join(strata)}
def logistic_result(df,y,dept_col,version,metric):
 d=df.copy(); d=d[d.group.isin(['EN-CN','EN-NC'])].copy(); d['group_ec']=(d.group=='EN-CN').astype(int); d['year_c']=pd.to_numeric(d.year,errors='coerce').fillna(2022)-2022; d['obj']=pd.to_numeric(d.OBJ_CN,errors='coerce').fillna(0)
 X=pd.concat([d[['group_ec','year_c','obj']].reset_index(drop=True),pd.get_dummies(d[dept_col].fillna('UNKNOWN'),prefix='dept',drop_first=True,dtype=float).reset_index(drop=True)],axis=1); X=sm.add_constant(X,has_constant='add'); yv=d[y].astype(int).to_numpy(); model=sm.Logit(yv,X.astype(float)).fit(disp=False,maxiter=200)
 beta=float(model.params['group_ec']); se=float(model.bse['group_ec']); return {'version':version,'metric':metric,'estimate_OR':float(np.exp(beta)),'CI95_low':float(np.exp(beta-1.96*se)),'CI95_high':float(np.exp(beta+1.96*se)),'p_value':float(model.pvalues['group_ec']),'test':'Logistic regression: group + dept fixed effects + year-2022 + OBJ_CN','n':len(d)}
def firth_fit(X,y,maxiter=100,tol=1e-8):
 X=np.asarray(X,float); y=np.asarray(y,float); p=X.shape[1]; beta=np.zeros(p)
 for _ in range(maxiter):
  mu=expit(X@beta); W=np.clip(mu*(1-mu),1e-9,None); I=X.T@(W[:,None]*X); inv=np.linalg.pinv(I); H=(X@inv*X).sum(axis=1)*W; adj=y-mu+H*(0.5-mu); step=inv@(X.T@adj);
  if np.max(np.abs(step))<tol: beta=beta+step; break
  beta=beta+step
 mu=expit(X@beta); W=np.clip(mu*(1-mu),1e-9,None); cov=np.linalg.pinv(X.T@(W[:,None]*X)); return beta,cov
def firth_result(df,y,dept_col,version,metric):
 d=df[df.group.isin(['EN-CN','EN-NC'])].copy(); d['group_ec']=(d.group=='EN-CN').astype(int); d['year_c']=pd.to_numeric(d.year,errors='coerce').fillna(2022)-2022; d['obj']=pd.to_numeric(d.OBJ_CN,errors='coerce').fillna(0); X=pd.concat([d[['group_ec','year_c','obj']].reset_index(drop=True),pd.get_dummies(d[dept_col].fillna('UNKNOWN'),prefix='dept',drop_first=True,dtype=float).reset_index(drop=True)],axis=1); X=sm.add_constant(X,has_constant='add'); beta,cov=firth_fit(X.to_numpy(),d[y].astype(int).to_numpy()); names=list(X.columns); i=names.index('group_ec'); se=float(np.sqrt(max(cov[i,i],1e-12))); return {'version':version,'metric':metric,'estimate_OR':float(np.exp(beta[i])),'CI95_low':float(np.exp(beta[i]-1.96*se)),'CI95_high':float(np.exp(beta[i]+1.96*se)),'p_value':float(2*norm.sf(abs(beta[i]/se))),'test':'Firth penalized logistic regression','n':len(d)}
def jsd_rows(df,version,metric):
 qcols=[c for c in df.columns if re.match(r'^Q[1-9].*dict$',c) and c not in {'Q2_dict','Q8_dict'}]
 def dist(g):
  x=g[qcols].astype(float).sum(axis=0).to_numpy()+0.5; return x/x.sum()
 a=dist(df[df.group=='EN-CN']); b=dist(df[df.group=='EN-NC']); z=dist(df[df.group=='ZH']) if 'ZH' in set(df.group) else None
 js=float(jensenshannon(a,b,base=2)**2); jz=float(jensenshannon(z,a,base=2)**2) if z is not None else None; jn=float(jensenshannon(z,b,base=2)**2) if z is not None else None
 # 5000 group-label permutations preserving group sizes among English; compare EN-CN vs EN-NC
 e=df[df.group.isin(['EN-CN','EN-NC'])].copy(); labels=e.group.to_numpy(); perm=[]
 for i in range(5000):
  lp=labels.copy(); rng.shuffle(lp); e2=e.copy(); e2['gp']=lp; aa=e2[e2.gp=='EN-CN']; bb=e2[e2.gp=='EN-NC']; va=(aa[qcols].astype(float).sum()+0.5).to_numpy().copy(); vb=(bb[qcols].astype(float).sum()+0.5).to_numpy().copy(); va/=va.sum(); vb/=vb.sum(); perm.append(jensenshannon(va,vb,base=2)**2)
 perm=np.array(perm); p=float((np.sum(perm>=js)+1)/(len(perm)+1))
 return [{'version':version,'metric':metric,'comparison':'EN-CN vs EN-NC','JSD_bits':js,'permutation_p_two_sided':p,'n_perm':5000,'q_columns':','.join(qcols)}, {'version':version,'metric':metric,'comparison':'ZH vs EN-CN','JSD_bits':jz,'permutation_p_two_sided':None,'n_perm':None,'q_columns':','.join(qcols)}, {'version':version,'metric':metric,'comparison':'ZH vs EN-NC','JSD_bits':jn,'permutation_p_two_sided':None,'n_perm':None,'q_columns':','.join(qcols)}]
# inputs
ref=clean(pd.read_excel(BASE,sheet_name='21b_主体性_逐篇核对')); main=clean(pd.read_excel(BASE,sheet_name='30_记录级主数据')); b3=pd.read_csv(OUT/'B3_Dept_Doc_Level.csv')
# merge dictionary fields and v2 dept
df=ref.merge(main[['doc_id']+[c for c in main.columns if re.match(r'^Q[1-9].*dict$',c)+[c for c in []]]],on='doc_id',how='left') if False else ref.copy()
qcols=[c for c in main.columns if re.match(r'^Q[1-9].*dict$',c)]
df=df.merge(main[['doc_id']+qcols+['OBJ_CN_dict','topic']].rename(columns={'topic':'topic_code_main'}),on='doc_id',how='left')
df=df.merge(b3[['doc_id','dept_type_v2','difference_flag']],on='doc_id',how='left')
# normalize dictionary values
for c in qcols+['Q2_dictionary','Q8_dictionary','OBJ_CN','OBJ_CN_dict']:
 if c in df.columns: df[c]=pd.to_numeric(df[c],errors='coerce').fillna(0).astype(int)
df['Q2_strict']=df.Q2_verified.astype(str).eq('1').astype(int); df['Q2_loose']=df.Q2_verified.astype(str).isin(['1','B']).astype(int); df['Q2_dict']=df.Q2_dictionary.astype(int); df['Q8_dict']=df.Q8_dictionary.astype(int); df['OBJ_CN']=df['OBJ_CN_dict'].fillna(df['OBJ_CN']).astype(int)
# core tests
doc_rows=[]
for version,dept_col in [('17b','dept_fixed'),('v2','dept_type_v2')]:
 for y,metric in [('Q2_dict','Q2 dictionary'),('Q2_strict','Q2 strict'),('Q2_loose','Q2 loose'),('Q8_dict','Q8 dictionary')]: doc_rows.append(fisher_row(df,y,version,metric))
 for y,metric in [('Q2_strict','Q2 strict MH'),('Q2_loose','Q2 loose MH'),('Q8_dict','Q8 dictionary MH')]: doc_rows.append(mh_result(df,y,dept_col,version,metric))
 for y,metric in [('Q2_strict','Q2 strict adjusted logistic'),('Q8_dict','Q8 dictionary adjusted logistic')]: doc_rows.append(logistic_result(df,y,dept_col,version,metric))
 for y,metric in [('Q2_strict','Q2 strict Firth'),('Q8_dict','Q8 dictionary Firth')]: doc_rows.append(firth_result(df,y,dept_col,version,metric))
# journal strict
shared=df.groupby('journal')['group'].nunique(); journals=shared[shared==2].index.tolist(); jdf=df[df.journal.isin(journals)].copy(); jrow=fisher_row(jdf,'Q2_strict','shared_journals','Q2 strict shared 50 journals'); jm=mh_result(jdf,'Q2_strict','dept_fixed','shared_journals','Q2 strict shared-journal MH')
# robustness
rob=[]
for r in [jrow,jm]: rob.append(r)
for period,label in [((2019,2022),'2019-2022'),((2023,2026),'2023-2026')]:
 sub=df[df.year.between(period[0],period[1])]; r=fisher_row(sub,'Q2_strict',label,'Q2 strict period'); rob.append(r)
for country in sorted(df.country_group.dropna().unique()):
 sub=df[df.country_group==country]; y=sub.Q2_strict.astype(int); rob.append({'metric':'Q2 strict country share','country_group':country,'positive':int(y.sum()),'n':len(y),'share':float(y.mean())})
for left,right,label in [('CN','ANGLO+EURO','CN vs ANGLO+EURO'),('EASIA','ANGLO+EURO','EASIA vs ANGLO+EURO')]:
 sub=df[df.country_group.isin(([left] if left!='ANGLO+EURO' else []) + (['ANGLO','EURO'] if right=='ANGLO+EURO' else [right]))].copy(); sub['cmp_group']=np.where(sub.country_group==left,left,'ANGLO+EURO'); r=fisher_row(sub.assign(group=sub.cmp_group),'Q2_strict',label,'Q2 strict country comparison',ga=left,gb='ANGLO+EURO'); rob.append(r)
art=df[df.dept_fixed=='ART']; rob.append(fisher_row(art,'Q8_dict','ART only','Q8 dictionary ART subset'))
# topic distribution
topic=df[df.Q2_strict==1].groupby(['topic_code','group']).size().reset_index(name='n'); topic['share_within_group']=topic.groupby('group')['n'].transform(lambda x:x/x.sum());
# JSD
fullmain=main.copy(); fullmain=fullmain.merge(ref[['doc_id','Q2_verified']],on='doc_id',how='left'); fullmain['Q2_strict']=fullmain.Q2_verified.astype(str).eq('1').astype(int); jsd=jsd_rows(fullmain,'17b','Q1-Q9 dictionary JSD'); strictmain=fullmain.copy(); q2col=next((c for c in qcols if c.startswith('Q2_')),None); strictmain[q2col]=strictmain['Q2_strict']; jsd_strict=jsd_rows(strictmain,'17b','Q1-Q9 strict Q2 JSD'); jsd.extend(jsd_strict)
# permutation MH only 10000 for 17b strict and v2 strict
perm_rows=[]
for dept_col,ver in [('dept_fixed','17b'),('dept_type_v2','v2')]:
 obs=mh_result(df,'Q2_strict',dept_col,ver,'Q2 strict MH'); d=df.copy(); labels=d.group.to_numpy(); strata=d[dept_col].fillna('UNKNOWN').to_numpy(); inds={dep:np.where(strata==dep)[0] for dep in np.unique(strata)}; vals=[]
 for i in range(10000):
  lp=labels.copy();
  for dep,idx in inds.items():
   tmp=lp[idx].copy(); rng.shuffle(tmp); lp[idx]=tmp
  dd=d.copy(); dd['group']=lp; rr=mh_result(dd,'Q2_strict',dept_col,'perm','Q2 strict MH'); vals.append(np.log(rr['estimate_OR']))
 vals=np.array(vals); perm_rows.append({'version':ver,'metric':'Q2 strict MH label permutation','observed_OR':obs['estimate_OR'],'perm_p_two_sided':float((np.sum(np.abs(vals)>=abs(np.log(obs['estimate_OR'])))+1)/(len(vals)+1)),'n_perm':len(vals),'seed':SEED})
# validation expected
expected=[('17b','Q2 dictionary',0.409217,0.006316,0.409217),('17b','Q2 strict',0.292286,0.006447,0.292286),('17b','Q2 loose',0.463249,0.005124,0.463249),('17b','Q8 dictionary',1.458141,0.035793,1.458141),('17b','Q2 strict MH',0.270475,0.010188,0.270475),('17b','Q2 strict adjusted logistic',0.288425,0.011870,0.288425),('17b','Q8 dictionary MH',1.643404,0.009375,1.643404)]
valid=[]
for ver,metric,eo,ep,_ in expected:
 got=next(r for r in doc_rows if r['version']==ver and r['metric']==metric); valid.append({'version':ver,'metric':metric,'expected_OR':eo,'computed_OR':got.get('estimate_OR'),'expected_p':ep,'computed_p':got.get('p_value'),'OR_match':abs(got.get('estimate_OR',np.nan)-eo)<0.002,'p_match':abs(got.get('p_value',np.nan)-ep)<0.003})
# payload conversion
def rows_from(d):
 if isinstance(d,list): keys=sorted({k for x in d for k in x.keys()}); rows=[[x.get(k) for k in keys] for x in d]
 elif isinstance(d,pd.DataFrame): keys=list(d.columns); rows=d.astype(object).where(pd.notna(d),None).values.tolist()
 else: keys=list(d.columns); rows=d.values.tolist()
 return {'columns':keys,'rows':rows}
payload={'C4_DocLevel_Tests':rows_from(pd.DataFrame(doc_rows)),'C4_Robustness':rows_from(pd.DataFrame(rob)),'C4_Permutation':rows_from(pd.DataFrame(perm_rows)),'C4_JSD':rows_from(pd.DataFrame(jsd)),'C4_Topic_Q2_Strict':rows_from(topic),'C4_Validation':rows_from(pd.DataFrame(valid))}
(OUT/'c4_payload.json').write_text(json.dumps(payload,ensure_ascii=False,default=str),encoding='utf-8')
summary={'doc_rows':len(doc_rows),'rob_rows':len(rob),'validation':valid,'shared_journals':len(journals),'topic_positive_n':int(df.Q2_strict.sum())}
(OUT/'c4_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(summary,ensure_ascii=False,indent=2))





