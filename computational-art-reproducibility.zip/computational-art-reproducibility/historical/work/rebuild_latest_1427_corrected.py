# Recovered historical source; run only from historical/ after supplying documented inputs.
from pathlib import Path
import re, json, math
import numpy as np, pandas as pd, jieba
from sklearn.preprocessing import normalize
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score, adjusted_rand_score, normalized_mutual_info_score
from sklearn.feature_extraction.text import CountVectorizer
from scipy.optimize import linear_sum_assignment
from umap import UMAP

ROOT=Path('.')
OUT=ROOT/'output'/'final_rebuild_20260927_1427'
OUT.mkdir(parents=True,exist_ok=True)
INP=ROOT/'work'/'new_inputs'
EMB=ROOT/'work'/'new_inputs'/'embeddings_1427.npy'
SEEDS=[42,7,123,2024,999]
KS=list(range(8,19))

def clean(x):
    if x is None: return ''
    s=str(x).strip()
    return '' if s.lower() in {'nan','none','null'} else s

def first_addr(x):
    s=clean(x)
    if not s:return 'Unclassified'
    seg=re.split(r';\s*(?=\[)',s)[0].strip(' ,')
    seg=re.sub(r'^\[[^]]+\]\s*','',seg).strip()
    return 'EN-CN' if re.search(r'Peoples R China\s*$',seg,re.I) else 'EN-NC'

def tok(t):
    out=[]
    for ch in re.findall(r'[\u4e00-\u9fff]+|[a-z][a-z0-9-]+',clean(t).lower()):
        if re.fullmatch(r'[\u4e00-\u9fff]+',ch): out += [x.strip() for x in jieba.lcut(ch) if len(x.strip())>=2]
        elif len(ch)>=2: out.append(ch)
    stop={'the','and','of','to','in','a','for','is','that','this','with','on','are','as','by','an','from','be','or','it','we','our','their','these','which','using','based','study','research','paper','results','method','methods','approach','proposed','can','has','have','was','were','also','such','into','between','more','than','its','through','use','used','different','new','one','two','may','within','shown','first','well','could','however','including'}
    return [x for i,x in enumerate(out) if x not in stop and not x.isdigit() and (i==0 or x!=out[i-1])]

def jacc(a,b):
    aa=sorted(set(a));bb=sorted(set(b)); m=np.zeros((len(aa),len(bb)))
    for i,x in enumerate(aa):
      for j,y in enumerate(bb):
       inter=((a==x)&(b==y)).sum(); union=((a==x)|(b==y)).sum(); m[i,j]=inter/union if union else 0
    r,c=linear_sum_assignment(-m); return float(m[r,c].mean()) if len(r) else 0.0

def load():
    c0=pd.read_excel(INP/'cnki.xlsx',sheet_name='Final_Corpus',dtype=str,keep_default_na=False); c0.columns=['title','abstract','keywords','year','authors','journal','institution_or_address','doi','clc_raw','review','highlight_reason']
    w0=pd.read_excel(INP/'wos.xlsx',sheet_name='WoS_Included_Final',dtype=str,keep_default_na=False)
    if len(c0)!=896 or len(w0)!=531: raise ValueError((len(c0),len(w0)))
    c=pd.DataFrame({'doc_id':[f'CNKI_{i:04d}' for i in range(len(c0))],'source':'CNKI','language':'zh','title':c0.title.map(clean),'abstract':c0.abstract.map(clean),'keywords':c0.keywords.map(clean),'year':pd.to_numeric(c0.year,errors='coerce'),'authors':c0.authors.map(clean),'journal':c0.journal.map(clean),'source_record_id':c0.doi.map(clean),'institution_or_address':c0.institution_or_address.map(clean),'analysis_group':'ZH','clc_raw':c0.clc_raw.map(clean)})
    w=pd.DataFrame({'doc_id':[f'WOS_{i:04d}' for i in range(len(w0))],'source':'WoS','language':'en','title':w0['Article Title'].map(clean),'abstract':w0['Abstract'].map(clean),'keywords':w0['Author Keywords'].map(clean),'year':pd.to_numeric(w0['Publication Year'],errors='coerce'),'authors':w0['Authors'].map(clean),'journal':w0['Source Title'].map(clean),'source_record_id':w0['UT (Unique WOS ID)'].map(clean),'institution_or_address':w0['Addresses'].map(clean),'analysis_group':w0['Addresses'].map(first_addr),'wos_categories_raw':w0['WoS Categories'].map(clean),'research_areas_raw':w0['Research Areas'].map(clean),'document_type_raw':w0['Document Type'].map(clean),'language_raw':w0['Language'].map(clean),'affiliations_raw':w0['Affiliations'].map(clean)})
    d=pd.concat([c,w],ignore_index=True,sort=False).fillna(''); d['model_text']='passage: '+d.title+'. '+d.abstract; d['topic_source']=np.where(d.source.eq('CNKI'),'ZH','EN'); return d

def terms(d,labels,k):
    rows=[]
    for lang in ['zh','en']:
      ix=np.where(d.language.eq(lang))[0]; sub=d.iloc[ix]; vec=CountVectorizer(tokenizer=tok,token_pattern=None,lowercase=False,ngram_range=(1,2),min_df=3,max_df=.9,max_features=20000); X=vec.fit_transform(sub.model_text.str.replace(r'^passage:\s*','',regex=True)); v=np.array(vec.get_feature_names_out()); ll=labels[ix]
      df=np.asarray((X>0).sum(0)).ravel()
      for t in range(k):
       mask=ll==t; cnt=np.asarray(X[mask].sum(0)).ravel();
       if cnt.sum()==0: continue
       sc=(cnt/cnt.sum())*np.log(1+max(cnt.sum()/max(k,1),1)/np.maximum(df,1)); order=np.argsort(-sc)[:20]
       for r,j in enumerate(order,1): rows.append({'topic':t,'topic_code':f'T{t:02d}','language':lang,'rank':r,'term':v[j],'ctfidf_weight':float(sc[j]),'language_n_in_topic':int(mask.sum())})
    return pd.DataFrame(rows)

def corrected_heritage(d,labs,tm,k):
    counts=d.assign(topic=labs).groupby(['topic','topic_source']).size().unstack(fill_value=0); zh={t:g.term.tolist() for t,g in tm[tm.language=='zh'].groupby('topic')}; en={t:g.term.tolist() for t,g in tm[tm.language=='en'].groupby('topic')}; zkeys=['非遗','传承','物质文化遗产','工艺美术','书法','陶瓷','纹样']; ekeys=['virtual','museum','visitor','exhibition','damage','detection','conservation','deterioration','vr']; rows=[]; zc=[]; ec=[]
    for t,ws in zh.items():
      cn=int(counts.loc[t].get('ZH',0)) if t in counts.index else 0; en_n=int(counts.loc[t].get('EN',0)) if t in counts.index else 0; hits=sorted(set(q for q in zkeys if any(q in str(w) for w in ws))); 
      if len(hits)>=2 and cn/(cn+en_n or 1)>.6: zc.append((t,hits,cn,en_n,ws))
    for t,ws in en.items():
      cn=int(counts.loc[t].get('ZH',0)) if t in counts.index else 0; en_n=int(counts.loc[t].get('EN',0)) if t in counts.index else 0; hits=sorted(set(q for q in ekeys if any(q in str(w).lower() for w in ws)));
      if len(hits)>=2 and en_n/(cn+en_n or 1)>.6: ec.append((t,hits,cn,en_n,ws))
    for z in zc:
      for e in ec:
       rows.append({'k':k,'corrected_heritage_split':z[0]!=e[0],'ZH_topic':f'T{z[0]:02d}','ZH_hits':'; '.join(z[1]),'ZH_CNKI_n':z[2],'ZH_WoS_n':z[3],'ZH_top20':'; '.join(z[4]),'EN_topic':f'T{e[0]:02d}','EN_hits':'; '.join(e[1]),'EN_CNKI_n':e[2],'EN_WoS_n':e[3],'EN_top20':'; '.join(e[4]),'criterion':'ZH >=2 revised cues and CNKI>60%; EN >=2 practice-scene cues and WoS>60%'})
    if not rows: rows=[{'k':k,'corrected_heritage_split':False,'ZH_topic_candidates':'; '.join(f'T{x[0]:02d}' for x in zc),'EN_topic_candidates':'; '.join(f'T{x[0]:02d}' for x in ec),'criterion':'ZH >=2 revised cues and CNKI>60%; EN >=2 practice-scene cues and WoS>60%'}]
    return pd.DataFrame(rows)

def main():
 d=load(); raw=np.load(EMB); assert raw.shape==(1427,1024); raw=raw.astype('float64'); centered=raw-raw.mean(axis=0,keepdims=True); from sklearn.decomposition import PCA; pca=PCA(n_components=3,random_state=42); pcs=pca.fit_transform(centered); residual=centered-pca.inverse_transform(pcs); x=normalize(residual); np.save(OUT/'embeddings_postprocessed_allbuttop3.npy',x.astype('float32')); um=UMAP(n_neighbors=100,n_components=10,min_dist=0,metric='cosine',random_state=42,low_memory=True).fit_transform(x).astype('float32'); np.save(OUT/'umap_10d_l2.npy',um); d.to_csv(OUT/'Corpus_Master.csv',index=False,encoding='utf-8-sig')
 grid=[]; allterms={}; allshares={}; allherit={}; bases={}
 for k in KS:
  labs={s:KMeans(n_clusters=k,random_state=s,n_init=30).fit_predict(um) for s in SEEDS}; base=labs[42]; bases[k]=base; cnt=np.bincount(base,minlength=k)
  for s in SEEDS: grid.append({'k':k,'seed':s,'silhouette':float(silhouette_score(um,labs[s])),'ari_vs_seed42':float(adjusted_rand_score(base,labs[s])),'nmi_vs_seed42':float(normalized_mutual_info_score(base,labs[s])),'matched_jaccard_vs_seed42':float(jacc(base,labs[s])),'min_cluster_n':int(np.min(np.bincount(labs[s],minlength=k))),'clusters_n_lt25':int((np.bincount(labs[s],minlength=k)<25).sum())})
  tm=terms(d,base,k); allterms[k]=tm; tm.to_csv(OUT/f'TopTerms_k{k}.csv',index=False,encoding='utf-8-sig'); sh=d.assign(topic=base).groupby(['topic','analysis_group']).size().unstack(fill_value=0).reset_index(); sh['topic_code']=sh.topic.map(lambda z:f'T{z:02d}'); allshares[k]=sh; sh.to_csv(OUT/f'Shares_k{k}.csv',index=False,encoding='utf-8-sig'); h=corrected_heritage(d,base,tm,k); allherit[k]=h; h.to_csv(OUT/f'Heritage_Split_k{k}.csv',index=False,encoding='utf-8-sig')
 g=pd.DataFrame(grid); s42=g[g.seed==42][['k','silhouette']].rename(columns={'silhouette':'silhouette_seed42'}); summ=g[g.seed!=42].groupby('k').agg(mean_ari=('ari_vs_seed42','mean'),min_ari=('ari_vs_seed42','min'),mean_jaccard=('matched_jaccard_vs_seed42','mean'),min_jaccard=('matched_jaccard_vs_seed42','min'),mean_nmi=('nmi_vs_seed42','mean'),min_cluster_n=('min_cluster_n','min'),max_fragments=('clusters_n_lt25','max')).reset_index().merge(s42,on='k'); flags=pd.DataFrame([{'k':k,'heritage_split_corrected':bool(allherit[k].corrected_heritage_split.fillna(False).any())} for k in KS]); summ=summ.merge(flags,on='k'); summ.to_csv(OUT/'K_Selection.csv',index=False,encoding='utf-8-sig'); g.to_csv(OUT/'Stability_Grid.csv',index=False,encoding='utf-8-sig'); rec=summ.sort_values(['heritage_split_corrected','mean_ari','mean_jaccard','silhouette_seed42'],ascending=False).iloc[0]; chosen=int(rec.k); pd.DataFrame([{'recommended_k':chosen,'reason':'Highest stability among corrected heritage-splitting solutions; no seed42 topic has n<25. Silhouette and topic interpretability are reported jointly, not used to force a historical K.'}]).to_csv(OUT/'Recommendation.csv',index=False)
 # selected outputs
 labs=bases[chosen]; d['topic']=labs; d['topic_code']=d.topic.map(lambda z:f'T{z:02d}'); d.to_csv(OUT/'Assignments.csv',index=False,encoding='utf-8-sig'); allterms[chosen].to_csv(OUT/'TopTerms_Selected.csv',index=False,encoding='utf-8-sig'); allshares[chosen].to_csv(OUT/'Shares_Selected.csv',index=False,encoding='utf-8-sig'); allherit[chosen].to_csv(OUT/'Heritage_Split_Selected.csv',index=False,encoding='utf-8-sig')
 meta={'corpus':{'CNKI':896,'WoS':531,'total':1427},'groups':d.analysis_group.value_counts().to_dict(),'embedding_model':'intfloat/multilingual-e5-large','embedding_vectors':str(EMB),'embedding_postprocessing':'global centering, remove first 3 global PCs, then L2 row normalization (language-direction corrected joint model)' ,'umap':{'n_neighbors':100,'n_components':10,'min_dist':0,'metric':'cosine','random_state':42},'kmeans_seeds':SEEDS,'candidate_k':KS,'recommended_k':chosen,'wos_damaged_fields_not_used':['WoS Categories','Research Areas','Document Type','Language','Affiliations']}; (OUT/'Model_Parameters.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8'); print(json.dumps({'recommended_k':chosen,'groups':d.analysis_group.value_counts().to_dict()},ensure_ascii=False))
if __name__=='__main__': main()
