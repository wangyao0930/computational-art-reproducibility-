# Recovered historical source; run only from historical/ after supplying documented inputs.
import pandas as pd, os, json, numpy as np
base='./output/final_rebuild_20260927_1427'
# add a concise report-ready summary and augment topic names/terms
ks=pd.read_csv(os.path.join(base,'K_Selection.csv'),encoding='utf-8-sig')
sel=int(pd.read_csv(os.path.join(base,'Recommendation.csv'),encoding='utf-8-sig').recommended_k.iloc[0])
assign=pd.read_csv(os.path.join(base,'Assignments.csv'),encoding='utf-8-sig',dtype=str).fillna('')
shares=pd.read_csv(os.path.join(base,f'Shares_k{sel}.csv'),encoding='utf-8-sig')
# topic overview with language-side counts and interpretable labels inferred manually from top terms
names={0:('AI绘画与生成式艺术基础','AI painting and generative-art foundations'),1:('数字媒体、影视动画与插画设计','Digital media, film animation and illustration design'),2:('三维重建、点云与图像分析','3D reconstruction, point clouds and image analysis'),3:('传统书法、文化表达与生成叙事','Traditional calligraphy, cultural expression and generative narrative'),4:('音乐与舞蹈生成','Music and dance generation'),5:('图像生成、GAN与风格迁移','Image generation, GANs and style transfer'),6:('AI在艺术设计中的应用','AI applications in art and design'),7:('影视内容生产与提示工程','Film content production and prompt engineering'),8:('绘画图像分类与机器分析','Painting-image classification and machine analysis'),9:('计算美学与艺术创造力','Computational aesthetics and artistic creativity'),10:('博物馆展陈与遗产数字技术','Museum exhibition and digital heritage technologies'),11:('AIGC内容生产与文化产业','AIGC content production and cultural industries'),12:('审美评价与图像质量评估','Aesthetic evaluation and image-quality assessment'),13:('数字艺术经济、NFT与元宇宙','Digital-art economy, NFTs and the metaverse'),14:('舞蹈生成与动作编排','Dance generation and choreography')}
t=pd.read_csv(os.path.join(base,f'TopTerms_k{sel}.csv'),encoding='utf-8-sig')
rows=[]
for i in range(sel):
 s=shares[shares.topic==i].iloc[0] if len(shares[shares.topic==i]) else None
 zh=int(s.ZH) if s is not None else 0; ecn=int(s['EN-CN']) if s is not None else 0; enc=int(s['EN-NC']) if s is not None else 0
 z=t[(t.topic==i)&(t.language=='zh')].term.head(20).tolist(); e=t[(t.topic==i)&(t.language=='en')].term.head(20).tolist(); low=[]
 if zh<15: low.append('ZH low-n, not interpretable')
 if ecn+enc<15: low.append('EN low-n, not interpretable')
 rows.append({'topic_code':f'T{i:02d}','topic_name_zh':names[i][0],'topic_name_en':names[i][1],'ZH_n':zh,'EN_CN_n':ecn,'EN_NC_n':enc,'total_n':zh+ecn+enc,'top20_zh':'; '.join(z),'top20_en':'; '.join(e),'term_interpretability_flag':'; '.join(low) or 'interpretable on both sides'})
ov=pd.DataFrame(rows); ov.to_csv(os.path.join(base,'Topic_Overview_Selected.csv'),index=False,encoding='utf-8-sig')
# match old outputs for new report list
meta={'new_corpus':{'CNKI':896,'WoS':531,'total':1427},'groups':{'ZH':896,'EN-CN':243,'EN-NC':288},'old_1429_excluded_wos':['WOS:001060595700004','WOS:001130364400005'],'selected_k':sel,'model':'multilingual-E5-large; global center; remove first 3 global PCs; L2; UMAP 100/10/0 cosine seed42; KMeans n_init30','formal_l2_diagnostic':'language-pure clusters for K=8-18; not used as substantive shared-topic solution','corrected_candidate_selection':'K=15: mean ARI 0.980630, min cluster n 34, corrected heritage split True; K=13 also splits heritage, mean ARI 0.974714','legacy_translation_summary':'ARI 0.299778; mixed topics 9; minority share 0.191043'}
open(os.path.join(base,'new_model_metadata.json'),'w',encoding='utf-8').write(json.dumps(meta,ensure_ascii=False,indent=2))
print(ov.to_string(index=False))
