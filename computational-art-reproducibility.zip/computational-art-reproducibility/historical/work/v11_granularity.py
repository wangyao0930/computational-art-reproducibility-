# Recovered historical source; run only from historical/ after supplying documented inputs.
import os
os.environ.setdefault('OMP_NUM_THREADS','4')
from v11_common import *
from sklearn.cluster import KMeans
from threadpoolctl import threadpool_limits
from run_phase_f import coherence_for_language,normalize_term

def prior_table(name):
    obj=json.loads((BASE/'phase_f_payload.json').read_text(encoding='utf-8'))[name]
    return pd.DataFrame(obj['rows'],columns=obj['columns'])

def main():
    from umap import UMAP
    import joblib
    d,f=load();d['text']=d.title+'。'+d.abstract
    x=np.load(FINAL/'embeddings_postprocessed_allbuttop3.npy').astype(np.float32)
    U0=np.load(FINAL/'umap_10d_l2.npy').astype(np.float32)
    refs={k:KMeans(k,n_init=30,random_state=42).fit_predict(U0) for k in [13,17]}
    rows=[];assignment=[];coherence=[];cohs=[]
    # Preserve the exact historical F1 protocol for appending K=13 and K=17:
    # seed42 saved original coordinates; other seeds refit saved float32 post vectors.
    for seed in SEEDS:
        if seed==42:u=U0
        else:
            um=UMAP(n_neighbors=100,n_components=10,min_dist=0,metric='cosine',random_state=seed,low_memory=True)
            u=um.fit_transform(x).astype(np.float32)
            joblib.dump(um,ART/f'F1_legacy_pp_seed{seed}_umap.joblib',compress=3)
        for k in [13,17]:
            km=KMeans(k,n_init=30,random_state=seed).fit(u);lab=km.labels_
            np.save(ART/f'F1_k{k}_seed{seed}_centers.npy',km.cluster_centers_)
            np.save(ART/f'F1_k{k}_seed{seed}_labels.npy',lab)
            rows.append(dict(k=k,seed=seed,umap_seed=seed,kmeans_seed=seed,ARI_vs_seed42=float(adjusted_rand_score(refs[k],lab)),NMI_vs_seed42=float(normalized_mutual_info_score(refs[k],lab)),min_cluster_n=int(np.bincount(lab,minlength=k).min()),clusters_n_lt25=int((np.bincount(lab,minlength=k)<25).sum()),method='v9 F1 exact protocol: seed42 saved coordinates, other seeds saved float32 postprocessed embeddings; KMeans n_init30'))
            assignment.extend(dict(k=k,seed=seed,doc_id=doc,cluster=int(l)) for doc,l in zip(d.doc_id,lab))
        print(f'F1 K13/K17 seed {seed} complete',flush=True)
    for k in [13,17]:
        tt=pd.read_csv(FINAL/f'TopTerms_k{k}.csv',encoding='utf-8-sig');tt['term_norm']=tt.term.map(normalize_term)
        for lang in ['zh','en']:
            rr,s=coherence_for_language(k,lang,d,refs[k],tt);coherence+=rr;cohs.append(s)
    old=prior_table('F1_Stability_10seed');full=pd.concat([old[~old.k.isin([13,17])],pd.DataFrame(rows)],ignore_index=True).sort_values(['k','seed'])
    summ=full.groupby('k').agg(ARI_mean=('ARI_vs_seed42','mean'),ARI_min=('ARI_vs_seed42','min'),ARI_q25=('ARI_vs_seed42',lambda x:float(x.quantile(.25))),ARI_median=('ARI_vs_seed42','median'),ARI_q75=('ARI_vs_seed42',lambda x:float(x.quantile(.75))),min_cluster_n_min=('min_cluster_n','min'),max_clusters_n_lt25=('clusters_n_lt25','max')).reset_index()
    save('F1_Stability_10seed',full);save('F1_Stability_Summary',summ);save('F1_New_Assignments',assignment)
    # Identify exact old payload names before appending, rather than presume a schema.
    payload=json.loads((BASE/'phase_f_payload.json').read_text('utf-8'))
    detailname=next(n for n in payload if n.startswith('F1_Coherence') and any(c in payload[n]['columns'] for c in ['n_docs']))
    summaryname=next(n for n in payload if n.startswith('F1_Coherence') and 'cv_mean' in payload[n]['columns'])
    dt=pd.concat([prior_table(detailname),pd.DataFrame(coherence)],ignore_index=True)
    sm=pd.concat([prior_table(summaryname),pd.DataFrame(cohs)],ignore_index=True)
    save(detailname,dt);save(summaryname,sm)
    grid=[]
    for k,sub in dt.groupby('k'):
        weights=pd.to_numeric(sub.n_docs)
        grid.append(dict(k=int(k),c_v_weighted=float(np.average(pd.to_numeric(sub.c_v),weights=weights)),NPMI_weighted=float(np.average(pd.to_numeric(sub.NPMI),weights=weights)),valid_topic_language_rows=len(sub),is_requested_grid=int(k) in [8,10,12,14,16,18],is_k15=int(k)==15,is_added_v11=int(k) in [13,17]))
    save('F1_K15_vs_Grid',grid)
    save('F1_Method',[dict(item='stability comparability',detail='Appended K13/K17 use exact v9 F1 float32 input and seed42 reference. Task8 uses v11 deterministic full SVD, so F1 seed42 is a historical reference, not Task8 seed42.'),dict(item='coherence',detail='Frozen original K-specific c-TF-IDF top10; same saved seed42 UMAP and KMeans labels. Language-side n>=15; gensim c_v and c_npmi; original tokenizer/windows retained.'),dict(item='low-n',detail='Language-side n<15 excluded from coherence and not interpretable for naming.')])
    manifest();status('Task6','PASS','K13/K17: 20 fits appended to historical F1; c_v/NPMI added for both languages with n>=15. Historical seed42 coordinate provenance explicit.')

if __name__=='__main__':
    with threadpool_limits(limits=4):guarded('Task6',main)
