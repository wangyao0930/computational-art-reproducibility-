# Recovered historical source; run only from historical/ after supplying documented inputs.
"""Shared, auditable v11 definitions. Frozen labels are read-only."""
from pathlib import Path
import os, sys, json, hashlib, traceback
import numpy as np
import pandas as pd
from scipy.stats import beta, fisher_exact, contingency
from scipy.spatial.distance import jensenshannon
from scipy.optimize import linear_sum_assignment
from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT/'outputs/rerun_1427_k15'
OUT = BASE/'v11'
TABLES = OUT/'tables'
ART = OUT/'artifacts'
for p in (OUT,TABLES,ART): p.mkdir(parents=True,exist_ok=True)
FINAL = ROOT/'output/final_rebuild_20260927_1427'
SOURCE = FINAL/'computational_art_final_rebuild_1427.xlsx'
SEEDS = [42,7,123,2024,999,17,21,33,55,77]
VALUE = [0,3,13]
TECH = [2,5,8,12]
PAIRS = [('ZH','EN'),('ZH','EN-CN'),('ZH','EN-NC'),('EN-CN','EN-NC')]

def save(name, data):
    d = data if isinstance(data,pd.DataFrame) else pd.DataFrame(data)
    d.to_csv(TABLES/f'{name}.csv',index=False,encoding='utf-8-sig')
    (TABLES/f'{name}.json').write_text(d.to_json(orient='split',force_ascii=False,index=False),encoding='utf-8')
    return d

def status(task, code, detail):
    p=OUT/'status.json'
    rows=json.loads(p.read_text('utf-8')) if p.exists() else []
    rows=[r for r in rows if r['task']!=task]
    rows.append(dict(task=task,status=code,detail=detail))
    p.write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
    save('Status',rows)
    print(f'{task}: {code}: {detail}',flush=True)

def load():
    d=pd.read_excel(SOURCE,sheet_name='Corpus_Master',dtype=str,keep_default_na=False)
    d.columns=d.columns.str.replace('\ufeff','')
    assert len(d)==1427 and d.doc_id.is_unique
    assert d.analysis_group.value_counts().to_dict()=={'ZH':896,'EN-NC':288,'EN-CN':243}
    assert set(d.topic_code)=={f'T{i:02d}' for i in range(15)}
    a=pd.read_csv(FINAL/'Assignments.csv',dtype=str,keep_default_na=False)
    assert d.doc_id.tolist()==a.doc_id.tolist() and d.topic_code.tolist()==a.topic_code.tolist()
    assert (d.model_text=='passage: '+d.title+'. '+d.abstract).all()
    return d,np.array([int(t[1:]) for t in d.topic_code])

def mask(d,g):
    return d.analysis_group.ne('ZH').to_numpy() if g=='EN' else d.analysis_group.eq(g).to_numpy()

def cp(k,n):
    return (0. if k==0 else float(beta.ppf(.025,k,n-k+1)),1. if k==n else float(beta.ppf(.975,k+1,n-k)))

def test(a,b):
    t=np.array([[sum(a),len(a)-sum(a)],[sum(b),len(b)-sum(b)]],dtype=int)
    r=contingency.odds_ratio(t,kind='conditional'); ci=r.confidence_interval()
    return dict(numerator_a=int(sum(a)),denominator_a=len(a),numerator_b=int(sum(b)),denominator_b=len(b),OR=float(r.statistic),OR_low=float(ci.low),OR_high=float(ci.high),Fisher_p=float(fisher_exact(t).pvalue))

def sep(a,b,k=15):
    ca=np.bincount(a,minlength=k); cb=np.bincount(b,minlength=k)
    rho=float(np.minimum(ca,cb).sum()/(len(a)+len(b)))
    rand=min(len(a),len(b))/(len(a)+len(b))
    return dict(rho=rho,rho_rand=rand,S=1-rho/rand,JSD=float(jensenshannon(ca/ca.sum(),cb/cb.sum(),base=2)**2))

def align(frozen,labels):
    assert len(frozen)==len(labels)==1427
    cm=np.zeros((15,15),int); np.add.at(cm,(frozen,labels),1)
    r,c=linear_sum_assignment(-cm)
    m=dict(zip(c,r)); mapped=np.array([m[t] for t in labels])
    rows=[dict(cluster=int(j),frozen_topic=f'T{i:02d}',overlap_n=int(cm[i,j]),Jaccard=float(cm[i,j]/((frozen==i).sum()+(labels==j).sum()-cm[i,j]))) for i,j in zip(r,c)]
    return mapped,rows

def comparisons(d, frozen, labels, mapped):
    return [dict(subset=g,raw_agreement=float((frozen[m]==labels[m]).mean()),aligned_agreement=float((frozen[m]==mapped[m]).mean()),ARI=float(adjusted_rand_score(frozen[m],labels[m])),NMI=float(normalized_mutual_info_score(frozen[m],labels[m]))) for g,m in [('ALL',np.ones(len(d),bool)),('ZH',mask(d,'ZH')),('EN',mask(d,'EN'))]]

def metrics(d, labels, mapped):
    vals={}
    for a,b in PAIRS:
        for key,v in sep(labels[mask(d,a)],labels[mask(d,b)]).items(): vals[f'{key}_{a}_vs_{b}']=v
    vals['D']=vals['JSD_ZH_vs_EN-CN']-vals['JSD_ZH_vs_EN-NC']
    counts=np.bincount(labels,minlength=15); zh=np.bincount(labels[mask(d,'ZH')],minlength=15)
    vals['ZH_majority_clusters']=int((zh/counts>.5).sum())
    for axis,topics in [('VALUE',VALUE),('TECH',TECH)]:
        for g in ['ZH','EN','EN-CN','EN-NC']:
            m=mask(d,g); n=int(np.isin(mapped[m],topics).sum()); den=int(m.sum()); lo,hi=cp(n,den)
            for key,v in dict(n=n,denominator=den,share=n/den,CI_low=lo,CI_high=hi).items(): vals[f'{axis}_{g}_{key}']=v
    for a,b in [('ZH','EN'),('EN-CN','EN-NC')]:
        for key,v in test(np.isin(mapped[mask(d,a)],VALUE),np.isin(mapped[mask(d,b)],VALUE)).items(): vals[f'VALUE_{a}_vs_{b}_{key}']=v
    dominant=np.where(zh/counts>=.9)[0]
    for g in ['EN-CN','EN-NC']:
        m=mask(d,g); n=int(np.isin(labels[m],dominant).sum()); lo,hi=cp(n,int(m.sum()))
        for key,v in dict(n=n,denominator=int(m.sum()),share=n/m.sum(),CI_low=lo,CI_high=hi).items(): vals[f'DATADRIVEN_{g}_{key}']=v
    for key,v in test(np.isin(labels[mask(d,'EN-CN')],dominant),np.isin(labels[mask(d,'EN-NC')],dominant)).items(): vals[f'DATADRIVEN_EN-CN_vs_EN-NC_{key}']=v
    vals['strict_voids_2pct']=sum(cp(int(n),int(mask(d,g).sum()))[1]<.02 for g in ['ZH','EN-CN','EN-NC'] for n in np.bincount(labels[mask(d,g)],minlength=15))
    return vals

def post_fit(raw):
    raw=np.asarray(raw,dtype=np.float64); mean=raw.mean(0); centered=raw-mean
    _,_,v=np.linalg.svd(centered,full_matrices=False)
    pcs=v[:3].copy()
    # Resolve SVD sign ambiguity deterministically; projection itself is sign invariant.
    pcs*=np.where(pcs[np.arange(3),np.abs(pcs).argmax(1)]<0,-1,1)[:,None]
    return post_transform(raw,mean,pcs),mean,pcs

def post_transform(raw,mean,pcs):
    c=np.asarray(raw,dtype=np.float64)-mean
    x=c-(c@pcs.T)@pcs
    return x/np.linalg.norm(x,axis=1,keepdims=True)

def fit_cluster(x,seed,prefix,k=15):
    from umap import UMAP
    from sklearn.cluster import KMeans
    import joblib
    stem=ART/f'{prefix}_seed{seed}'
    um=UMAP(n_neighbors=100,n_components=10,min_dist=0,metric='cosine',random_state=seed,low_memory=True)
    u=um.fit_transform(x).astype(np.float32)
    km=KMeans(n_clusters=k,n_init=30,random_state=seed).fit(u)
    joblib.dump(um,str(stem)+'_umap.joblib',compress=3)
    np.save(str(stem)+'_coordinates.npy',u)
    np.save(str(stem)+'_centers.npy',km.cluster_centers_)
    np.save(str(stem)+'_labels.npy',km.labels_)
    return km.labels_,u

def sha(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()

def manifest():
    rows=[dict(path=str(p.resolve()),sha256=sha(p),bytes=p.stat().st_size,description=p.stem) for p in sorted(ART.glob('*')) if p.is_file()]
    save('Artifacts_Manifest',rows)

def guarded(task,fn):
    try: fn()
    except Exception:
        err=traceback.format_exc(); (OUT/f'{task}_error.txt').write_text(err,encoding='utf-8'); status(task,'CHECK',err)

