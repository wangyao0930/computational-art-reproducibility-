# Recovered historical source; run only from historical/ after supplying documented inputs.
# -*- coding: utf-8 -*-
"""Merge WoS .xls batches and perform conservative, auditable screening."""
from __future__ import annotations

import glob
import json
import os
import re
from pathlib import Path

import pandas as pd


ROOT = Path(__file__).resolve().parent
SOURCE_ROOT = ROOT / "source_batches"
OUT = ROOT / "processed"
OUT.mkdir(parents=True, exist_ok=True)

REQUIRED = ["Article Title", "Abstract", "Author Keywords"]

# Phrases that identify an art object, art practice, or art-specific aesthetic
# question. Generic "art", "artist", "literature", and "state-of-the-art"
# are intentionally excluded because they create systematic false positives.
ART_CORE = [
    r"\bcomputational art\b", r"\balgorithmic art\b", r"\bgenerative art\b",
    r"\bcomputer art\b", r"\bmachine art\b", r"\bneural art\b",
    r"\bai art\b", r"\bartificial intelligence art\b", r"\bcomputer[- ]generated art\b",
    r"\bmachine[- ]generated art\b", r"\balgorithmic aesthetic", r"\bcomputational aesthetic",
    r"\bdigital art\b", r"\belectronic art\b", r"\bnew media art\b",
    r"\bmedia art\b", r"\bvisual arts?\b", r"\bfine art\b", r"\bartwork", r"\bartistic creation",
    r"\bpainting", r"\bsculpture", r"\bmusic composition", r"\bpoetry", r"\bcalligraph",
    r"\bdance", r"\bchoreograph", r"\bfilm art", r"\bcinema art", r"\bmuseum collection",
    r"\bart history", r"\bart authentication", r"\bart education", r"\bart teaching",
    r"\bart design", r"\bart production", r"\bcreative industr", r"\bcreative practice",
    r"\baesthetic assessment", r"\baesthetic evaluation", r"\baesthetic quality", r"\baesthetic experience",
    r"\bcultural heritage", r"\bheritage conservation",
    r"艺术", r"美学", r"艺术创作", r"视觉艺术", r"艺术设计", r"非遗", r"文化遗产", r"文博",
]
CORE_OBJECT = ART_CORE[:16] + [
    r"\bcreative ai\b", r"\bai[- ]generated artwork", r"\bart generation\b",
    r"\bai painting\b", r"\bmachine creativity\b", r"\bcomputational creativity\b",
]
TECH = [
    r"\bcomputational\b", r"\balgorithm", r"\bcomputer[- ]generated\b", r"\bmachine[- ]generated\b",
    r"\bmachine learning\b", r"\bdeep learning\b", r"\bneural network", r"\bgenerative\b",
    r"\bgenerative ai\b", r"\bgenerative artificial intelligence\b", r"\bartificial intelligence\b",
    r"\btext[- ]to[- ]image\b", r"\bdiffusion model", r"\bgenerative adversarial\b", r"\bGAN\b",
    r"\btransformer", r"\bdeep generative\b", r"\bAI\b", r"人工智能", r"生成式", r"生成艺术",
    r"计算", r"算法", r"机器学习", r"深度学习", r"神经网络", r"扩散模型", r"文生图", r"AIGC",
]
NON_ART_CONTEXT = [
    r"\bclinical\b", r"\bdisease\b", r"\bdiagnos", r"\bcancer\b", r"\bpatient\b", r"\bmedical\b",
    r"\bhealthcare\b", r"\bneuroimaging\b", r"\bmagnetic resonance\b", r"\bremote sensing\b",
    r"\btraffic\b", r"\bmanufactur", r"\bindustrial\b", r"\bautonomous vehicle\b", r"\bprotein\b",
    r"\bdrug\b", r"\bagriculture\b", r"\bgeolog", r"\bfinancial\b", r"\bsupply chain\b",
    r"\bcybersecurity\b", r"\bmalware\b", r"\bsoftware testing\b", r"\bwireless\b", r"\bantenna\b",
    r"\bpower system\b", r"\bwind turbine\b", r"\bair quality\b", r"\bseismic\b", r"\bdiabetic\b",
    r"医学", r"临床", r"疾病", r"诊断", r"癌症", r"医疗", r"遥感", r"制造", r"交通", r"农业",
]
APPLIED_CONTEXT = [
    r"\btherapy\b", r"\bdepression\b", r"\bdyslexia\b", r"\beye movement", r"\bpatient\b",
    r"\bvisitor experience", r"\bsentiment analysis", r"\bservice quality", r"\brecommendation",
    r"\btourism\b", r"\bmarketing\b", r"\beducation\b", r"\bteaching\b", r"\btraining\b",
    r"\bstudent\b", r"\bpedagog", r"\belderly\b", r"\bmental health", r"\bbrain[- ]computer interface",
    r"治疗", r"抑郁", r"教育", r"教学", r"学生", r"推荐", r"旅游", r"服务质量", r"情感分析",
]


def clean(v: object) -> str:
    if v is None:
        return ""
    s = str(v).replace("\u00a0", " ").strip()
    return "" if s.lower() in {"nan", "none", "n/a", "na", "null", "-", "—"} else s


def hits(text: str, patterns: list[str]) -> list[str]:
    out = []
    for p in patterns:
        if re.search(p, text, flags=re.I):
            out.append(p.replace(r"\b", "").replace("\\", ""))
    return out


def record_key(row: pd.Series) -> str:
    for col in ["UT (Unique WOS ID)", "DOI"]:
        val = clean(row.get(col, "")).lower()
        if val:
            return f"{col}:{val}"
    title = re.sub(r"\W+", " ", clean(row.get("Article Title", "")).lower()).strip()
    year = clean(row.get("Publication Year", ""))
    return f"TITLE:{title}|YEAR:{year}"


def classify(row: pd.Series) -> tuple[str, str, str, int, int, int]:
    title = clean(row.get("Article Title", ""))
    abstract = clean(row.get("Abstract", ""))
    keywords = clean(row.get("Author Keywords", ""))
    if re.search(r"\bretracted\b|撤稿", title, flags=re.I):
        return "exclude", "retracted_record", "retracted", 0, 0, 0
    if not abstract:
        return "exclude", "missing_abstract", "", 0, 0, 0
    if not keywords:
        return "exclude", "missing_author_keywords", "", 0, 0, 0
    full = " ".join([title, abstract, keywords])
    title_hits = hits(title, ART_CORE)
    context_hits = hits(" ".join([abstract, keywords]), ART_CORE)
    tech_hits = hits(full, TECH)
    non_art_hits = hits(full, NON_ART_CONTEXT)
    applied_hits = hits(full, APPLIED_CONTEXT)
    # Generic art/creative terms are only sufficient when paired with a
    # computational term and a reasonably direct art-making/aesthetic context.
    strong_title = any(re.search(p, title, flags=re.I) for p in ART_CORE)
    direct_title = any(re.search(p, title, flags=re.I) for p in ART_CORE[:24])
    core_title = hits(title, CORE_OBJECT)
    core_anywhere = hits(full, CORE_OBJECT)
    specific_context = any(
        re.search(p, " ".join([abstract, keywords]), flags=re.I)
        for p in ART_CORE[6:]
    )
    if core_title and tech_hits and not applied_hits and not non_art_hits:
        return "include", "direct_art_and_computation", "; ".join(title_hits + tech_hits), len(title_hits), len(tech_hits), len(non_art_hits)
    if core_title and tech_hits:
        return "review", "core_art_term_in_applied_context", "; ".join(title_hits + tech_hits + applied_hits + non_art_hits), len(title_hits), len(tech_hits), len(non_art_hits)
    if core_anywhere and tech_hits and not applied_hits and not non_art_hits:
        return "include", "direct_art_and_computation", "; ".join(context_hits + tech_hits), len(context_hits), len(tech_hits), len(non_art_hits)
    if core_anywhere and tech_hits:
        return "review", "core_art_term_in_applied_context", "; ".join(context_hits + tech_hits + applied_hits + non_art_hits), len(context_hits), len(tech_hits), len(non_art_hits)
    if strong_title and not tech_hits:
        return "review", "art_term_without_explicit_computation", "; ".join(title_hits), len(title_hits), 0, len(non_art_hits)
    if context_hits and tech_hits and specific_context and not non_art_hits and not applied_hits:
        return "include", "art_context_and_computation", "; ".join(context_hits + tech_hits), len(context_hits), len(tech_hits), 0
    if context_hits and tech_hits:
        return "review", "art_and_computation_with_non_art_context", "; ".join(context_hits + tech_hits + non_art_hits), len(context_hits), len(tech_hits), len(non_art_hits)
    return "exclude", "no_direct_computational_art_context", "; ".join(context_hits + tech_hits), len(context_hits), len(tech_hits), len(non_art_hits)


def main() -> None:
    files = sorted(Path(p) for p in glob.glob(str(SOURCE_ROOT / "**" / "*.xls"), recursive=True))
    frames: list[pd.DataFrame] = []
    file_stats = []
    for path in files:
        try:
            df = pd.read_excel(path, engine="xlrd", dtype=str, keep_default_na=False)
        except Exception as exc:  # keep an auditable record of unreadable files
            file_stats.append({"file": str(path), "rows": 0, "error": repr(exc)})
            continue
        df = df.fillna("")
        df["Source Batch"] = path.parts[-2] if len(path.parts) >= 2 else "unknown"
        df["Source File"] = path.name
        frames.append(df)
        file_stats.append({"file": str(path), "rows": int(len(df)), "error": ""})
    if not frames:
        raise RuntimeError("No readable .xls files found")
    all_cols = list(dict.fromkeys(c for df in frames for c in df.columns))
    merged = pd.concat([df.reindex(columns=all_cols) for df in frames], ignore_index=True).fillna("")
    merged["Record Key"] = merged.apply(record_key, axis=1)
    # Keep a deterministic first occurrence while retaining the number of
    # source hits for later audit.
    source_hits = merged.groupby("Record Key")["Source File"].agg(lambda x: "; ".join(sorted(set(map(str, x))))).rename("Source Files")
    merged = merged.drop_duplicates("Record Key", keep="first").copy()
    merged = merged.merge(source_hits, left_on="Record Key", right_index=True, how="left")
    results = merged.apply(classify, axis=1, result_type="expand")
    results.columns = ["Screen Decision", "Screen Reason", "Matched Terms", "Art Hit Count", "Tech Hit Count", "Non-art Hit Count"]
    merged = pd.concat([merged, results], axis=1)
    included = merged[merged["Screen Decision"] == "include"].copy()
    review = merged[merged["Screen Decision"] == "review"].copy()
    excluded = merged[merged["Screen Decision"] == "exclude"].copy()
    # Put review and exclusion reasons first in the audit table.
    audit_cols = ["Record Key", "Screen Decision", "Screen Reason", "Matched Terms", "Source Batch", "Source File", "Source Files", "Article Title", "Abstract", "Author Keywords", "Publication Year", "DOI", "UT (Unique WOS ID)"]
    audit_cols = [c for c in audit_cols if c in merged.columns]
    # Full merged/deduplicated table is kept separately so the cleaned
    # workbook remains usable while the complete source merge stays available.
    merged.to_csv(OUT / "merged_deduplicated.csv", index=False, encoding="utf-8-sig")
    included.to_csv(OUT / "included.csv", index=False, encoding="utf-8-sig")
    review[audit_cols].to_csv(OUT / "manual_review.csv", index=False, encoding="utf-8-sig")
    excluded[audit_cols].to_csv(OUT / "excluded.csv", index=False, encoding="utf-8-sig")
    summary = {
        "source_files_found": len(files),
        "source_files_read": len(frames),
        "source_file_errors": [x for x in file_stats if x["error"]],
        "raw_rows": int(sum(len(df) for df in frames)),
        "unique_records": int(len(merged)),
        "included_rows": int(len(included)),
        "manual_review_rows": int(len(review)),
        "excluded_rows": int(len(excluded)),
        "exclusion_reasons": {str(k): int(v) for k, v in excluded["Screen Reason"].value_counts().items()},
        "review_reasons": {str(k): int(v) for k, v in review["Screen Reason"].value_counts().items()},
        "required_fields": REQUIRED,
        "rule_note": "Retain only records with title, abstract, author keywords, and a direct computational-art context; borderline records are not included and remain in manual_review.csv.",
    }
    (OUT / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    (OUT / "file_stats.json").write_text(json.dumps(file_stats, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
