# Recovered historical source; run only from historical/ after supplying documented inputs.
import pandas as pd, numpy as np, re, unicodedata, collections, itertools, time
import networkx as nx
m=pd.read_pickle('master.pkl')

def norm_kw(k, lang):
    k=unicodedata.normalize('NFKC',k).strip()
    k=re.sub(r'[\(（][^\)）]*[\)）]','',k)   # 去括号内缩写
    k=k.lower().replace('-',' ').replace('_',' ')
    k=re.sub(r'\s+',' ',k).strip(' .;,:"\'“”')
    if lang=='en':
        w=k.split(' ')
        last=w[-1]
        if len(last)>3 and last.endswith('s') and not last.endswith(('ss','is','us','ics')):
            w[-1]=last[:-1]
        k=' '.join(w)
    return k

def doc_keywords(row):
    lang='zh' if row.source=='CNKI' else 'en'
    raw=re.split(r';;|;|；',str(row.keywords))
    out=[]
    for r in raw:
        if not r.strip(): continue
        n=norm_kw(r,lang)
        if n and n not in out: out.append(n)
    return out, [r.strip() for r in raw if r.strip()]

m['kw_norm']=None; m['kw_raw']=None
kn=[];kr=[]
for _,r in m.iterrows():
    a,b=doc_keywords(r); kn.append(a); kr.append(b)
m['kw_norm']=kn; m['kw_raw']=kr
m.to_pickle('kw.pkl')
for g,mask in {'ZH':m.group=='ZH','EN':m.source!='CNKI','EN-CN':m.group=='EN-CN','EN-NC':m.group=='EN-NC'}.items():
    docs=m[mask].kw_norm.tolist()
    f=collections.Counter(k for d in docs for k in d)
    print(g,len(docs),'unique',len(f),'f>=2',sum(v>=2 for v in f.values()),'f>=3',sum(v>=3 for v in f.values()),'mean kw/doc',np.mean([len(d) for d in docs]).round(2))
    print('  top',f.most_common(12))
