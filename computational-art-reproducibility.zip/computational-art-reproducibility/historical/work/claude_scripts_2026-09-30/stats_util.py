# Recovered historical source; run only from historical/ after supplying documented inputs.
import numpy as np
from scipy import stats


def cp_ci(k, n, alpha=0.05):
    if n == 0:
        return (np.nan, np.nan)
    lo = 0.0 if k == 0 else stats.beta.ppf(alpha / 2, k, n - k + 1)
    hi = 1.0 if k == n else stats.beta.ppf(1 - alpha / 2, k + 1, n - k)
    return lo, hi


def ci_str(k, n, digits=1):
    lo, hi = cp_ci(k, n)
    if np.isnan(lo):
        return '—'
    return f'{lo*100:.{digits}f}–{hi*100:.{digits}f}'


def fisher(a, b, c, d):
    """a/b = 组1 阳/阴，c/d = 组2 阳/阴。返回条件 MLE OR、95% 精确区间、双侧 p。"""
    res = stats.contingency.odds_ratio([[a, b], [c, d]], kind='conditional')
    ci = res.confidence_interval(0.95)
    p = stats.fisher_exact([[a, b], [c, d]])[1]
    return res.statistic, ci.low, ci.high, p


def mh(strata):
    """strata: list of (a,b,c,d)，a=组1阳 b=组1阴 c=组2阳 d=组2阴。
    返回 MH OR、RBG 95% 区间、CMH 卡方 p（含与不含连续性校正）。"""
    R = S = 0.0
    PR = PS_QR = QS = 0.0
    sumA = sumE = sumV = 0.0
    for a, b, c, d in strata:
        n = a + b + c + d
        if n <= 1:
            continue
        r = a * d / n
        s = b * c / n
        P = (a + d) / n
        Q = (b + c) / n
        R += r
        S += s
        PR += P * r
        PS_QR += P * s + Q * r
        QS += Q * s
        n1 = a + b
        n2 = c + d
        m1 = a + c
        m2 = b + d
        sumA += a
        sumE += n1 * m1 / n
        sumV += n1 * n2 * m1 * m2 / (n * n * (n - 1))
    orr = R / S if S > 0 else np.inf
    var = PR / (2 * R * R) + PS_QR / (2 * R * S) + QS / (2 * S * S)
    se = np.sqrt(var)
    lo, hi = np.exp(np.log(orr) - 1.959964 * se), np.exp(np.log(orr) + 1.959964 * se)
    chi_cc = (abs(sumA - sumE) - 0.5) ** 2 / sumV
    chi = (sumA - sumE) ** 2 / sumV
    return dict(OR=orr, lo=lo, hi=hi, p_cmh_cc=stats.chi2.sf(chi_cc, 1), p_cmh=stats.chi2.sf(chi, 1), A=sumA, E=sumE, V=sumV)


def strat_perm_p(y, g, s, reps=10000, seed=42):
    """层内置换组标签：统计量 = Σ_层 组1阳性数（与 CMH 同一充分统计量），双侧 p（以 |A−E| 计）。"""
    rng = np.random.default_rng(seed)
    y = np.asarray(y); g = np.asarray(g); s = np.asarray(s)
    E = 0.0
    idx = {}
    for lev in np.unique(s):
        m = s == lev
        idx[lev] = np.where(m)[0]
        E += y[m].sum() * g[m].sum() / m.sum()
    obs = abs((y * g).sum() - E)
    cnt = 0
    gp = g.copy()
    for _ in range(reps):
        for lev, ii in idx.items():
            gp[ii] = rng.permutation(g[ii])
        if abs((y * gp).sum() - E) >= obs - 1e-12:
            cnt += 1
    return (cnt + 1) / (reps + 1)


def logit(X, y, names, max_iter=100):
    """IRLS 逻辑回归；X 不含常数项。返回 dict(name -> (beta, se, OR, lo, hi, p))。"""
    X = np.column_stack([np.ones(len(y)), X]).astype(float)
    y = np.asarray(y, float)
    beta = np.zeros(X.shape[1])
    for _ in range(max_iter):
        eta = X @ beta
        p = 1 / (1 + np.exp(-eta))
        W = p * (1 - p)
        H = X.T @ (X * W[:, None])
        g = X.T @ (y - p)
        step = np.linalg.solve(H, g)
        beta += step
        if np.max(np.abs(step)) < 1e-10:
            break
    p = 1 / (1 + np.exp(-(X @ beta)))
    H = X.T @ (X * (p * (1 - p))[:, None])
    cov = np.linalg.inv(H)
    se = np.sqrt(np.diag(cov))
    out = {}
    for i, nm in enumerate(['const'] + list(names)):
        z = beta[i] / se[i]
        out[nm] = (beta[i], se[i], np.exp(beta[i]), np.exp(beta[i] - 1.959964 * se[i]), np.exp(beta[i] + 1.959964 * se[i]),
                   2 * stats.norm.sf(abs(z)))
    return out
