# Recovered historical source; run only from historical/ after supplying documented inputs.
import pandas as pd
from dept_v3 import *
from overrides import *
df=pd.read_pickle('master.pkl')
rows=[]
for _,r in df.iterrows():
    if r.source=='CNKI':
        d=code_zh(r.institution_or_address); d['fa_match']='cnki_first_segment'; d['n_fa_affils']=1
        d['dept_v3']=d['dept_v3_auto']; d['override_note']=''
        # 非高校机构（无院系层）
        if d['level'] in ('no_unit',) :
            for key,code,note in ZH_ORG:
                if key in d['first_affil']:
                    d['dept_v3']=code; d['override_note']=note; d['level']='organization'; break
        for key,(code,note) in ZH_OVR_BY_UNIT.items():
            if key in d['unit'] or (d['unit']=='' and key in d['first_affil']):
                d['dept_v3']=code; d['override_note']=note; d['level']='manual'; break
        if 'La Trobe' in d['first_affil']:
            d['dept_v3']='CS'; d['override_note']='英文单位串：Dept Computer Science and IT'; d['level']='manual'
    else:
        d=code_en(r.authors, r.institution_or_address)
        d['dept_v3']=d['dept_v3_auto']; d['override_note']=''
        if r.doc_id in EN_OVR:
            d['dept_v3'],d['override_note']=EN_OVR[r.doc_id]; d['level']='manual'
    d['doc_id']=r.doc_id; d['group']=r.group; d['axis_main']=r.axis_main; d['topic']=r.topic
    rows.append(d)
c=pd.DataFrame(rows)
c.to_pickle('code_v3.pkl')
print(pd.crosstab(c.group,c.dept_v3,margins=True))
print(pd.crosstab([c.group],c.level))
