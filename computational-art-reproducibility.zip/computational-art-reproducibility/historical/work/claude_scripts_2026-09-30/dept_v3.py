# Recovered historical source; run only from historical/ after supplying documented inputs.
"""院系编码 v3：按第一作者原始单位串编码（中英文同一套类别）。
类别：ART 艺术与设计；CS 计算机与信息工程；BOTH 同时含艺术与计算两类标记；
HUM 其他人文社科；STEM 其他理工医农；UNKNOWN 无院系信息或无法判定。
判定顺序：先在院系层（剔除学校名）找标记；ART 与 CS 同时出现 → BOTH；只有 ART → ART；只有 CS → CS；
否则有人文社科标记 → HUM；否则有其他理工标记 → STEM；院系层无任何标记时，学校本身为艺术类院校 → ART（机构层）；
其余 → UNKNOWN。
"""
import re
import pandas as pd

# ---------------- 中文 ----------------
ZH_ART = ['艺术', '美术', '设计', '音乐', '舞蹈', '戏剧', '戏曲', '影视', '电影', '动画', '动漫', '书法',
          '美育', '视觉传达', '服装', '服饰', '播音', '演艺', '表演', '画院', '国画', '油画', '绘画', '雕塑',
          '美院', '摄影', '工艺美术', '陶瓷艺术', '时尚', '作曲', '艺体', '电视', '数字创意', '歌舞']
ZH_CS = ['计算机', '软件', '信息科学', '信息工程', '信息技术', '信息学院', '电子信息', '人工智能', '智能科学',
         '智能工程', '智能技术', '电子', '通信', '自动化', '大数据', '数据科学', '网络空间', '物联网', '数字媒体技术',
         '机器人', '计算科学', '虚拟现实', '计算与信息', '信息系统', '信息处理', '信号']
ZH_HUM = ['文学', '中文', '汉语', '新闻', '传播', '传媒', '哲学', '马克思', '历史', '考古', '文博', '博物馆',
          '教育', '法学', '法律', '经济', '管理', '商学', '工商', '社会', '政治', '政法', '外国语', '外语', '翻译',
          '国际', '文化', '心理', '图书', '档案', '人文', '公共', '旅游', '民族', '宗教', '语言', '党校', '宣传',
          '社科', '伦理', '美学', '出版', '编辑', '国学', '文科', '创意产业', '文旅', '人类学', '期刊', '杂志', '经贸', '财经', '商务', '儒学', '创业', '版权']
ZH_STEM = ['机械', '土木', '建筑', '城市规划', '规划', '材料', '化学', '化工', '物理', '数学', '统计', '医',
           '药', '生命', '生物', '环境', '纺织', '交通', '能源', '农', '林学', '地理', '测绘', '光电', '光学', '航空',
           '航天', '海洋', '地球', '工程学院', '理学院', '食品', '轻工', '电气']
# 学校本身为艺术类院校（院系层无信息时使用）
ZH_ART_INST = ['艺术', '美术', '音乐', '戏剧', '戏曲', '电影', '舞蹈', '画院', '工艺美术', '美院', '动漫', '动画', '文艺', '歌舞']


def zh_split(seg):
    """把中文单位串拆成（学校/机构，院系层）。"""
    s = seg.strip()
    if '大学' in s:
        i = s.index('大学') + 2
        return s[:i], s[i:]
    if '学院' in s:
        i = s.index('学院') + 2
        return s[:i], s[i:]
    for key in ['研究院', '研究所', '科学院']:
        if key in s:
            i = s.index(key) + len(key)
            return s[:i], s[i:]
    return s, ''


def hits(text, words):
    return [w for w in words if w in text]


def classify_markers(art, cs, hum, stem):
    if art and cs:
        return 'BOTH'
    if art:
        return 'ART'
    if cs:
        return 'CS'
    if hum:
        return 'HUM'
    if stem:
        return 'STEM'
    return None


def code_zh(raw):
    first = re.split(r'[;；]', str(raw))[0].strip()
    inst, unit = zh_split(first)
    unit_c = unit
    # 防误配：环境艺术、艺术教育等由优先级处理；"信息管理""信息资源管理"不计 CS
    cs_text = unit_c.replace('信息管理', '').replace('信息资源管理', '')
    art = hits(unit_c, ZH_ART)
    cs = hits(cs_text, ZH_CS)
    hum = hits(unit_c, ZH_HUM)
    stem = hits(unit_c, ZH_STEM)
    cat = classify_markers(art, cs, hum, stem)
    level = 'unit'
    if cat is None:
        if hits(inst, ZH_ART_INST):
            cat, level = 'ART', 'institution'
        else:
            cat, level = 'UNKNOWN', ('no_unit' if unit.strip() == '' else 'unit_unmatched')
    return dict(first_affil=first, inst=inst, unit=unit, art_hits=';'.join(art), cs_hits=';'.join(cs),
                hum_hits=';'.join(hum), stem_hits=';'.join(stem), dept_v3_auto=cat, level=level)


# ---------------- 英文（WoS C1）----------------
UNIT_START = re.compile(r'^(Sch|Dept|Coll|Fac|Grad Sch|Grad Dept|Div|Inst|Ctr|Lab|Key Lab|State Key Lab|Res Ctr|'
                        r'Res Inst|Program|Programme|Unit|Grp|Sect|Acad|Minist Educ|Engn Res|Natl Engn|Shanghai Key|'
                        r'Beijing Key|Guangdong Key|Jiangsu Key|Zhejiang Key|Hubei Key|Sichuan Key|Studio|Chair|Media Lab|'
                        r'Interdisciplinary|Int Coll|Int Sch|Lib|Museum|Educ|Language Ctr|Off|Directorate|Area|Cluster|Consortium)\b')
ACAD_UNIT = re.compile(r'^(Sch|Dept|Coll|Fac|Grad Sch|Grad Dept|Div|Int Coll|Int Sch|Program|Programme|Area)\b')

EN_ART = [r'\bArts?\b', r'\bFine Arts?\b', r'\bDesign\b', r'\bDesigns\b', r'\bMus\b', r'\bMusic\b', r'\bFilm\b',
          r'\bCinema\b', r'\bAnimat', r'\bCreat (Arts|Media|Design)', r'\bDance\b', r'\bDrama\b', r'\bTheat(re|er)\b',
          r'\bPerforming\b', r'\bFash', r'\bVisual Commun', r'\bCalligraphy\b', r'\bCallig\b', r'\bPhotog\b', r'\bCraft', r'\bArtes\b', r'\bKunst', r'\bArtist', r'\bConservat(ory|oire)\b',
          r'\bSculpture\b', r'\bPainting\b', r'\bMedia Arts?\b', r'\bGame Design\b']
EN_CS = [r'\bComp\b', r'\bComputat', r'\bComputing\b', r'\bComputer\b', r'\bInformat\b', r'\bInformatics\b', r'\bSoftware\b',
         r'\bElect\b', r'\bElectrical\b', r'\bElectronic', r'\bArtificial Intelligence\b', r'\bAI\b', r'\bAutomat', r'\bData Sci',
         r'\bIntelligent\b', r'\bIntelligence\b', r'\bRobot', r'\bMachine Learning\b', r'\bCybernet', r'\bTelecommun',
         r'\bCommun Engn\b', r'\bSignal\b', r'\bImage Proc', r'\bMultimedia\b', r'\bVirtual Real', r'\bIoT\b', r'\bInternet Things\b',
         r'\bBig Data\b', r'\bDigital Media Techn', r'\bCyber\b', r'\bCAD', r'\bComputac', r'\bInformatica', r'\bMicroelect', r'\bTelecomun', r'\bSW\b', r'\bInformaticay', r'\bIntegrated Circuits\b', r'\bSemicond\b']
EN_HUM = [r'\bHumanities\b', r'\bLit\b', r'\bLiterature\b', r'\bLanguages?\b', r'\bLinguist', r'\bPhilosophy\b', r'\bPhilos\b',
          r'\bHist\b', r'\bHistory\b', r'\bEduc\b', r'\bEducation\b', r'\bLaw\b', r'\bLaws\b', r'\bEcon\b', r'\bManagement\b',
          r'\bBusiness\b', r'\bCommerce\b', r'\bSocial\b', r'\bSociol', r'\bPolit', r'\bPsychol', r'\bPsychosocial\b',
          r'\bJournalism\b', r'\bCommun\b', r'\bCommunicat', r'\bMedia\b', r'\bCultural\b', r'\bCulture\b', r'\bHeritage\b',
          r'\bArchaeol', r'\bMuseol', r'\bLib\b', r'\bTourism\b', r'\bCognit', r'\bAesthet', r'\bSocial Sci', r'\bInt Relat',
          r'\bPublic Adm', r'\bFinance\b', r'\bAccounting\b', r'\bMarketing\b', r'\bEnglish\b', r'\bForeign\b',
          r'\bAnthropol', r'\bLiberal Arts\b', r'\bMarxism\b']
EN_STEM = [r'\bEngn\b', r'\bEngineering\b', r'\bMech', r'\bCivil\b', r'\bMat\b', r'\bMat Sci', r'\bMaterials?\b', r'\bChem',
           r'\bPhys\b', r'\bPhysics\b', r'\bMath\b', r'\bMathematics\b', r'\bStat\b', r'\bStatistics\b', r'\bMed\b', r'\bMedicine\b',
           r'\bHlth\b', r'\bLife Sci', r'\bBiol', r'\bEnvironm', r'\bText\b', r'\bTextile', r'\bArchitecture\b', r'\bUrban Planning\b',
           r'\bPlanning\b', r'\bGeog', r'\bGeosci', r'\bEarth\b', r'\bAgr\b', r'\bForestry\b', r'\bOpt\b', r'\bOptics\b', r'\bAerosp', r'\bAeronaut', r'\bIngn\b', r'\bArquitectura\b', r'\bPharm\b', r'\bBiotechnol', r'\bAnat\b', r'\bBuilt Environm', r'\bImaging Sci', r'\bReg Planning', r'\bTechnol\b',
           r'\bEnergy\b', r'\bTransport', r'\bNat Sci', r'\bSci\b', r'\bSciences\b', r'\bOcean', r'\bSurveying\b', r'\bInd\b']
EN_ART_INST = [r'\bGallery\b', r'\bKunst', r'\bArtist\b', r'\bArts?\b', r'\bFine Arts?\b', r'\bDesign\b', r'\bConservat(ory|oire)\b', r'\bMus\b', r'\bMusic\b', r'\bFilm\b',
               r'\bDrama\b', r'\bDance\b', r'\bTheat(re|er)\b', r'\bPerforming\b']


def rx_hits(text, pats):
    out = []
    for p in pats:
        m = re.search(p, text)
        if m:
            out.append(m.group(0))
    return out


def split_c1(c1):
    """返回 [(names_list, address)]。"""
    groups = []
    for m in re.finditer(r'\[([^\]]*)\]\s*([^\[]*)', c1):
        names = [n.strip() for n in m.group(1).split(';') if n.strip()]
        addr = m.group(2).strip().rstrip(';').strip()
        groups.append((names, addr))
    if not groups:
        groups = [([], a.strip()) for a in c1.split(';') if a.strip()]
    return groups


def norm_name(n):
    n = n.strip()
    if ',' in n:
        last, first = n.split(',', 1)
    else:
        parts = n.split()
        last, first = (parts[-1], ' '.join(parts[:-1])) if parts else ('', '')
    initials = ''.join(ch for ch in first if ch.isupper())
    return last.strip().lower(), initials[:1]


def first_author_addresses(authors, c1):
    groups = split_c1(c1)
    if not groups:
        return [], 'no_c1'
    fa = str(authors).split(';')[0].strip()
    fl, fi = norm_name(fa)
    hits_ = []
    for names, addr in groups:
        for n in names:
            l, i = norm_name(n)
            if l == fl and (not fi or not i or i == fi):
                hits_.append(addr)
                break
    if hits_:
        return hits_, 'matched_first_author'
    return [groups[0][1]], 'fallback_first_group'


ACAD_ANY = re.compile(r'\b(Sch|Dept|Coll|Fac|Acad|Div|Program|Programme|Dipartimento|Departamento|Escuela|Facultad|Fak|Grad Sch)\b')
INST_LIKE = re.compile(r'\b(Univ|Universit\w*|Universidad|Universidade|Politecn\w*|Polytech|Hochschule|Ecole)\b')


def parse_en_address(addr):
    """WoS C1 地址：机构名 + 若干单位段 + 地点段。
    机构段 = 含 Univ 等的段，或首个不以单位关键词开头的段；末段（国家）不参与。
    单位层优先取学术单位段（Sch/Dept/Coll/Fac/Acad/Div…，不论其在段首还是段中）；没有学术单位段时，
    退而取其余中间段（实验室、中心等）。"""
    segs = [s.strip() for s in addr.split(',') if s.strip()]
    if len(segs) > 1:
        body = segs[:-1]
    else:
        body = segs
    inst_idx = set()
    for i, s in enumerate(body):
        if INST_LIKE.search(s) and not UNIT_START.match(s):
            inst_idx.add(i)
    if not inst_idx:
        for i, s in enumerate(body):
            if not UNIT_START.match(s):
                inst_idx.add(i)
                break
    inst = ' ; '.join(body[i] for i in sorted(inst_idx))
    rest = [s for i, s in enumerate(body) if i not in inst_idx]
    acad = [s for s in rest if ACAD_ANY.search(s)]
    if acad:
        return inst, acad, [s for s in rest if s not in acad], 'unit'
    if rest:
        return inst, [], rest, 'subunit'
    return inst, [], [], 'none'


def code_en_single(addr):
    inst, units, other, level = parse_en_address(addr)
    unit_text = ' | '.join(units) if units else ' | '.join(other)
    unit_text_m = re.sub(r'\bMinist Educ\b|\bMoE\b', '', unit_text)
    unit_text_m = re.sub(r'\bComp Aided Design\b', 'CAD', unit_text_m)
    cs_text = re.sub(r'(Informat Management|Management Informat Syst|Lib & Informat|Informat Studies|Informat Syst & Management)',
                     '', unit_text_m)
    art = rx_hits(unit_text_m, EN_ART)
    cs = rx_hits(cs_text, EN_CS)
    hum = rx_hits(unit_text_m, EN_HUM)
    stem = rx_hits(unit_text_m, EN_STEM)
    if re.search(r'\bLiberal Arts\b', unit_text_m):
        art = [a for a in art if a not in ('Arts', 'Art')]
    return dict(inst=inst, units=unit_text, level=level, art=art, cs=cs, hum=hum, stem=stem,
                inst_art=rx_hits(inst, EN_ART_INST))


def code_en(authors, c1):
    addrs, how = first_author_addresses(authors, c1)
    parts = [code_en_single(a) for a in addrs]
    art = sorted({x for p in parts for x in p['art']})
    cs = sorted({x for p in parts for x in p['cs']})
    hum = sorted({x for p in parts for x in p['hum']})
    stem = sorted({x for p in parts for x in p['stem']})
    cat = classify_markers(art, cs, hum, stem)
    level = 'unit' if any(p['level'] == 'unit' for p in parts) else ('subunit' if any(p['level'] == 'subunit' for p in parts) else 'none')
    if cat is None:
        if any(p['inst_art'] for p in parts):
            cat, level = 'ART', 'institution'
        else:
            cat = 'UNKNOWN'
            level = 'no_unit' if level == 'none' else 'unit_unmatched'
    return dict(first_affil=' || '.join(addrs), inst=' || '.join(p['inst'] for p in parts),
                unit=' || '.join(p['units'] for p in parts), art_hits=';'.join(art), cs_hits=';'.join(cs),
                hum_hits=';'.join(hum), stem_hits=';'.join(stem), dept_v3_auto=cat, level=level, fa_match=how,
                n_fa_affils=len(addrs))
