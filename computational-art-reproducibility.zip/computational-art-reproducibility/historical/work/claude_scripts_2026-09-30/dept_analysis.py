# Recovered historical source; run only from historical/ after supplying documented inputs.
import pandas as pd, numpy as np
from stats_util import *
m=pd.read_pickle('master.pkl'); c=pd.read_pickle('code_v3.pkl')
d=m.merge(c[['doc_id','dept_v3','level','first_affil','inst','unit','art_hits','cs_hits','hum_hits','stem_hits','override_note','fa_match','n_fa_affils']],on='doc_id')
d['VALUE']=(d.axis_main=='VALUE').astype(int); d['TECH']=(d.axis_main=='TECH').astype(int)
d['dept_v3_noinst']=np.where(d.level=='institution','UNKNOWN',d.dept_v3)
coll={'ART':'ART','CS':'TECHSIDE','BOTH':'TECHSIDE','STEM':'TECHSIDE','HUM':'HUM','UNKNOWN':'UNKNOWN'}
d['dept_v3_c4']=d.dept_v3.map(coll)
d.to_pickle('analysis.pkl')
ORDER=['ART','CS','BOTH','HUM','STEM','UNKNOWN']
groups={'ZH':d.group=='ZH','EN-CN':d.group=='EN-CN','EN-CN-strict':(d.group=='EN-CN')&(d.EN_CN_strict=='1'),'EN-NC':d.group=='EN-NC','EN':d.source!='CNKI'}
rows=[]
for gname,mask in groups.items():
    sub=d[mask]
    for dep in ORDER+['ALL']:
        s=sub if dep=='ALL' else sub[sub.dept_v3==dep]
        for ax in ['VALUE','TECH']:
            k=int(s[ax].sum()); n=len(s)
            rows.append(dict(group=gname,dept_v3=dep,axis=ax,count=k,n=n,share_pct=round(100*k/n,2) if n else None,CI95=ci_str(k,n)))
t17f=pd.DataFrame(rows)
print(t17f[t17f.axis=='VALUE'].pivot(index='dept_v3',columns='group',values='count').loc[ORDER+['ALL']])
print(t17f[t17f.axis=='VALUE'].pivot(index='dept_v3',columns='group',values='n').loc[ORDER+['ALL']])
t17f.to_pickle('t17f.pkl')

# ---------- ZH vs EN within each v3 stratum (VALUE) ----------
rows=[]
zh=d[d.group=='ZH']; en=d[d.source!='CNKI']
for dep in ORDER+['ALL']:
    a_=zh if dep=='ALL' else zh[zh.dept_v3==dep]; b_=en if dep=='ALL' else en[en.dept_v3==dep]
    a=int(a_.VALUE.sum()); na=len(a_); b=int(b_.VALUE.sum()); nb=len(b_)
    if na and nb:
        orr,lo,hi,p=fisher(a,na-a,b,nb-b)
    else:
        orr=lo=hi=p=np.nan
    rows.append(dict(dept_v3=dep,ZH=f'{a}/{na}',ZH_pct=round(100*a/na,2) if na else None,ZH_CI95=ci_str(a,na),
                     EN=f'{b}/{nb}',EN_pct=round(100*b/nb,2) if nb else None,EN_CI95=ci_str(b,nb),
                     diff_pp=round(100*(a/na-b/nb),2) if na and nb else None,OR_cond=orr,OR_CI95=(f'{lo:.2f}–{hi:.2f}' if np.isfinite(hi) else f'{lo:.2f}–∞') if na and nb else None,p_fisher=p))
t_within=pd.DataFrame(rows); print(t_within.to_string())
t_within.to_pickle('t_within.pkl')

# ---------- direct standardisation ----------
def std_rate(src, tgt, col):
    w=tgt[col].value_counts(normalize=True)
    p=src.groupby(col).VALUE.mean()
    common=[k for k in w.index if k in p.index]
    miss=[k for k in w.index if k not in p.index]
    return float((w[common]*p[common]).sum()/w[common].sum()), w, p, miss

def boot_std(src, tgt, col, reps=5000, seed=42, resample_target=True):
    rng=np.random.default_rng(seed)
    sv=src[col].values; sy=src.VALUE.values; tv=tgt[col].values
    levels=sorted(set(tv))
    sidx={l:np.where(sv==l)[0] for l in levels}
    out=[]
    for _ in range(reps):
        tt=tv[rng.integers(0,len(tv),len(tv))] if resample_target else tv
        w=pd.Series(tt).value_counts(normalize=True)
        tot=0.0; ws=0.0
        for l,wl in w.items():
            ii=sidx.get(l)
            if ii is None or len(ii)==0: continue
            bs=sy[ii[rng.integers(0,len(ii),len(ii))]].mean()
            tot+=wl*bs; ws+=wl
        out.append(tot/ws)
    return np.percentile(out,[2.5,97.5])

rows=[]
specs=[('v3 六类（主口径参照）','dept_v3',None),('v3 四类合并：ART / 技术侧（CS+BOTH+STEM）/ HUM / UNKNOWN（主口径）','dept_v3_c4',None),
       ('v3 四类合并，仅已知院系（剔除 UNKNOWN 后重新归一）','dept_v3_c4','known'),('v3 四类合并，机构层 ART 改为 UNKNOWN（敏感性）','dept_v3_noinst_c4',None)]
d['dept_v3_noinst_c4']=d.dept_v3_noinst.map(coll)
zh=d[d.group=='ZH']; en=d[d.source!='CNKI']
crude_zh=zh.VALUE.mean(); crude_en=en.VALUE.mean()
for tgt_name,tgt_mask in [('EN',d.source!='CNKI'),('EN-CN',d.group=='EN-CN'),('EN-NC',d.group=='EN-NC')]:
    tgt=d[tgt_mask]
    for label,col,mode in specs:
        src=zh; tg=tgt
        if mode=='known':
            src=zh[zh[col]!='UNKNOWN']; tg=tgt[tgt[col]!='UNKNOWN']
        est,w,p,miss=std_rate(src,tg,col)
        lo,hi=boot_std(src,tg,col)
        en_act=tg.VALUE.mean()
        zh_c=src.VALUE.mean()
        rows.append(dict(direction='中文按英文院系构成标准化',target=tgt_name,spec=label,
                         weights='; '.join(f'{k} {v*100:.1f}%' for k,v in w.items()),
                         ZH_stratum_rates='; '.join(f'{k} {p[k]*100:.1f}% (n={int((src[col]==k).sum())})' for k in w.index if k in p.index),
                         ZH_crude_pct=round(100*zh_c,2),ZH_standardised_pct=round(100*est,2),CI95_boot=f'{lo*100:.1f}–{hi*100:.1f}',
                         target_actual_pct=round(100*en_act,2),target_actual=f'{int(tg.VALUE.sum())}/{len(tg)}',
                         share_of_gap_explained_by_composition=round((zh_c-est)/(zh_c-en_act),3),missing_strata=';'.join(miss)))
# reverse: EN standardised to ZH composition
for label,col,mode in specs[:2]:
    est,w,p,miss=std_rate(en,zh,col)
    lo,hi=boot_std(en,zh,col)
    rows.append(dict(direction='英文按中文院系构成标准化（反向核对）',target='ZH',spec=label,weights='; '.join(f'{k} {v*100:.1f}%' for k,v in w.items()),
                     ZH_stratum_rates='（此行为英文各层比率）'+'; '.join(f'{k} {p[k]*100:.1f}% (n={int((en[col]==k).sum())})' for k in w.index if k in p.index),
                     ZH_crude_pct=round(100*crude_en,2),ZH_standardised_pct=round(100*est,2),CI95_boot=f'{lo*100:.1f}–{hi*100:.1f}',
                     target_actual_pct=round(100*crude_zh,2),target_actual=f'{int(zh.VALUE.sum())}/{len(zh)}',share_of_gap_explained_by_composition=None,missing_strata=';'.join(miss)))
t_std=pd.DataFrame(rows)
pd.set_option('display.width',250); pd.set_option('display.max_colwidth',60)
print(t_std[['direction','target','spec','ZH_crude_pct','ZH_standardised_pct','CI95_boot','target_actual_pct','share_of_gap_explained_by_composition']].to_string())
t_std.to_pickle('t_std.pkl'); d.to_pickle('analysis.pkl')
