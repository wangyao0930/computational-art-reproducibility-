# Recovered historical source; run only from historical/ after supplying documented inputs.
import pandas as pd, numpy as np, collections, itertools, time
import networkx as nx
m=pd.read_pickle('kw.pkl')
GROUPS={'ZH':m.group=='ZH','EN':m.source!='CNKI','EN-CN':m.group=='EN-CN','EN-NC':m.group=='EN-NC'}

def build(docs, fmin, wmin=1):
    f=collections.Counter(k for d in docs for k in d)
    keep={k for k,v in f.items() if v>=fmin}
    docs2=[[k for k in d if k in keep] for d in docs]
    w=collections.Counter()
    for d in docs2:
        for a,b in itertools.combinations(sorted(set(d)),2):
            w[(a,b)]+=1
    G=nx.Graph()
    G.add_nodes_from(sorted(keep))
    for (a,b),x in sorted(w.items()):
        if x>=wmin: G.add_edge(a,b,weight=x)
    return G, docs2, f

def metrics(G, seed=42):
    n=G.number_of_nodes(); e=G.number_of_edges()
    iso=[v for v in G.nodes if G.degree(v)==0]
    H=G.copy(); H.remove_nodes_from(iso)
    lcc=max(nx.connected_components(H),key=len) if H.number_of_nodes() else set()
    comms=nx.community.louvain_communities(H,weight='weight',seed=seed,resolution=1.0) if H.number_of_edges() else []
    Q=nx.community.modularity(H,comms,weight='weight') if comms else np.nan
    return dict(nodes=n,edges=e,isolates=len(iso),density=nx.density(G),mean_degree=2*e/n if n else np.nan,
                mean_strength=sum(d for _,d in G.degree(weight='weight'))/n if n else np.nan,
                lcc_share=len(lcc)/n if n else np.nan,avg_clustering=nx.average_clustering(G),
                transitivity=nx.transitivity(G),modularity_louvain=Q,
                n_communities_ge3=sum(1 for c in comms if len(c)>=3))

def curveball_chain(docs, rng, burn, thin, samples):
    """保持每篇关键词数与每个关键词频次的二部图随机化（curveball 算法）。"""
    D=[set(d) for d in docs if len(d)>0]
    idx=list(range(len(D)))
    def trade(k):
        for _ in range(k):
            i,j=rng.choice(len(D),2,replace=False)
            A,B=D[i],D[j]
            a_only=sorted(A-B); b_only=sorted(B-A)
            if not a_only or not b_only: continue
            pool=a_only+b_only
            rng.shuffle(pool)
            na=len(a_only)
            shared=A&B
            D[i]=shared|set(pool[:na]); D[j]=shared|set(pool[na:])
    trade(burn)
    for _ in range(samples):
        trade(thin)
        yield [list(x) for x in D]


import sys
g=sys.argv[1]; fmin=int(sys.argv[2]); wmin=int(sys.argv[3]); REPS=int(sys.argv[4])
docs=m[GROUPS[g]].kw_norm.tolist()
G,docs2,f=build(docs,fmin,wmin)
obs=metrics(G)
row=dict(group=g,fmin=fmin,wmin=wmin,n_docs=len(docs),n_docs_with_retained_kw=sum(1 for d in docs2 if d),unique_keywords=len(f),**obs)
rng=np.random.default_rng(42)
nd=sum(1 for d in docs2 if d)
nulls=[]
for i,nd_docs in enumerate(curveball_chain(docs2,rng,burn=20*nd,thin=2*nd,samples=REPS)):
    w=collections.Counter()
    for d in nd_docs:
        for a,b in itertools.combinations(sorted(d),2): w[(a,b)]+=1
    H=nx.Graph(); H.add_nodes_from(G.nodes)
    for (a,b),x in sorted(w.items()):
        if x>=wmin: H.add_edge(a,b,weight=x)
    nulls.append(metrics(H,seed=i))
N=pd.DataFrame(nulls)
nullrows=[]
for k in ['edges','density','mean_degree','lcc_share','avg_clustering','transitivity','modularity_louvain']:
    mu=N[k].mean(); sd=N[k].std(ddof=1); lo,hi=np.percentile(N[k],[2.5,97.5])
    ge=(np.sum(N[k]>=obs[k])+1)/(len(N)+1); le=(np.sum(N[k]<=obs[k])+1)/(len(N)+1)
    nullrows.append(dict(group=g,fmin=fmin,wmin=wmin,metric=k,observed=obs[k],null_mean=mu,null_sd=sd,null_2p5=lo,null_97p5=hi,
        z=(obs[k]-mu)/sd if sd>0 else np.nan,p_upper=ge,p_lower=le,reps=len(N),
        vals_in_0_1=bool(all(0<=v<=1 for v in list(N[k])+[obs[k]])) if k in ('density','lcc_share','avg_clustering','transitivity','modularity_louvain') else None))
pd.to_pickle((row,nullrows,N),f'net_{g}_{fmin}_{wmin}.pkl')
print(g,fmin,wmin,'done',obs)
