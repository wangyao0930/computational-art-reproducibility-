# Recovered historical source; run only from historical/ after supplying documented inputs.
"""从数据底表读取 30_记录级主数据，生成 master.pkl（全部按字符串读取）。"""
import sys, pandas as pd
src = sys.argv[1] if len(sys.argv) > 1 else 'Epistemic_distinctiveness_data_1427_K15_v2026-09-30.xlsx'
df = pd.read_excel(src, sheet_name='30_记录级主数据', dtype=str)
df = df[[c for c in df.columns if not c.startswith('dept_v3')]]  # 由 apply_codes.py 重新生成
df.to_pickle('master.pkl'); print(df.shape)
