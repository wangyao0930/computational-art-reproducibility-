# Recovered historical source; run only from historical/ after supplying documented inputs.
import pandas as pd, numpy as np, warnings
warnings.filterwarnings('ignore')
from stats_util import *
d=pd.read_pickle('analysis.pkl')
e=d[d.source!='CNKI'].copy()
e['g']=(e.group=='EN-CN').astype(int)
e['y_strict']=(e.Q2_verified_EN=='1').astype(int)
e['y_wide']=e.Q2_verified_EN.isin(['1','B']).astype(int)
e['y_dict']=(e['Q2_主体性_dict']=='1').astype(int)
e['y_tech']=(e['Q8_技术实现_dict']=='1').astype(int)
e['yr']=e.year.astype(int)-2022; e['obj']=(e.OBJ_CN_dict=='1').astype(int)
versions=[('v1 Codex 原始（B3）','dept_type_codex'),('v2 2026-09-28 修正（dept_fixed）','dept_fixed'),
          ('v3 本轮重编（六类，主口径）','dept_v3'),('v3 四类合并','dept_v3_c4'),('v3 机构层 ART 改为 UNKNOWN','dept_v3_noinst')]
outs=[('y_strict','主体性·核对后严格（主分析）'),('y_wide','主体性·核对后宽松'),('y_dict','主体性·词典编码'),('y_tech','技术实现·词典编码')]
rows=[]
for vlab,col in versions:
    for y,ylab in outs:
        st=[];desc=[]
        for lev in sorted(e[col].unique()):
            s=e[e[col]==lev]
            a=int(((s.g==1)&(s[y]==1)).sum()); b=int(((s.g==1)&(s[y]==0)).sum()); c=int(((s.g==0)&(s[y]==1)).sum()); dd=int(((s.g==0)&(s[y]==0)).sum())
            st.append((a,b,c,dd)); desc.append(f'{lev} {a}/{a+b} vs {c}/{c+dd}')
        r=mh(st)
        perm=strat_perm_p(e[y].values,e.g.values,e[col].values,reps=10000,seed=42) if y in ('y_strict','y_tech') else np.nan
        D=pd.get_dummies(e[col],drop_first=True).astype(float)
        X=pd.concat([e[['g']],D,e[['yr','obj']]],axis=1)
        lr=logit(X.values,e[y].values,list(X.columns))['g']
        rows.append(dict(dept_version=vlab,outcome=ylab,MH_OR=r['OR'],MH_CI95=f"{r['lo']:.2f}–{r['hi']:.2f}",p_CMH_cc=r['p_cmh_cc'],
                         p_stratified_perm=perm,adj_OR=lr[2],adj_CI95=f'{lr[3]:.2f}–{lr[4]:.2f}',p_Wald=lr[5],
                         strata='；'.join(desc)))
t=pd.DataFrame(rows)
pd.set_option('display.width',250); pd.set_option('display.max_colwidth',40)
print(t.drop(columns='strata').to_string())
t.to_pickle('t_mh.pkl')
# crude
for y,ylab in outs:
    a=int(((e.g==1)&(e[y]==1)).sum()); b=int(((e.g==1)&(e[y]==0)).sum()); c=int(((e.g==0)&(e[y]==1)).sum()); dd=int(((e.g==0)&(e[y]==0)).sum())
    print(ylab, a,a+b,c,c+dd, fisher(a,b,c,dd))
# ZH vs EN VALUE, MH across v3 strata
zz=d.copy(); zz['g']=(zz.group=='ZH').astype(int)
for col in ['dept_v3','dept_v3_c4','dept_v3_noinst']:
    st=[]
    for lev in sorted(zz[col].unique()):
        s=zz[zz[col]==lev]
        a=int(((s.g==1)&(s.VALUE==1)).sum()); b=int(((s.g==1)&(s.VALUE==0)).sum()); c=int(((s.g==0)&(s.VALUE==1)).sum()); dd=int(((s.g==0)&(s.VALUE==0)).sum())
        st.append((a,b,c,dd))
    r=mh(st); print('ZH vs EN VALUE MH',col,r['OR'],r['lo'],r['hi'],r['p_cmh_cc'])
