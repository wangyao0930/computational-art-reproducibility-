# Recovered historical source; run only from historical/ after supplying documented inputs.
"""Reapply the current screening rules to the existing deduplicated merge."""
from pathlib import Path
import json
import pandas as pd
from screen_corpus import classify

root = Path(__file__).resolve().parent / "processed"
df = pd.read_csv(root / "merged_deduplicated.csv", dtype=str, keep_default_na=False).fillna("")
old_summary = json.loads((root / "summary.json").read_text(encoding="utf-8"))
old_cols = ["Screen Decision", "Screen Reason", "Matched Terms", "Art Hit Count", "Tech Hit Count", "Non-art Hit Count"]
df = df.drop(columns=[c for c in old_cols if c in df.columns])
results = df.apply(classify, axis=1, result_type="expand")
results.columns = old_cols
df = pd.concat([df, results], axis=1)
included = df[df["Screen Decision"] == "include"].copy()
review = df[df["Screen Decision"] == "review"].copy()
excluded = df[df["Screen Decision"] == "exclude"].copy()
audit_cols = ["Record Key", "Screen Decision", "Screen Reason", "Matched Terms", "Source Batch", "Source File", "Source Files", "Article Title", "Abstract", "Author Keywords", "Publication Year", "DOI", "UT (Unique WOS ID)"]
audit_cols = [c for c in audit_cols if c in df.columns]
included.to_csv(root / "included.csv", index=False, encoding="utf-8-sig")
review[audit_cols].to_csv(root / "manual_review.csv", index=False, encoding="utf-8-sig")
excluded[audit_cols].to_csv(root / "excluded.csv", index=False, encoding="utf-8-sig")
summary = {
  **{k: old_summary[k] for k in ["source_files_found", "source_files_read", "source_file_errors", "raw_rows", "unique_records"]},
  "included_rows": int(len(included)), "manual_review_rows": int(len(review)), "excluded_rows": int(len(excluded)),
  "exclusion_reasons": {str(k): int(v) for k,v in excluded["Screen Reason"].value_counts().items()},
  "review_reasons": {str(k): int(v) for k,v in review["Screen Reason"].value_counts().items()},
  "required_fields": ["Article Title", "Abstract", "Author Keywords"],
  "rule_note": "Retain only records with title, abstract, author keywords, and a direct computational-art object. Records where art only serves as therapy, education, service, experiment, or another applied context are sent to manual review.",
}
(root / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
print(json.dumps(summary, ensure_ascii=False, indent=2))
