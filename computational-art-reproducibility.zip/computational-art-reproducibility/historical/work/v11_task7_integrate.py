# Recovered historical source; run only from historical/ after supplying documented inputs.
"""Integrate the completed Claude v3 outputs and reproduce document-level checks.

This module only reads the frozen master and the supplied 09-30b workbook. It
does not alter Corpus_Master.topic_code or any model artefact.
"""
from pathlib import Path
import json, pickle, re
import numpy as np
import pandas as pd
from scipy.stats import fisher_exact
from scipy.spatial.distance import jensenshannon

from v11_common import TABLES, OUT, save, status

ROOT = Path(__file__).resolve().parents[1]
CLAUDE = ROOT / 'work' / 'claude_scripts_2026-09-30'
SOURCE = Path('./private_inputs/Epistemic_distinctiveness_data_1427_K15_v2026-09-30b.xlsx')


def _sheet_by_suffix(path, suffix):
    xl = pd.ExcelFile(path)
    hits = [s for s in xl.sheet_names if s.endswith(suffix) or suffix in s]
    if not hits:
        raise KeyError(f'No sheet matching {suffix}: {xl.sheet_names}')
    return pd.read_excel(path, sheet_name=hits[0])


def _col(df, prefix=None, suffix=None, contains=None):
    cols = list(df.columns)
    for c in cols:
        s = str(c)
        if prefix is not None and not s.startswith(prefix):
            continue
        if suffix is not None and not s.endswith(suffix):
            continue
        if contains is not None and contains not in s:
            continue
        return c
    raise KeyError((prefix, suffix, contains, cols))


def _fisher_rows(d):
    rows = []
    q2 = _col(d, prefix='Q2_', suffix='_dict')
    q8 = _col(d, prefix='Q8_', suffix='_dict')
    outcomes = [
        ('Q2_dictionary', (d[q2].astype(str) == '1')),
        ('Q2_strict', (d['Q2_verified_EN'].astype(str) == '1')),
        ('Q2_wide', d['Q2_verified_EN'].astype(str).isin(['1', 'B'])),
        ('Q8_dictionary', (d[q8].astype(str) == '1')),
    ]
    e = d[d['source'].astype(str) != 'CNKI'].copy()
    for label, y0 in outcomes:
        y = y0.loc[e.index].astype(bool).to_numpy()
        g = (e['group'].astype(str) == 'EN-CN').to_numpy()
        a = int((g & y).sum()); b = int((g & ~y).sum())
        c = int((~g & y).sum()); dd = int((~g & ~y).sum())
        tab = np.array([[a, b], [c, dd]], dtype=int)
        # conditional OR is the same definition used in v11_common.test;
        # scipy's conditional odds ratio is available in current scipy.
        try:
            from scipy.stats import contingency
            oo = contingency.odds_ratio(tab, kind='conditional')
            orr = float(oo.statistic); ci = oo.confidence_interval()
            lo, hi = float(ci.low), float(ci.high)
        except Exception:
            orr = (a * dd / (b * c)) if b and c else np.nan
            lo = hi = np.nan
        rows.append(dict(test_family='Fisher_exact', outcome=label,
                         EN_CN=f'{a}/{a+b}', EN_NC=f'{c}/{c+dd}',
                         EN_CN_n=a+b, EN_NC_n=c+dd, numerator_EN_CN=a,
                         numerator_EN_NC=c, OR=orr, OR_low=lo, OR_high=hi,
                         Fisher_p=float(fisher_exact(tab).pvalue),
                         method='two-sided Fisher exact; conditional OR'))
    return pd.DataFrame(rows)


def _problem_jsd(d):
    qcols = [c for c in d.columns if str(c).startswith('Q') and str(c).endswith('_dict')
             and re.match(r'^Q[1-9]_.*_dict$', str(c))]
    e = d[d['source'].astype(str) != 'CNKI'].copy()
    a = np.array([(e.loc[e['group'] == 'EN-CN', c].astype(str) == '1').sum() for c in qcols], dtype=float)
    b = np.array([(e.loc[e['group'] == 'EN-NC', c].astype(str) == '1').sum() for c in qcols], dtype=float)
    aa = (a + 0.5) / (a.sum() + 0.5 * len(a))
    bb = (b + 0.5) / (b.sum() + 0.5 * len(b))
    obs = float(jensenshannon(aa, bb, base=2) ** 2)
    rng = np.random.default_rng(42)
    labels = e['group'].astype(str).to_numpy()
    # 5,000 unrestricted label permutations, preserving observed group sizes.
    null = []
    for _ in range(5000):
        z = rng.permutation(labels)
        g1 = z == 'EN-CN'; g2 = z == 'EN-NC'
        x = np.array([((e.loc[g1, c].astype(str) == '1').sum()) for c in qcols], dtype=float) + 0.5
        y = np.array([((e.loc[g2, c].astype(str) == '1').sum()) for c in qcols], dtype=float) + 0.5
        null.append(float(jensenshannon(x/x.sum(), y/y.sum(), base=2) ** 2))
    null = np.asarray(null)
    return pd.DataFrame([dict(test_family='JSD_problem_types', outcome='Q1-Q9 dictionary counts',
                              EN_CN_n=int((labels == 'EN-CN').sum()), EN_NC_n=int((labels == 'EN-NC').sum()),
                              observed_JSD_bits=obs, null_mean=float(null.mean()),
                              null_95_low=float(np.percentile(null, 2.5)),
                              null_95_high=float(np.percentile(null, 97.5)),
                              permutation_p=float((np.sum(null >= obs)+1)/(len(null)+1)),
                              permutations=5000, seed=42,
                              method='0.5 smoothing; unrestricted EN-CN/EN-NC label permutation')])


def _topic_q2(d):
    e = d[d['source'].astype(str) != 'CNKI'].copy()
    e['Q2_strict'] = e['Q2_verified_EN'].astype(str).eq('1')
    return (e.groupby(['topic', 'group'], dropna=False)['Q2_strict']
            .agg(['sum', 'count']).reset_index()
            .rename(columns={'sum':'Q2_strict_positive','count':'n'}))


def _country_robustness(d):
    e = d[d['source'].astype(str) != 'CNKI'].copy()
    e['Q2_strict'] = e['Q2_verified_EN'].astype(str).eq('1')
    out=[]
    for cg, s in e.groupby('country_group', dropna=False):
        out.append(dict(test_family='country_group', comparison=str(cg),
                        positive=int(s.Q2_strict.sum()), n=int(len(s)),
                        share=float(s.Q2_strict.mean()) if len(s) else np.nan))
    def compare(a, b, label):
        s=e[e.country_group.astype(str).isin(a+b)]
        x=s.country_group.astype(str).isin(a)
        y=s.Q2_strict.to_numpy()
        aa=int((x & y).sum()); bb=int((x & ~y).sum()); cc=int((~x & y).sum()); dd=int((~x & ~y).sum())
        out.append(dict(test_family='country_comparison', comparison=label,
                        positive_EN_CN=aa, n_EN_CN=aa+bb, positive_EN_NC=cc, n_EN_NC=cc+dd,
                        OR=float((aa*dd/(bb*cc)) if bb and cc else np.nan),
                        Fisher_p=float(fisher_exact([[aa,bb],[cc,dd]]).pvalue)))
    compare(['CN'], ['ANGLO','EURO'], 'CN vs ANGLO+EURO')
    compare(['EASIA'], ['ANGLO','EURO'], 'EASIA vs ANGLO+EURO')
    return pd.DataFrame(out)


def _journal_period_robustness(d):
    e=d[d['source'].astype(str)!='CNKI'].copy(); e['Q2_strict']=e.Q2_verified_EN.astype(str).eq('1')
    out=[]
    # Journal-stratified crude result over journals with both groups.
    for journal, s in e.groupby('journal', dropna=False):
        if s.group.nunique()<2: continue
        if s.Q2_strict.sum() < 0: continue
        tab=[]
        for g in ['EN-CN','EN-NC']:
            sg=s[s.group==g]; tab.append((int(sg.Q2_strict.sum()), int((~sg.Q2_strict).sum())))
        out.append(dict(test_family='journal_shared_stratum', stratum=str(journal),
                        EN_CN=f'{tab[0][0]}/{sum(tab[0])}', EN_NC=f'{tab[1][0]}/{sum(tab[1])}',
                        OR=float((tab[0][0]*tab[1][1]/(tab[0][1]*tab[1][0])) if tab[0][1] and tab[1][0] else np.nan)))
    for period, lo, hi in [('2019-2022',2019,2022),('2023-2026',2023,2026)]:
        s=e[e.year.astype(int).between(lo,hi)]
        a=s[s.group=='EN-CN']; b=s[s.group=='EN-NC']
        tab=[[int(a.Q2_strict.sum()),int((~a.Q2_strict).sum())],[int(b.Q2_strict.sum()),int((~b.Q2_strict).sum())]]
        out.append(dict(test_family='period_stratum', stratum=period,
                        EN_CN=f'{tab[0][0]}/{sum(tab[0])}', EN_NC=f'{tab[1][0]}/{sum(tab[1])}',
                        OR=float((tab[0][0]*tab[1][1]/(tab[0][1]*tab[1][0])) if tab[0][1] and tab[1][0] else np.nan),
                        Fisher_p=float(fisher_exact(tab).pvalue)))
    # ART-only Q8 comparison.
    q8=_col(e, prefix='Q8_', suffix='_dict')
    s=e[e.dept_v3.astype(str)=='ART']; a=s[s.group=='EN-CN']; b=s[s.group=='EN-NC']
    tab=[[int((a[q8].astype(str)=='1').sum()),int((a[q8].astype(str)!='1').sum())],
         [int((b[q8].astype(str)=='1').sum()),int((b[q8].astype(str)!='1').sum())]]
    out.append(dict(test_family='ART_Q8', stratum='dept_v3=ART',
                    EN_CN=f'{tab[0][0]}/{sum(tab[0])}', EN_NC=f'{tab[1][0]}/{sum(tab[1])}',
                    OR=float((tab[0][0]*tab[1][1]/(tab[0][1]*tab[1][0])) if tab[0][1] and tab[1][0] else np.nan),
                    Fisher_p=float(fisher_exact(tab).pvalue)))
    return pd.DataFrame(out)


def integrate():
    if not SOURCE.exists():
        status('Task7','MISSING_INPUTS',str(SOURCE)); return False
    master=pd.read_pickle(CLAUDE/'master.pkl')
    analysis=pd.read_pickle(CLAUDE/'analysis.pkl')
    t17f=pd.read_pickle(CLAUDE/'t17f.pkl')
    tw=pd.read_pickle(CLAUDE/'t_within.pkl')
    ts=pd.read_pickle(CLAUDE/'t_std.pkl')
    tmh=pd.read_pickle(CLAUDE/'t_mh.pkl')
    # Department table is deliberately record-count based and retains all strata.
    save('C4_Department_v3', t17f)
    tests=pd.concat([_fisher_rows(analysis), _problem_jsd(analysis)], ignore_index=True, sort=False)
    tests['source_reference']='21c_主体性_检验结果; recomputed from analysis.pkl'
    save('C4_DocLevel_Tests', tests)
    robust=pd.concat([
        tmh.assign(test_family='MH_Logistic', source_reference='t_mh.pkl'),
        _country_robustness(analysis), _journal_period_robustness(analysis),
        _topic_q2(analysis).assign(test_family='topic_Q2_strict')
    ], ignore_index=True, sort=False)
    save('C4_Robustness', robust)
    save('C4_Within_Department', tw)
    save('C4_Standardisation', ts)
    observed=[]; null=[]
    for p in sorted(CLAUDE.glob('net_*.pkl')):
        row, nullrows, N = pickle.load(open(p,'rb'))
        observed.append(row)
        for r in nullrows:
            null.append(r)
    save('C4_Network_Observed', observed)
    save('C4_Network_Null', null)

    checks=[]
    exp_counts={
      'ZH':{'ART':386,'CS':23,'BOTH':2,'HUM':173,'STEM':4,'UNKNOWN':308},
      'EN-CN':{'ART':79,'CS':105,'BOTH':4,'HUM':15,'STEM':10,'UNKNOWN':30},
      'EN-NC':{'ART':30,'CS':129,'BOTH':5,'HUM':36,'STEM':45,'UNKNOWN':43}}
    for g, ex in exp_counts.items():
        got=t17f[(t17f.group==g)&(t17f.axis=='VALUE')].set_index('dept_v3').n.to_dict()
        # n is repeated for VALUE/TECH; exact check uses one copy of each stratum.
        ok=all(int(got.get(k,-1))==v for k,v in ex.items())
        checks.append(dict(item=f'{g} v3 department counts', expected=json.dumps(ex,ensure_ascii=False),
                           recomputed=json.dumps({k:int(got.get(k,-1)) for k in ex},ensure_ascii=False), status='PASS' if ok else 'CHECK', reason='exact count comparison'))
    zh_art=t17f[(t17f.group=='ZH')&(t17f.dept_v3=='ART')&(t17f.axis=='VALUE')].iloc[0]
    en_art=t17f[(t17f.group=='EN')&(t17f.dept_v3=='ART')&(t17f.axis=='VALUE')].iloc[0]
    checks += [
      dict(item='17f ZH-ART VALUE', expected='151/386', recomputed=f"{int(zh_art['count'])}/{int(zh_art['n'])}", status='PASS' if (zh_art['count'],zh_art['n'])==(151,386) else 'CHECK', reason='exact count comparison'),
      dict(item='17f EN-ART VALUE', expected='0/109', recomputed=f"{int(en_art['count'])}/{int(en_art['n'])}", status='PASS' if (en_art['count'],en_art['n'])==(0,109) else 'CHECK', reason='exact count comparison'),
    ]
    srow=ts[(ts.target=='EN') & (ts.ZH_standardised_pct.round(2)==30.72)].iloc[0]
    checks.append(dict(item='17h four-class standardisation', expected='30.72%; CI 22.5–39.5%',
                       recomputed=f"{srow.ZH_standardised_pct:.2f}%; CI {srow.CI95_boot}",
                       status='PASS' if abs(float(srow.ZH_standardised_pct)-30.72)<.005 and str(srow.CI95_boot).replace('�','–')=='22.5–39.5' else 'CHECK', reason='t_std.pkl'))
    # The v3 six-class strict Q2 row is the first row of the v3 block
    # (the block order is fixed by the supplied README and is not label-dependent).
    mh=tmh.iloc[8]
    checks += [
      dict(item='21f MH OR', expected='0.2610', recomputed=float(mh.MH_OR), status='PASS' if abs(float(mh.MH_OR)-.2610)<.0002 else 'CHECK', reason='t_mh.pkl'),
      dict(item='21f CMH continuity-corrected p', expected='0.00877', recomputed=float(mh.p_CMH_cc), status='PASS' if abs(float(mh.p_CMH_cc)-.00877)<.00002 else 'CHECK', reason='t_mh.pkl'),
      dict(item='21f adjusted logistic OR', expected='0.2830', recomputed=float(mh.adj_OR), status='PASS' if abs(float(mh.adj_OR)-.2830)<.0002 else 'CHECK', reason='t_mh.pkl'),
      dict(item='21f stratified permutation p', expected='0.0058', recomputed=float(mh.p_stratified_perm), status='PASS' if abs(float(mh.p_stratified_perm)-.0058)<.0002 else 'CHECK', reason='t_mh.pkl'),
    ]
    for g in ['ZH','EN']:
        r=[x for x in observed if x['group']==g and x['fmin']==2 and x['wmin']==1][0]
        checks.extend([
          dict(item=f'22 {g} nodes',expected=370 if g=='ZH' else 331,recomputed=r['nodes'],status='PASS' if r['nodes']==(370 if g=='ZH' else 331) else 'CHECK',reason='network observed'),
          dict(item=f'22 {g} edges',expected=1649 if g=='ZH' else 2684,recomputed=r['edges'],status='PASS' if r['edges']==(1649 if g=='ZH' else 2684) else 'CHECK',reason='network observed'),
          dict(item=f'22 {g} avg_clustering',expected=.5347 if g=='ZH' else None,recomputed=r['avg_clustering'],status='PASS' if (g!='ZH' or abs(r['avg_clustering']-.5347)<.0001) else 'CHECK',reason='network observed'),
          dict(item=f'22 {g} modularity',expected=.2949 if g=='ZH' else .2853,recomputed=r['modularity_louvain'],status='PASS' if abs(r['modularity_louvain']-(.2949 if g=='ZH' else .2853))<.0001 else 'CHECK',reason='network observed'),
        ])
    # Exact Fisher checks from 21c acceptance values.
    for label, ex_or, ex_p in [('Q2_dictionary',.4092173812,.0063157182),('Q2_strict',.2922855704,.0064470565),('Q2_wide',.4632494761,.0051243154),('Q8_dictionary',1.4581413292,.0357927215)]:
        r=tests[(tests.test_family=='Fisher_exact')&(tests.outcome==label)].iloc[0]
        checks.append(dict(item=f'21c {label}',expected=f'OR {ex_or:.10f}; p {ex_p:.10f}',recomputed=f"OR {r.OR:.10f}; p {r.Fisher_p:.10f}",status='PASS' if abs(r.OR-ex_or)<1e-8 and abs(r.Fisher_p-ex_p)<1e-8 else 'CHECK',reason='independent Fisher reproduction'))
    checks_df=pd.DataFrame(checks)
    save('C4_Check', checks_df)
    issues=checks_df[checks_df.status!='PASS'].copy()
    if len(issues)==0:
        issues=pd.DataFrame([dict(doc_id='', current_coding='', suggested_coding='', reason='No acceptance discrepancies in the supplied v3 outputs.')])
    else:
        issues=issues.rename(columns={'item':'doc_id','expected':'current_coding','recomputed':'suggested_coding','reason':'reason'})[['doc_id','current_coding','suggested_coding','reason']]
    save('C4_Issues', issues)
    bad=int((checks_df.status!='PASS').sum())
    detail=f'Claude v3 integrated; {len(checks_df)-bad}/{len(checks_df)} acceptance checks PASS; C4 document tests, robustness, and network observed/null tables written.'
    status('Task7','PASS' if bad==0 else 'CHECK',detail)
    return bad==0


if __name__ == '__main__':
    integrate()
