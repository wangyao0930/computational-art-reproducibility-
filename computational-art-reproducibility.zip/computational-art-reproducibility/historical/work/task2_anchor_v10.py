# Recovered historical source; run only from historical/ after supplying documented inputs.
# -*- coding: utf-8 -*-
"""Task 2, v10: anchor-pair permutation test with the specified statistic."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA

ROOT = Path('.')
MODEL = ROOT / "work" / "models" / "multilingual-e5-large"
RAW_DOC_EMB = ROOT / "work" / "new_inputs" / "embeddings_1427.npy"
OUT = ROOT / "outputs" / "rerun_1427_k15" / "task2_anchor_v10"
OUT.mkdir(parents=True, exist_ok=True)
SEED = 42
N_PERM = 5000

ANCHOR_PAIRS = [
    ("作者归属", "authorship"), ("创造力", "creativity"), ("主体性", "subjectivity"),
    ("本体论", "ontology"), ("伦理", "ethics"), ("版权", "copyright"), ("审美", "aesthetics"),
    ("风格迁移", "style transfer"), ("生成对抗网络", "generative adversarial network"),
    ("扩散模型", "diffusion model"), ("图像分类", "image classification"), ("点云", "point cloud"),
    ("非物质文化遗产", "intangible cultural heritage"), ("书法", "calligraphy"), ("陶瓷", "ceramics"),
    ("博物馆", "museum"), ("展览", "exhibition"), ("舞蹈", "dance"), ("编舞", "choreography"),
    ("音乐生成", "music generation"), ("电影", "film"), ("动画", "animation"), ("插画", "illustration"),
    ("数字媒体艺术", "digital media art"), ("元宇宙", "metaverse"), ("人机协作", "human-AI collaboration"),
    ("艺术设计", "art and design"), ("计算美学", "computational aesthetics"), ("灵韵", "aura"),
    ("文化传承", "cultural transmission"), ("人工智能艺术", "AI art"), ("深度学习", "deep learning"),
    ("图像生成", "image generation"),
]

def postprocess(x: np.ndarray, center: np.ndarray, pca: PCA) -> np.ndarray:
    xc = x - center
    removed = pca.inverse_transform(pca.transform(xc))
    y = xc - removed
    norms = np.linalg.norm(y, axis=1, keepdims=True)
    return y / norms

def main():
    from sentence_transformers import SentenceTransformer

    model = SentenceTransformer(str(MODEL))
    raw_docs = np.load(RAW_DOC_EMB).astype(np.float64)
    center = raw_docs.mean(axis=0, keepdims=True)
    pca = PCA(n_components=3, random_state=SEED).fit(raw_docs - center)

    zh = [a for a, _ in ANCHOR_PAIRS]
    en = [b for _, b in ANCHOR_PAIRS]
    zh_raw = np.asarray(model.encode(["query: " + x for x in zh], batch_size=16, normalize_embeddings=True, show_progress_bar=False), dtype=np.float64)
    en_raw = np.asarray(model.encode(["passage: " + x for x in en], batch_size=16, normalize_embeddings=True, show_progress_bar=False), dtype=np.float64)

    rng = np.random.default_rng(SEED)
    summaries = []
    detail_rows = []
    for rep, a, b in [
        ("raw_query_passage", zh_raw, en_raw),
        ("postprocessed_query_passage", postprocess(zh_raw, center, pca), postprocess(en_raw, center, pca)),
    ]:
        sim = a @ b.T
        np.fill_diagonal(sim, np.diag(sim))
        true = np.diag(sim)
        off = sim[~np.eye(len(ANCHOR_PAIRS), dtype=bool)]
        ranks = np.array([1 + int(np.sum(sim[i] > sim[i, i])) for i in range(len(ANCHOR_PAIRS))], dtype=int)
        null = np.empty(N_PERM, dtype=np.float64)
        for j in range(N_PERM):
            perm = rng.permutation(len(ANCHOR_PAIRS))
            null[j] = float(np.mean(sim[np.arange(len(ANCHOR_PAIRS)), perm]))
        T = float(np.mean(true))
        pval = float((np.sum(null >= T) + 1) / (N_PERM + 1))
        summaries.append({
            "representation": rep,
            "pairs": len(ANCHOR_PAIRS),
            "T_mean_diagonal_cosine": T,
            "non_diagonal_mean_cosine": float(np.mean(off)),
            "top1_fraction": float(np.mean(ranks == 1)),
            "top5_fraction": float(np.mean(ranks <= 5)),
            "median_rank": float(np.median(ranks)),
            "permutations": N_PERM,
            "seed": SEED,
            "p_value_Tsigma_ge_T": pval,
            "status": "PASS" if pval <= 0.01 else "CHECK",
        })
        for i, (z, e) in enumerate(ANCHOR_PAIRS):
            detail_rows.append({"representation": rep, "row": i, "zh_anchor": z, "en_anchor": e, "diagonal_cosine": float(true[i]), "rank": int(ranks[i])})
        pd.DataFrame(sim, index=zh, columns=en).to_csv(OUT / f"F2_Anchor_Matrix_{'raw' if rep.startswith('raw') else 'post'}.csv", encoding="utf-8-sig")

    summary_df = pd.DataFrame(summaries)
    detail_df = pd.DataFrame(detail_rows)
    summary_df.to_csv(OUT / "F2_Anchor_Summary_v2.csv", index=False, encoding="utf-8-sig")
    detail_df.to_csv(OUT / "F2_Anchor_Detail_v2.csv", index=False, encoding="utf-8-sig")
    report = {
        "task": "Task 2 anchor permutation test v10",
        "pairs": len(ANCHOR_PAIRS), "permutations": N_PERM, "seed": SEED,
        "statistic": "T = mean(diagonal cosine); p=(count(T_sigma>=T)+1)/(N+1)",
        "status": "PASS" if bool((summary_df["p_value_Tsigma_ge_T"] <= 0.01).all()) else "CHECK",
        "summary": summaries,
    }
    (OUT / "task2_summary.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(summary_df.to_string(index=False))

if __name__ == "__main__":
    main()
