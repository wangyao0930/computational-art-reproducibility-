# Recovered historical source; run only from historical/ after supplying documented inputs.
from __future__ import annotations

import json
import math
import re
import unicodedata
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.stats import beta, fisher_exact, hypergeom
from scipy.spatial.distance import jensenshannon

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "output" / "final_rebuild_20260927_1427" / "computational_art_final_rebuild_1427.xlsx"
OUT = ROOT / "outputs" / "rerun_1427_k15"
OUT.mkdir(parents=True, exist_ok=True)
TOPICS = [f"T{i:02d}" for i in range(15)]
VALUE = {"T00", "T03", "T13"}
TECH = {"T02", "T05", "T08", "T12"}
VALUE_WIDE = VALUE | {"T09", "T11"}
SEEDS = [42, 7, 123, 2024, 999]


def norm_topic(x):
    if pd.isna(x) or str(x).strip() == "":
        return ""
    s = str(x).strip().upper()
    if s.startswith("T"):
        return f"T{int(s[1:]):02d}"
    return f"T{int(float(s)):02d}"


def s(x):
    return "" if pd.isna(x) else str(x).strip()


def normalize_journal(x):
    x = unicodedata.normalize("NFKC", s(x)).replace("（", "(").replace("）", ")")
    x = x.upper().replace("&", "AND")
    return re.sub(r"[^0-9A-Z\u4e00-\u9fff]+", "", x)


def cp(k, n):
    if n <= 0:
        return np.nan, np.nan
    lo = 0.0 if k == 0 else float(beta.ppf(.025, k, n-k+1))
    hi = 1.0 if k == n else float(beta.ppf(.975, k+1, n-k))
    return lo, hi


def bootstrap_diff(a, b, reps=5000, seed=42):
    a = np.asarray(a, dtype=int)
    b = np.asarray(b, dtype=int)
    if len(a) == 0 or len(b) == 0:
        return np.nan, np.nan, np.nan
    rng = np.random.default_rng(seed)
    vals = np.empty(reps)
    for i in range(reps):
        vals[i] = a[rng.integers(0, len(a), len(a))].mean() - b[rng.integers(0, len(b), len(b))].mean()
    return float(a.mean() - b.mean()), float(np.quantile(vals, .025)), float(np.quantile(vals, .975))


def fisher_binary(a, b):
    a = np.asarray(a, dtype=int)
    b = np.asarray(b, dtype=int)
    table = np.array([[a.sum(), len(a)-a.sum()], [b.sum(), len(b)-b.sum()]], dtype=int)
    orv, p = fisher_exact(table)
    return table, float(orv), float(p)


def jsd_counts(a, b):
    a = np.asarray(a, dtype=float); b = np.asarray(b, dtype=float)
    return float(jensenshannon(a/a.sum(), b/b.sum(), base=2) ** 2)


def write_table(name, df):
    df.to_csv(OUT / f"{name}.csv", index=False, encoding="utf-8-sig")


def load_inputs():
    d = pd.read_excel(SOURCE, sheet_name="Corpus_Master", dtype=object).fillna("")
    d.columns = d.columns.str.replace("\ufeff", "", regex=False)
    d["topic_code"] = d["topic_code"].map(norm_topic)
    d["year"] = pd.to_numeric(d["year"], errors="coerce")
    d["journal_norm"] = d["journal"].map(normalize_journal)
    d["first_seg"] = d["institution_or_address"].map(lambda x: re.sub(r"\[[^\]]*\]", "", s(x)).split(";")[0].strip())
    d["en_cn_strict"] = d["analysis_group"].eq("EN-CN") & ~d["first_seg"].str.contains("Hong Kong|Macau|Macao", case=False, regex=True, na=False) | d["first_seg"].str.contains("Hong Kong Univ Sci & Technol, Guangzhou Campus", case=False, regex=False, na=False)

    dept_path = ROOT / "output" / "task3_department_coding_k13.xlsx"
    dept = pd.read_excel(dept_path, sheet_name="Address_Parsed_K13", dtype=object).fillna("")
    dept.columns = dept.columns.str.replace("\ufeff", "", regex=False)
    dept["topic_code"] = dept["topic_code"].map(norm_topic)
    dept["title_norm"] = dept["title"].map(s)
    dept["source_record_id"] = dept["record_id"].where(dept["source"].eq("WoS"), "")
    dept["journal_norm"] = dept["journal"].map(normalize_journal)

    country = pd.read_excel(ROOT / "output" / "task4_country_groups_k13.xlsx", sheet_name="Primary_Group_Mapping", dtype=object).fillna("")
    country.columns = country.columns.str.replace("\ufeff", "", regex=False)

    payload = json.loads((ROOT / "output" / "task5_analysis_payload.json").read_text(encoding="utf-8"))
    tier_headers = payload["Tier_Assigned_headers"]
    tier = pd.DataFrame(payload["Tier_Assigned"], columns=tier_headers)
    tier["journal_name"] = tier.iloc[:, 2].map(normalize_journal)

    old = pd.read_csv(ROOT / "work" / "joint_k12_revision_20260821" / "document_topic_assignments_k12.csv", dtype=object).fillna("")
    old["topic_int"] = pd.to_numeric(old["topic"], errors="coerce")
    return d, dept, country, tier, old


def merge_reused_coding(d, dept, country, tier):
    # Department reuse: WoS by UT/source_record_id; CNKI by exact title.
    wo = dept[dept.source.eq("WoS")].copy()
    zh = dept[dept.source.eq("CNKI")].copy()
    dm_w = d[d.source.eq("WoS")].merge(wo[["record_id", "dept_type", "coding_status", "parse_failure_flag", "department_name", "institution_name", "first_author_block", "country_normalized", "clc", "topic_code"]], left_on="source_record_id", right_on="record_id", how="left", suffixes=("", "_reuse"))
    dm_z = d[d.source.eq("CNKI")].merge(zh[["title_norm", "dept_type", "coding_status", "parse_failure_flag", "department_name", "institution_name", "first_author_block", "country_normalized", "clc", "topic_code"]], left_on="title", right_on="title_norm", how="left", suffixes=("", "_reuse"))
    m = pd.concat([dm_z, dm_w], ignore_index=True, sort=False)
    for c in ["dept_type", "coding_status", "parse_failure_flag", "department_name", "institution_name", "first_author_block", "country_normalized", "clc"]:
        if c not in m:
            m[c] = ""
    m["dept_match"] = m["dept_type"].ne("") & m["dept_type"].notna()
    m["clc_use"] = m["clc_raw"].where(m["clc_raw"].ne(""), m["clc"])
    # Country reuse by WoS UT.
    m = m.merge(country[["source_record_id", "first_author_country_clean", "geographic_group"]], on="source_record_id", how="left", suffixes=("", "_country"))
    m["geographic_group"] = m["geographic_group"].where(m["geographic_group"].ne(""), "")
    # Journal tier lookup by normalized journal; evidence completeness is explicit.
    tmap = tier.drop_duplicates("journal_name").set_index("journal_name")
    tier["_article_n"] = pd.to_numeric(tier.iloc[:, 3], errors="coerce").fillna(0)
    status_article_sum = tier.groupby(tier.iloc[:, 12])["_article_n"].sum()
    raw_core = next((idx for idx, value in status_article_sum.items() if int(value) == 137), "")
    raw_noncore = next((idx for idx, value in status_article_sum.items() if int(value) == 127), "")
    m["tier_match"] = m["journal_norm"].isin(tmap.index)
    for name in ["CORE_latest", "overall_status", "evidence_url", "evidence_list_name", "evidence_matched_string", "match_method", "coverage_scope", "coverage_codes"]:
        m[name] = m["journal_norm"].map(tmap[name]).fillna("") if name in tmap.columns else ""
    def tier_status(row):
        evidence = all(s(row[c]) for c in ["evidence_url", "evidence_list_name", "evidence_matched_string"])
        if s(row["overall_status"]) == raw_core and evidence:
            return "CORE_CONFIRMED"
        if s(row["overall_status"]) == raw_noncore and row["match_method"] == "complete_coverage_no_match":
            return "CONFIRMED_NON_CORE"
        return "PENDING"
    m["tier_status"] = m.apply(tier_status, axis=1)
    m["reuse_source"] = np.where(m["dept_match"], "task3_department_coding_k13", "unmatched")
    m.loc[m["source"].eq("WoS") & m["source_record_id"].isin(country.source_record_id), "country_reuse_source"] = "task4_country_groups_k13"
    m["country_reuse_source"] = m["country_reuse_source"].fillna("unmatched")
    return m


def phase_b0(m):
    rows = []
    for src, label in [("task3_department_coding_k13", "department reuse"), ("task4_country_groups_k13", "country reuse"), ("task5_analysis_payload", "journal tier reuse")]:
        if src.startswith("task3"):
            total = len(m); matched = int(m.dept_match.sum())
        elif src.startswith("task4"):
            total = int((m.source == "WoS").sum()); matched = int(m.country_reuse_source.eq(src).sum())
        else:
            total = int((m.source == "CNKI").sum()); matched = int(m.tier_match[m.source.eq("CNKI")].sum())
        rows.append({"input": src, "purpose": label, "records_in_scope": total, "matched_records": matched, "match_rate": matched / total if total else np.nan, "status": "reused where matched; unmatched retained for audit"})
    return pd.DataFrame(rows)


def phase_b1(m):
    zh = m[m.source.eq("CNKI")].copy()
    def first_code(x):
        return s(x).split(";")[0].strip().upper() if s(x) else ""
    zh["clc_first"] = zh["clc_use"].map(first_code)
    zh["has_J"] = zh["clc_use"].str.split(";").map(lambda xs: any(s(v).upper().startswith("J") for v in xs if s(v)))
    zh["has_TP"] = zh["clc_use"].str.split(";").map(lambda xs: any(s(v).upper().startswith("TP") for v in xs if s(v)))
    zh["clc_layer"] = np.select([zh.clc_first.str.startswith("J"), zh.clc_first.str.startswith("TP"), zh.clc_first.eq("")], ["ZH-J", "ZH-TP", "ZH-missing"], default="ZH-other")
    zh["pure_layer"] = np.select([zh.has_J & ~zh.has_TP, zh.has_TP & ~zh.has_J], ["pure_J", "pure_TP"], default="mixed_or_other")
    out = []
    for group, q in list(zh.groupby("clc_layer")) + [("pure_J", zh[zh.pure_layer.eq("pure_J")]), ("pure_TP", zh[zh.pure_layer.eq("pure_TP")])]:
        for axis, topics in [("VALUE", VALUE), ("TECH", TECH), ("T00", {"T00"})]:
            k = int(q.topic_code.isin(topics).sum()); lo, hi = cp(k, len(q))
            out.append({"layer": group, "axis": axis, "topics": ";".join(sorted(topics)), "n": len(q), "numerator": k, "share": k/len(q) if len(q) else np.nan, "cp95_low": lo, "cp95_high": hi})
    # Pairwise topic and axis differences with Fisher p and Holm adjustment.
    pairs = [("ZH-J", "ZH-TP"), ("pure_J", "pure_TP"), ("pure_TP", "EN")]
    rows = []
    for ga, gb in pairs:
        a = zh[zh.clc_layer.eq(ga) if ga.startswith("ZH") else zh.pure_layer.eq(ga)]
        if gb == "EN":
            b = m[m.source.eq("WoS")]
        else:
            b = zh[zh.clc_layer.eq(gb) if gb.startswith("ZH") else zh.pure_layer.eq(gb)]
        tests = [("VALUE", VALUE)] + [(t, {t}) for t in TOPICS]
        for axis, topics in tests:
            va = a.topic_code.isin(topics).astype(int).to_numpy(); vb = b.topic_code.isin(topics).astype(int).to_numpy()
            tab, orv, p = fisher_binary(va, vb)
            diff, lo, hi = bootstrap_diff(va, vb)
            rows.append({"comparison": f"{ga} vs {gb}", "axis": axis, "n_a": len(va), "n_b": len(vb), "count_a": int(va.sum()), "count_b": int(vb.sum()), "difference_a_minus_b": diff, "bootstrap_ci_low": lo, "bootstrap_ci_high": hi, "fisher_p": p, "odds_ratio": orv})
    pr = pd.DataFrame(rows)
    # Holm correction within each comparison.
    for comp, idx in pr.groupby("comparison").groups.items():
        pvals = pr.loc[idx, "fisher_p"].to_numpy()
        order = np.argsort(pvals); adj = np.empty(len(pvals)); running = 0
        for rank, pos in enumerate(order):
            running = max(running, min(1.0, (len(pvals)-rank) * pvals[pos])); adj[pos] = running
        pr.loc[idx, "holm_p"] = adj
    diag = pd.DataFrame([{
        "j_first_with_TP_share": float((zh[zh.clc_layer.eq("ZH-J")].has_TP).mean()) if (zh.clc_layer.eq("ZH-J")).any() else np.nan,
        "tp_first_with_J_share": float((zh[zh.clc_layer.eq("ZH-TP")].has_J).mean()) if (zh.clc_layer.eq("ZH-TP")).any() else np.nan,
        "records_with_exactly_two_codes": int(zh.clc_use.str.split(";").map(lambda x: len([s(v) for v in x if s(v)]) == 2).sum()),
        "records_with_two_or_more_codes": int(zh.clc_use.str.split(";").map(lambda x: len([s(v) for v in x if s(v)]) >= 2).sum()),
        "journal_overlap_weighted": np.nan,
        "journal_overlap_jaccard": float(len(set(zh[zh.clc_layer.eq("ZH-J")].journal_norm) & set(zh[zh.clc_layer.eq("ZH-TP")].journal_norm)) / max(1, len(set(zh[zh.clc_layer.eq("ZH-J")].journal_norm) | set(zh[zh.clc_layer.eq("ZH-TP")].journal_norm))))
    }])
    return zh, pd.DataFrame(out), pr, diag


def phase_b2(m):
    zh = m[m.source.eq("CNKI")].copy()
    rows = []
    for tier_name, q in [("CORE", zh[zh.tier_status.eq("CORE_CONFIRMED")]), ("CONFIRMED_NON_CORE", zh[zh.tier_status.eq("CONFIRMED_NON_CORE")]), ("PENDING", zh[zh.tier_status.eq("PENDING")]), ("WoS", m[m.source.eq("WoS")])]:
        for t in TOPICS:
            k = int(q.topic_code.eq(t).sum()); lo, hi = cp(k, len(q))
            rows.append({"tier": tier_name, "topic_code": t, "n": len(q), "count": k, "share": k/len(q) if len(q) else np.nan, "cp95_low": lo, "cp95_high": hi})
    shares = pd.DataFrame(rows)
    pre = zh[zh.tier_status.eq("CORE_CONFIRMED") & zh.year.lt(2023)][["journal", "year", "title", "topic_code"]].copy()
    pre = pre.sort_values(["year", "journal", "title"])
    keep = zh[~(zh.tier_status.eq("CORE_CONFIRMED") & zh.year.lt(2023))]
    excl = []
    for label, q in [("CORE", zh[zh.tier_status.eq("CORE_CONFIRMED")]), ("CONFIRMED_NON_CORE", zh[zh.tier_status.eq("CONFIRMED_NON_CORE")]), ("PENDING", zh[zh.tier_status.eq("PENDING")]), ("LOOSE_CORE", zh[zh.tier_status.isin(["CORE_CONFIRMED", "PENDING"])]), ("WoS", m[m.source.eq("WoS")])]:
        v = int(q.topic_code.isin(VALUE).sum()); lo, hi = cp(v, len(q)); excl.append({"subset": label, "n": len(q), "value_n": v, "value_share": v/len(q) if len(q) else np.nan, "cp95_low": lo, "cp95_high": hi})
    q = keep
    v = int(q[q.source.eq("CNKI")].topic_code.isin(VALUE).sum()); den = int(q.source.eq("CNKI").sum())
    excl.append({"subset": "CNKI_after_pre2023_CORE_exclusion", "n": den, "value_n": v, "value_share": v/den if den else np.nan, "cp95_low": cp(v, den)[0], "cp95_high": cp(v, den)[1]})
    boot = []
    for mode, core_mask in [("STRICT", zh.tier_status.eq("CORE_CONFIRMED")), ("LOOSE", zh.tier_status.isin(["CORE_CONFIRMED", "PENDING"])), ("EXCLUDE", zh.tier_status.ne("PENDING"))]:
        core = zh[core_mask].topic_code.isin(VALUE).astype(int).to_numpy()
        non = zh[zh.tier_status.eq("CONFIRMED_NON_CORE")].topic_code.isin(VALUE).astype(int).to_numpy()
        wos = m[m.source.eq("WoS")].topic_code.isin(VALUE).astype(int).to_numpy()
        for label, other in [("WoS", wos), ("CONFIRMED_NON_CORE", non)]:
            diff, lo, hi = bootstrap_diff(core, other)
            boot.append({"mode": mode, "comparison": f"CORE - {label}", "CORE_n": len(core), "other_n": len(other), "CORE_value_share": core.mean() if len(core) else np.nan, "other_value_share": other.mean() if len(other) else np.nan, "difference": diff, "ci_low": lo, "ci_high": hi, "bootstrap_reps": 5000, "seed": 42})
    profile = []
    for y, q in zh[zh.tier_status.eq("CORE_CONFIRMED")].groupby("year"):
        profile.append({"profile": "year", "value": y, "n": len(q), "details": ""})
    for c, q in zh[zh.tier_status.eq("CORE_CONFIRMED")].assign(clc_first=zh[zh.tier_status.eq("CORE_CONFIRMED")].clc_use.map(lambda x: s(x).split(";")[0].strip().upper() if s(x) else "")).groupby("clc_first"):
        profile.append({"profile": "CLC_first", "value": c, "n": len(q), "details": ""})
    for dept, q in zh[zh.tier_status.eq("CORE_CONFIRMED")].groupby("dept_type"):
        profile.append({"profile": "dept_type", "value": dept, "n": len(q), "details": ""})
    return shares, pre, pd.DataFrame(excl), pd.DataFrame(boot), pd.DataFrame(profile)


def phase_b3(m):
    rows = []
    for group in ["ZH", "EN-CN", "EN-CN-strict", "EN-NC", "EN"]:
        if group == "EN": q = m[m.source.eq("WoS")]
        elif group == "EN-CN-strict": q = m[m.en_cn_strict]
        else: q = m[m.analysis_group.eq(group)]
        for dept in ["ART", "CS", "BOTH", "UNKNOWN", "ALL"]:
            z = q if dept == "ALL" else q[q.dept_type.eq(dept)]
            for axis, topics in [("VALUE", VALUE), ("TECH", TECH)]:
                k = int(z.topic_code.isin(topics).sum()); lo, hi = cp(k, len(z))
                rows.append({"group": group, "dept_type": dept, "axis": axis, "n": len(z), "numerator": k, "share": k/len(z) if len(z) else np.nan, "cp95_low": lo, "cp95_high": hi})
    audit = m[m.source.eq("WoS")][["doc_id", "source_record_id", "title", "journal", "first_seg", "department_name", "dept_type", "coding_status", "parse_failure_flag", "topic_code", "analysis_group"]].copy()
    value_en = m[m.source.eq("WoS") & m.topic_code.isin(VALUE)][["doc_id", "source_record_id", "title", "journal", "first_seg", "department_name", "dept_type", "coding_status", "topic_code", "analysis_group"]].copy()
    return pd.DataFrame(rows), audit, value_en


def phase_b4(m):
    q = m[m.source.eq("WoS")].copy()
    q["country_group"] = q["geographic_group"]
    rows = []
    for g, z in q.groupby("country_group"):
        for axis, topics in [("VALUE", VALUE), ("TECH", TECH)]:
            k = int(z.topic_code.isin(topics).sum()); lo, hi = cp(k, len(z))
            rows.append({"country_group": g, "axis": axis, "n": len(z), "numerator": k, "share": k/len(z), "cp95_low": lo, "cp95_high": hi})
    pairs = []
    base = q[q.country_group.eq("CN")]
    for g in sorted(q.country_group.dropna().unique()):
        if g == "CN": continue
        b = q[q.country_group.eq(g)]
        for axis, topics in [("VALUE", VALUE), ("TECH", TECH)]:
            va = base.topic_code.isin(topics).astype(int).to_numpy(); vb = b.topic_code.isin(topics).astype(int).to_numpy()
            tab, orv, p = fisher_binary(va, vb); diff, lo, hi = bootstrap_diff(va, vb)
            pairs.append({"comparison": f"{g} vs CN", "axis": axis, "n_a": len(vb), "n_b": len(va), "count_a": int(vb.sum()), "count_b": int(va.sum()), "difference_a_minus_b": diff, "ci_low": lo, "ci_high": hi, "fisher_p": p, "odds_ratio": orv})
    anglo = q[q.country_group.eq("ANGLO")]; non = q[~q.country_group.isin(["CN", "ANGLO"])]
    for axis, topics in [("VALUE", VALUE), ("TECH", TECH)]:
        va = anglo.topic_code.isin(topics).astype(int).to_numpy(); vb = non.topic_code.isin(topics).astype(int).to_numpy()
        tab, orv, p = fisher_binary(va, vb); diff, lo, hi = bootstrap_diff(va, vb)
        pairs.append({"comparison": "ANGLO vs non-CN/non-ANGLO", "axis": axis, "n_a": len(va), "n_b": len(vb), "count_a": int(va.sum()), "count_b": int(vb.sum()), "difference_a_minus_b": diff, "ci_low": lo, "ci_high": hi, "fisher_p": p, "odds_ratio": orv})
    binary = []
    for ga, gb, label in [("EN-CN", "EN-NC", "primary"), ("CN", "EN-NC", "strict_CN_vs_EN-NC")]:
        a = q[q.analysis_group.eq(ga)] if ga.startswith("EN") else q[q.country_group.eq(ga)]
        b = q[q.analysis_group.eq(gb)] if gb.startswith("EN") else q[q.country_group.eq(gb)]
        for axis, topics in [("VALUE", VALUE), ("TECH", TECH)]:
            va = a.topic_code.isin(topics).astype(int).to_numpy(); vb = b.topic_code.isin(topics).astype(int).to_numpy()
            tab, orv, p = fisher_binary(va, vb); diff, lo, hi = bootstrap_diff(va, vb)
            binary.append({"comparison": label, "group_a": ga, "group_b": gb, "axis": axis, "n_a": len(va), "n_b": len(vb), "count_a": int(va.sum()), "count_b": int(vb.sum()), "difference_a_minus_b": diff, "ci_low": lo, "ci_high": hi, "fisher_p": p, "odds_ratio": orv})
    return pd.DataFrame(rows), pd.DataFrame(pairs), pd.DataFrame(binary), q[["source_record_id", "first_author_country_clean", "geographic_group", "analysis_group", "topic_code"]]


def phase_b5():
    return pd.DataFrame([
        {"explanation": "学科建制", "prediction": "ZH-J 与 ZH-TP 的 VALUE/TECH 分布不同；纯 TP 若接近 EN，则语言差异可能是学科组成代理", "test": "CLC 首码、纯 J/TP 子集与 EN 比较", "key_sheet": "B1_CLC_Layers/B1_CLC_Pairwise", "author_judgement": ""},
        {"explanation": "期刊层级", "prediction": "CORE、NON_CORE 与 WoS 的主题分布不同", "test": "三档期刊层级与 WoS 轴占比、bootstrap", "key_sheet": "B2_Tier_Shares/B2_Tier_Bootstrap", "author_judgement": ""},
        {"explanation": "作者院系", "prediction": "ART 子集的轴占比与整体分布不同", "test": "ART/CS/BOTH/UNKNOWN 分层", "key_sheet": "B3_Dept_Axis/B3_ART_Audit", "author_judgement": ""},
        {"explanation": "作者国别", "prediction": "CN、ANGLO、EURO、EASIA、OTHER 的轴占比不同", "test": "五国别组与 CN 基准比较", "key_sheet": "B4_Country_Shares/B4_Country_Pairwise", "author_judgement": ""},
    ])


def phase_c(d, old):
    rows = []
    def current_pair(a, b, axis_set, label):
        va = a.topic_code.isin(axis_set).astype(int).to_numpy(); vb = b.topic_code.isin(axis_set).astype(int).to_numpy()
        tab, orv, p = fisher_binary(va, vb)
        rows.append({"scope": label, "axis_set": ";".join(sorted(axis_set)), "n_EN_CN": len(va), "n_EN_NC": len(vb), "count_EN_CN": int(va.sum()), "count_EN_NC": int(vb.sum()), "share_EN_CN": va.mean(), "share_EN_NC": vb.mean(), "odds_ratio": orv, "fisher_p": p})
    ec = d[d.analysis_group.eq("EN-CN")]; enc_group = d[d.analysis_group.eq("EN-NC")]; ecs = d[d.en_cn_strict]
    current_pair(ec, enc_group, VALUE, "K15_AXIS_main")
    current_pair(ecs, enc_group, VALUE, "K15_AXIS_main_strict")
    current_pair(ec, enc_group, VALUE_WIDE, "K15_AXIS_wide")
    # Across-K aggregate data-driven blocks.
    for k in range(8, 19):
        sh = pd.read_excel(SOURCE, sheet_name=f"Shares_k{k}", dtype=object).fillna(0)
        sh["topic_code"] = sh["topic_code"].map(norm_topic)
        z = sh["ZH"].to_numpy(float); ecn = sh["EN-CN"].to_numpy(float); enc = sh["EN-NC"].to_numpy(float)
        en_counts = ecn + enc
        for rule, mask in [("ZH_dominant_ge90", z/(z+en_counts+1e-12) >= .9), ("ZH_strict_majority", z/(z+en_counts+1e-12) > .5)]:
            a = ecn[mask].sum(); b = enc[mask].sum()
            table = np.array([[a, ecn.sum()-a], [b, enc.sum()-b]], dtype=int)
            orv, p = fisher_exact(table)
            rows.append({"scope": f"K{k}_{rule}", "axis_set": "data-driven ZH block", "n_EN_CN": int(ecn.sum()), "n_EN_NC": int(enc.sum()), "count_EN_CN": int(a), "count_EN_NC": int(b), "share_EN_CN": a/ecn.sum(), "share_EN_NC": b/enc.sum(), "odds_ratio": float(orv), "fisher_p": float(p)})
    # Old K=12 replication and migration.
    wo = old[old.source.eq("WoS")].copy()
    v = wo.topic_int.isin([0, 5, 6])
    a = wo.analysis_group3.eq("WoS_FirstAuthor_Mainland"); b = wo.analysis_group3.eq("WoS_FirstAuthor_Nonmainland")
    tab = [[int((a&v).sum()), int((a&~v).sum())], [int((b&v).sum()), int((b&~v).sum())]]
    orv, p = fisher_exact(tab)
    rows.append({"scope": "K12_old_value_T00_T05_T06", "axis_set": "old topic 0+5+6", "n_EN_CN": int(a.sum()), "n_EN_NC": int(b.sum()), "count_EN_CN": int((a&v).sum()), "count_EN_NC": int((b&v).sum()), "share_EN_CN": float((a&v).sum()/a.sum()), "share_EN_NC": float((b&v).sum()/b.sum()), "odds_ratio": float(orv), "fisher_p": float(p)})
    old_eng = wo[v].copy()
    old_eng = old_eng.merge(d[["source_record_id", "topic_code"]], on="source_record_id", how="left", suffixes=("_old", "_k15"))
    mig = old_eng[["source_record_id", "title", "journal", "analysis_group3", "topic_int", "topic_name_en", "topic_code"]].copy()
    mig["old_topic_code"] = mig["topic_int"].map(lambda x: f"T{int(x):02d}")
    # C3 JSD across K and current K15 bootstrap difference.
    jsd_rows = []
    for k in range(8, 19):
        sh = pd.read_excel(SOURCE, sheet_name=f"Shares_k{k}", dtype=object).fillna(0)
        a = sh["EN-CN"].to_numpy(float); b = sh["EN-NC"].to_numpy(float); z = sh["ZH"].to_numpy(float)
        jsd_rows.append({"K": k, "jsd_ZH_EN_CN": jsd_counts(z, a), "jsd_ZH_EN_NC": jsd_counts(z, b), "difference_ZH_EN_CN_minus_EN_NC": jsd_counts(z, a)-jsd_counts(z, b), "source": "Shares_k point estimates"})
    rng = np.random.default_rng(42); diffs = []
    for _ in range(2000):
        za = d[d.source.eq("CNKI")].sample(len(d[d.source.eq("CNKI")]), replace=True, random_state=int(rng.integers(1, 2**31-1))).topic_code.value_counts().reindex(TOPICS, fill_value=0).to_numpy()
        ec_a = ec.sample(len(ec), replace=True, random_state=int(rng.integers(1, 2**31-1))).topic_code.value_counts().reindex(TOPICS, fill_value=0).to_numpy()
        en_b = enc_group.sample(len(enc_group), replace=True, random_state=int(rng.integers(1, 2**31-1))).topic_code.value_counts().reindex(TOPICS, fill_value=0).to_numpy()
        diffs.append(jsd_counts(za, ec_a)-jsd_counts(za, en_b))
    jsd_rows.append({"K": 15, "jsd_ZH_EN_CN": jsd_counts(d[d.source.eq("CNKI")].topic_code.value_counts().reindex(TOPICS, fill_value=0), ec.topic_code.value_counts().reindex(TOPICS, fill_value=0)), "jsd_ZH_EN_NC": jsd_counts(d[d.source.eq("CNKI")].topic_code.value_counts().reindex(TOPICS, fill_value=0), enc_group.topic_code.value_counts().reindex(TOPICS, fill_value=0)), "difference_ZH_EN_CN_minus_EN_NC": float(np.mean(diffs)), "bootstrap_ci_low": float(np.quantile(diffs,.025)), "bootstrap_ci_high": float(np.quantile(diffs,.975)), "source": "K15 document bootstrap"})
    return pd.DataFrame(rows), mig, pd.DataFrame(jsd_rows)


def main():
    d, dept, country, tier, old = load_inputs()
    m = merge_reused_coding(d, dept, country, tier)
    tables = {}
    tables["B0_Coding_Reuse_Log"] = phase_b0(m)
    zh_clc, tables["B1_CLC_Layers"], tables["B1_CLC_Pairwise"], tables["B1_CLC_Diagnostics"] = phase_b1(m)
    tables["B2_Tier_Shares"], tables["B2_Pre2023_CORE"], tables["B2_Pre2023_Exclusion"], tables["B2_Tier_Bootstrap"], tables["B2_Core_Profile"] = phase_b2(m)
    tables["B3_Dept_Axis"], tables["B3_Audit_List"], tables["B3_VALUE_EN_Audit"] = phase_b3(m)
    tables["B4_Country_Shares"], tables["B4_Country_Pairwise"], tables["B4_Binary"], tables["B4_Country_Map"] = phase_b4(m)
    tables["B5_Competing_Explanations"] = phase_b5()
    tables["C1_OR_Robustness"], tables["C2_Doc_Migration"], tables["C3_Distance_Direction"] = phase_c(d, old)
    for name, df in tables.items():
        write_table(name, df)
    payload = {name: {"columns": list(df.columns), "rows": df.replace([np.inf, -np.inf], np.nan).replace({np.nan: None}).to_dict(orient="records")} for name, df in tables.items()}
    (OUT / "phase_bc_payload.json").write_text(json.dumps(payload, ensure_ascii=False, default=str), encoding="utf-8")
    report = [
        "# Phase B 与 C 报告",
        "",
        "本阶段固定使用 1427 条 Corpus_Master 与 K=15 topic_code。Phase B 复用既有 K=13 的院系、国别和期刊证据，仅将其按记录键映射到当前主表；主题轴使用 K=15 定义。",
        "",
        f"- 记录数：{len(d)}；ZH={int((d.source=='CNKI').sum())}；WoS={int((d.source=='WoS').sum())}。",
        f"- 院系匹配：{int(m.dept_match.sum())}/{len(m)}；WoS 国别匹配：{int(m.country_reuse_source.eq('task4_country_groups_k13').sum())}/{int((m.source=='WoS').sum())}。",
        f"- 期刊分层状态：CORE={int((m.tier_status=='CORE_CONFIRMED').sum())}，CONFIRMED_NON_CORE={int((m.tier_status=='CONFIRMED_NON_CORE').sum())}，PENDING={int((m.tier_status=='PENDING').sum())}（含 WoS 行，中文期刊分析见 B2）。",
        "",
        "## 预设假设判断",
        "",
        "本阶段仅报告重算结果，不替作者预先填写 B5 的解释判定。K12 旧口径复现是否与 K15 方向一致，见 C1_OR_Robustness；K15 的 JSD 方向与跨 K 变化见 C3_Distance_Direction。",
        "",
        "E5 模型 revision 未记录，未执行任何需要重新嵌入的 Phase E/F。",
    ]
    (OUT / "phase_bc_report.md").write_text("\n".join(report), encoding="utf-8")
    print(json.dumps({"tables": list(tables), "rows": len(d), "dept_match": int(m.dept_match.sum()), "country_match": int(m.country_reuse_source.eq('task4_country_groups_k13').sum())}, ensure_ascii=False))


if __name__ == "__main__":
    main()
