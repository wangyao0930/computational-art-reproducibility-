# Recovered historical source; run only from historical/ after supplying documented inputs.
from __future__ import annotations

import argparse
import json
import math
import os
import re
import sys
import time
import unicodedata
from importlib.metadata import PackageNotFoundError, version as package_version
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.spatial.distance import jensenshannon
from scipy.stats import beta, binom, fisher_exact
from scipy.stats import contingency

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "output" / "final_rebuild_20260927_1427" / "computational_art_final_rebuild_1427.xlsx"
OUT = ROOT / "outputs" / "rerun_1427_k15"
OUT.mkdir(parents=True, exist_ok=True)
SEEDS = [42, 7, 123, 2024, 999]
TOPICS = [f"T{i:02d}" for i in range(15)]
LABELS_ZH = {
    "T00": "人工智能艺术的本体与主体性", "T01": "数字媒体艺术与生成设计",
    "T02": "异质计算方法（残余类）", "T03": "遗产传承与传统工艺",
    "T04": "音乐生成与作曲", "T05": "图像生成与风格迁移",
    "T06": "人工智能在艺术设计中的应用", "T07": "影视动画与插画创作",
    "T08": "绘画图像的机器分类与分析", "T09": "计算艺术与生成艺术的理论阐释",
    "T10": "博物馆展陈与遗产数字技术", "T11": "AIGC 内容生产与艺术创作",
    "T12": "计算美学与审美评估", "T13": "人工智能绘画的伦理、版权与归属",
    "T14": "舞蹈生成与编舞",
}
LABELS_EN = {
    "T00": "Ontology and creative subjecthood in AI art", "T01": "Digital media art and generative design",
    "T02": "Heterogeneous computational methods (residual)", "T03": "Heritage transmission and traditional craft",
    "T04": "Music generation and composition", "T05": "Image generation and style transfer",
    "T06": "AI in art and design practice", "T07": "Film, animation and illustration",
    "T08": "Machine classification and analysis of paintings", "T09": "Theorising computational and generative art",
    "T10": "Museum display and digital heritage technologies", "T11": "AIGC content production and art creation",
    "T12": "Computational aesthetics and aesthetic assessment", "T13": "Ethics, copyright and attribution in AI painting",
    "T14": "Dance generation and choreography",
}
AXIS_MAIN = {"VALUE": {"T00", "T13", "T03"}, "TECH": {"T05", "T08", "T12", "T02"}}
AXIS_WIDE = {"VALUE_wide": AXIS_MAIN["VALUE"] | {"T09", "T11"}, "TECH_narrow": {"T05", "T08", "T12"}}


def s(x) -> str:
    if x is None or (isinstance(x, float) and np.isnan(x)):
        return ""
    return str(x).strip()


def env_versions() -> dict[str, str]:
    out = {"python": sys.version.split()[0]}
    for name in ["numpy", "pandas", "scipy", "scikit-learn", "umap-learn", "jieba", "sentence-transformers", "openpyxl"]:
        try:
            out[name] = package_version(name)
        except PackageNotFoundError:
            out[name] = "not installed"
    return out


def normalize_topic(x: object) -> str:
    x = s(x)
    if not x:
        return ""
    if x.upper().startswith("T"):
        return f"T{int(x[1:]):02d}"
    return f"T{int(float(x)):02d}"


def first_address_segment(x: object) -> str:
    # WoS author names can contain semicolons inside brackets. Remove all bracketed
    # author lists before splitting the address string.
    x = re.sub(r"\[[^\]]*\]", "", s(x))
    return x.split(";")[0].strip(" ,")


def strict_en_cn(d: pd.DataFrame) -> pd.Series:
    first = d["institution_or_address"].map(first_address_segment)
    is_cn = d["analysis_group"].eq("EN-CN")
    special = first.str.contains(r"Hong Kong|Macau|Macao", case=False, regex=True, na=False)
    guangzhou_campus = first.str.contains("Guangzhou Campus", case=False, regex=False, na=False)
    return is_cn & ~(special & ~guangzhou_campus)


def cp_interval(k: int, n: int) -> tuple[float, float]:
    if n <= 0:
        return np.nan, np.nan
    lo = 0.0 if k == 0 else float(beta.ppf(0.025, k, n - k + 1))
    hi = 1.0 if k == n else float(beta.ppf(0.975, k + 1, n - k))
    return lo, hi


def one_sided_upper(k: int, n: int) -> float:
    if n <= 0:
        return np.nan
    return 1.0 if k == n else float(beta.ppf(0.95, k + 1, n - k))


def min_detectable_n(t: float) -> int:
    return int(math.ceil(math.log(0.025) / math.log(1 - t)))


def bootstrap_difference(a: np.ndarray, b: np.ndarray, reps: int, seed: int) -> tuple[float, float, float]:
    if len(a) == 0 or len(b) == 0:
        return np.nan, np.nan, np.nan
    rng = np.random.default_rng(seed)
    vals = np.empty(reps, dtype=float)
    for i in range(reps):
        vals[i] = a[rng.integers(0, len(a), len(a))].mean() - b[rng.integers(0, len(b), len(b))].mean()
    return float(a.mean() - b.mean()), float(np.quantile(vals, 0.025)), float(np.quantile(vals, 0.975))


def odds_ratio_ci(table: np.ndarray) -> tuple[float, float, float]:
    try:
        result = contingency.odds_ratio(table, kind="conditional")
        ci = result.confidence_interval(confidence_level=0.95)
        return float(result.statistic), float(ci.low), float(ci.high)
    except Exception:
        a, b, c, d = [float(x) for x in table.ravel()]
        orv = ((a + 0.5) * (d + 0.5)) / ((b + 0.5) * (c + 0.5))
        se = math.sqrt(1 / (a + 0.5) + 1 / (b + 0.5) + 1 / (c + 0.5) + 1 / (d + 0.5))
        return orv, math.exp(math.log(orv) - 1.96 * se), math.exp(math.log(orv) + 1.96 * se)


def fisher_row(a: np.ndarray, b: np.ndarray, label_a: str, label_b: str, outcome: str) -> dict:
    aa = int(a.sum()); bb = int(b.sum())
    table = np.array([[aa, len(a) - aa], [bb, len(b) - bb]], dtype=int)
    p = float(fisher_exact(table, alternative="two-sided").pvalue)
    orv, lo, hi = odds_ratio_ci(table)
    return {"comparison": f"{label_a} vs {label_b}", "outcome": outcome, "numerator_a": aa,
            "denominator_a": len(a), "share_a": aa / len(a) if len(a) else np.nan,
            "numerator_b": bb, "denominator_b": len(b), "share_b": bb / len(b) if len(b) else np.nan,
            "difference_a_minus_b": aa / len(a) - bb / len(b) if len(a) and len(b) else np.nan,
            "fisher_p_two_sided": p, "odds_ratio_conditional": orv, "or_ci_low": lo, "or_ci_high": hi,
            "method": "Fisher exact; conditional maximum-likelihood odds ratio"}


def jsd_from_counts(a: np.ndarray, b: np.ndarray) -> float:
    pa = a.astype(float) / a.sum() if a.sum() else np.zeros_like(a, dtype=float)
    pb = b.astype(float) / b.sum() if b.sum() else np.zeros_like(b, dtype=float)
    return float(jensenshannon(pa, pb, base=2) ** 2)


def group_mask(d: pd.DataFrame, group: str) -> pd.Series:
    """Return an independent mask for each reporting group.

    EN is the pooled WoS population.  EN-CN-strict is a sensitivity subset and
    must not overwrite the original EN-CN assignment used for the primary
    denominators.
    """
    if group == "EN":
        return d["source"].eq("WoS")
    if group == "EN-CN-strict":
        return d["en_cn_strict"].astype(bool)
    return d["analysis_group"].eq(group)


def group_subset(d: pd.DataFrame, group: str) -> pd.DataFrame:
    return d.loc[group_mask(d, group)].copy()


def topic_counts(d: pd.DataFrame, g1: str, g2: str, topic_col: str = "topic_code") -> tuple[np.ndarray, np.ndarray]:
    a = group_subset(d, g1)
    b = group_subset(d, g2)
    return (a[topic_col].value_counts().reindex(TOPICS, fill_value=0).to_numpy(dtype=int),
            b[topic_col].value_counts().reindex(TOPICS, fill_value=0).to_numpy(dtype=int))


def separation(d: pd.DataFrame, g1: str, g2: str, reps: int = 5000, seed: int = 42) -> tuple[dict, pd.DataFrame]:
    mask_a = group_mask(d, g1)
    mask_b = group_mask(d, g2)
    sub = d.loc[mask_a | mask_b].copy()
    ca, cb = topic_counts(sub, g1, g2)
    rho = float(np.minimum(ca, cb).sum() / len(sub))
    rand = min(ca.sum(), cb.sum()) / len(sub)
    labels = np.where(group_mask(sub, g1), g1, g2)
    topics = sub.topic_code.to_numpy()
    rng = np.random.default_rng(seed)
    perm = np.empty(reps, dtype=float)
    for i in range(reps):
        shuffled = labels.copy(); rng.shuffle(shuffled)
        xa = np.array([np.sum((topics == t) & (shuffled == g1)) for t in TOPICS])
        xb = np.array([np.sum((topics == t) & (shuffled == g2)) for t in TOPICS])
        perm[i] = np.minimum(xa, xb).sum() / len(sub)
    mean_perm = float(perm.mean())
    row = {"source_a": g1, "source_b": g2, "N_a": int(ca.sum()), "N_b": int(cb.sum()),
           "sum_min": int(np.minimum(ca, cb).sum()), "rho_observed": rho,
           "rho_rand_analytic": rand, "S_analytic": 1 - rho / rand if rand else np.nan,
           "rho_perm_mean": mean_perm, "rho_perm_p025": float(np.quantile(perm, .025)),
           "rho_perm_p975": float(np.quantile(perm, .975)),
           "S_perm": 1 - rho / mean_perm if mean_perm else np.nan,
           "permutation_p_P_rho_perm_le_observed": float(np.mean(perm <= rho)), "reps": reps, "seed": seed,
           "method": "topic-preserving source-label permutation"}
    detail = pd.DataFrame({"topic_code": TOPICS,
                           "topic_label_zh_v2": [LABELS_ZH[x] for x in TOPICS],
                           "count_a": ca, "count_b": cb,
                           "share_a_within_topic": [ca[i] / (ca[i] + cb[i]) if ca[i] + cb[i] else np.nan for i in range(len(TOPICS))],
                           "strict_majority_source": [g1 if ca[i] > (ca[i] + cb[i]) / 2 else (g2 if cb[i] > (ca[i] + cb[i]) / 2 else "tie") for i in range(len(TOPICS))],
                           "overproportion_source": [g1 if ca[i] > (ca.sum() / (ca.sum() + cb.sum())) * (ca[i] + cb[i]) else (g2 if cb[i] > (cb.sum() / (ca.sum() + cb.sum())) * (ca[i] + cb[i]) else "none") for i in range(len(TOPICS))],
                           "cross_source_min_count": np.minimum(ca, cb)})
    return row, detail


def load_corpus() -> pd.DataFrame:
    if not SOURCE.exists():
        raise FileNotFoundError(f"Missing frozen workbook: {SOURCE}")
    allowed = ["Corpus_Master", "Assignments"] + [f"Shares_k{k}" for k in range(8, 19)] + [f"TopTerms_k{k}" for k in range(8, 19)] + ["K_Selection", "Stability_Grid", "Model_Parameters"]
    xl = pd.ExcelFile(SOURCE)
    missing = [x for x in allowed if x not in xl.sheet_names]
    if missing:
        raise FileNotFoundError(f"Missing allowed sheets: {missing}")
    d = pd.read_excel(SOURCE, sheet_name="Corpus_Master", dtype=object).fillna("")
    d.columns = d.columns.str.replace("\ufeff", "", regex=False)
    if len(d) != 1427 or d.doc_id.nunique() != 1427:
        raise ValueError(f"Corpus sanity failed: rows={len(d)}, unique_doc_id={d.doc_id.nunique()}")
    if d.analysis_group.value_counts().to_dict() != {"ZH": 896, "EN-NC": 288, "EN-CN": 243}:
        raise ValueError(f"Group counts failed: {d.analysis_group.value_counts().to_dict()}")
    d["topic_code"] = d["topic_code"].map(normalize_topic)
    d["year"] = pd.to_numeric(d["year"], errors="coerce")
    d["en_cn_strict"] = strict_en_cn(d)
    d["group_for_strict"] = np.where(d.analysis_group.eq("ZH"), "ZH", np.where(d.en_cn_strict, "EN-CN-strict", np.where(d.analysis_group.eq("EN-CN"), "EN-CN-HK-Macau", "EN-NC")))
    return d


def phase_sanity(d: pd.DataFrame) -> dict[str, pd.DataFrame]:
    rows = []
    for g, n in d.analysis_group.value_counts().sort_index().items():
        rows.append({"check": f"group_count_{g}", "expected": {"ZH": 896, "EN-CN": 243, "EN-NC": 288}.get(g), "observed": int(n), "pass": bool(n == {"ZH": 896, "EN-CN": 243, "EN-NC": 288}.get(g)), "method": "Corpus_Master count"})
    rows.append({"check": "total_count", "expected": 1427, "observed": len(d), "pass": len(d) == 1427, "method": "Corpus_Master count"})
    topic_counts_all = d.topic_code.value_counts().reindex(TOPICS, fill_value=0)
    for t in TOPICS:
        rows.append({"check": f"topic_count_{t}", "expected": int(topic_counts_all[t]), "observed": int(topic_counts_all[t]), "pass": True, "method": "Corpus_Master topic_code"})
    # Compare against supplied Shares_k15 values.
    sh = pd.read_excel(SOURCE, sheet_name="Shares_k15", dtype=object).fillna(0)
    sh["topic_code"] = sh["topic_code"].map(normalize_topic)
    for t in TOPICS:
        actual = d[d.topic_code.eq(t)].analysis_group.value_counts().to_dict()
        supplied = sh[sh.topic_code.eq(t)].iloc[0].to_dict()
        ok = int(actual.get("ZH", 0)) == int(float(supplied.get("ZH", 0))) and int(actual.get("EN-CN", 0)) == int(float(supplied.get("EN-CN", 0))) and int(actual.get("EN-NC", 0)) == int(float(supplied.get("EN-NC", 0)))
        rows.append({"check": f"Shares_k15_{t}", "expected": f"ZH={actual.get('ZH',0)}; EN-CN={actual.get('EN-CN',0)}; EN-NC={actual.get('EN-NC',0)}", "observed": f"ZH={supplied.get('ZH',0)}; EN-CN={supplied.get('EN-CN',0)}; EN-NC={supplied.get('EN-NC',0)}", "pass": ok, "method": "independent count versus supplied Shares_k15"})
    vec = ROOT / "work" / "new_inputs" / "embeddings_1427.npy"
    mapping = ROOT / "work" / "new_inputs" / "vector_mapping_1427.csv"
    vector_rows = np.load(vec).shape[0] if vec.exists() else None
    vector_ok = vector_rows == 1427 and mapping.exists()
    rows.append({"check": "vector_row_count", "expected": 1427, "observed": vector_rows, "pass": vector_ok, "method": "embeddings_1427.npy and vector_mapping_1427.csv"})
    diffs = pd.DataFrame([{"source_record_id": "WOS:001060595700004", "title": "RETRACTION: Mural digital image restoration technology and stitching evaluation model based on machine learning (Retraction of December, 2022)", "old_group": "EN-NC", "reason": "retraction record removed from latest WoS_Included_Final"}, {"source_record_id": "WOS:001130364400005", "title": "RETRACTED: Revolutionizing animation: unleashing the power of artificial intelligence for cutting-edge visual effects in films (Retracted Article)", "old_group": "EN-NC", "reason": "retracted article removed from latest WoS_Included_Final"}])
    strict_excluded = d.loc[
        d.analysis_group.eq("EN-CN") & ~d.en_cn_strict,
        [c for c in ["doc_id", "source_record_id", "title", "journal", "institution_or_address", "topic_code"] if c in d.columns],
    ].copy()
    strict_excluded.insert(1, "exclusion_reason", "first-author address contains Hong Kong/Macau/Macao; Guangzhou Campus exception not triggered")
    years = d.groupby(["year", "analysis_group"], dropna=False).size().reset_index(name="n")
    return {"00_Sanity": pd.DataFrame(rows), "00_Removed_1429_to_1427": diffs, "00_EN_CN_strict_Excluded": strict_excluded, "00_Year_Group_Counts": years}


def phase_a(d: pd.DataFrame) -> dict[str, pd.DataFrame]:
    groups = ["ZH", "EN", "EN-CN", "EN-CN-strict", "EN-NC"]
    d_en = group_subset(d, "EN")
    # A1 counts and exact intervals.
    a1 = []
    detect = {0.01: min_detectable_n(0.01), 0.02: min_detectable_n(0.02), 0.03: min_detectable_n(0.03)}
    for t in TOPICS:
        for g in groups:
            sub = group_subset(d, g)
            k = int(sub.topic_code.eq(t).sum()); n = len(sub); lo, hi = cp_interval(k, n); upper = one_sided_upper(k, n)
            row = {"topic_code": t, "topic_label_zh_v2": LABELS_ZH[t], "topic_label_en_v2": LABELS_EN[t], "group": g, "numerator": k, "denominator": n, "share": k / n if n else np.nan, "cp95_low": lo, "cp95_high": hi, "one_sided_95_upper": upper, "method": "Clopper-Pearson exact binomial"}
            for tval in [0.01, 0.02, 0.03]:
                key = f"{int(tval*100)}pct"
                row[f"gap_strict_{key}"] = bool(hi < tval) if n else False
                row[f"near_gap_{key}"] = bool(k / n < tval and not (hi < tval)) if n else False
                row[f"one_sided_p_{key}"] = float(binom.cdf(k, n, tval)) if n else np.nan
                row[f"detectability_{key}"] = "undetectable_at_t" if n < detect[tval] else "detectable_n" + str(detect[tval])
            a1.append(row)
    a1df = pd.DataFrame(a1)
    # A1 paper table, ZH share descending.
    order = a1df[a1df.group.eq("ZH")].sort_values("share", ascending=False).topic_code.tolist()
    paper = []
    for t in order:
        r = {"topic_code": t, "topic_label_zh_v2": LABELS_ZH[t], "topic_label_en_v2": LABELS_EN[t]}
        for g in ["ZH", "EN-CN", "EN-CN-strict", "EN-NC", "EN"]:
            q = a1df[(a1df.topic_code == t) & (a1df.group == g)].iloc[0]
            r[g] = f"{int(q.numerator)}/{int(q.denominator)} ({q.share*100:.1f}%, {q.cp95_low*100:.1f}–{q.cp95_high*100:.1f})" if pd.notna(q.share) else "n.a."
        paper.append(r)
    p_df = pd.DataFrame(paper)
    # A2 axis table and pairwise tests.
    axis_rows = []
    for axis_name, topic_set in {**AXIS_MAIN, **AXIS_WIDE}.items():
        for g in groups:
            sub = group_subset(d, g)
            k = int(sub.topic_code.isin(topic_set).sum()); n = len(sub); lo, hi = cp_interval(k, n)
            axis_rows.append({"axis_set": axis_name, "topics": ";".join(sorted(topic_set)), "group": g, "numerator": k, "denominator": n, "share": k / n if n else np.nan, "cp95_low": lo, "cp95_high": hi, "method": "Clopper-Pearson exact binomial"})
    axis_table = pd.DataFrame(axis_rows)
    pair_rows = []
    for axis_name, topic_set in {**AXIS_MAIN, **AXIS_WIDE}.items():
        vals = {}
        for g in ["ZH", "EN", "EN-CN", "EN-NC"]:
            sub = group_subset(d, g)
            vals[g] = sub.topic_code.isin(topic_set).astype(int).to_numpy()
        for ga, gb in [("ZH", "EN"), ("ZH", "EN-CN"), ("ZH", "EN-NC"), ("EN-CN", "EN-NC")]:
            row = fisher_row(vals[ga], vals[gb], ga, gb, axis_name)
            bvals = []
            for seed in SEEDS:
                diff, lo, hi = bootstrap_difference(vals[ga], vals[gb], 5000, seed)
                bvals.append({"seed": seed, "bootstrap_difference": diff, "bootstrap_ci_low": lo, "bootstrap_ci_high": hi})
            br = bvals[0]
            row.update({"bootstrap_difference_seed42": br["bootstrap_difference"], "bootstrap_ci_low_seed42": br["bootstrap_ci_low"], "bootstrap_ci_high_seed42": br["bootstrap_ci_high"], "bootstrap_seed_stability": json.dumps(bvals, ensure_ascii=False)})
            pair_rows.append(row)
    pairwise = pd.DataFrame(pair_rows)
    # A3 separation.
    sep_rows, sep_details = [], []
    for ga, gb in [("ZH", "EN"), ("ZH", "EN-CN"), ("ZH", "EN-NC"), ("EN-CN", "EN-NC")]:
        row, detail = separation(d, ga, gb, reps=5000, seed=42); sep_rows.append(row); detail.insert(0, "source_pair", f"{ga} vs {gb}"); sep_details.append(detail)
    sep_df = pd.DataFrame(sep_rows); sep_detail_df = pd.concat(sep_details, ignore_index=True)
    # A4 JSD with bootstrap and EN internal permutation.
    jsd_rows = []; jsd_perm_rows = []
    for ga, gb in [("ZH", "EN"), ("ZH", "EN-CN"), ("ZH", "EN-NC"), ("EN-CN", "EN-NC")]:
        ca, cb = topic_counts(d, ga, gb); obs = jsd_from_counts(ca, cb); vals = []
        aa = group_subset(d, ga)
        bb = group_subset(d, gb)
        for i in range(2000):
            rng = np.random.default_rng(42 + i); xa = aa.iloc[rng.integers(0, len(aa), len(aa))].topic_code.value_counts().reindex(TOPICS, fill_value=0).to_numpy(); xb = bb.iloc[rng.integers(0, len(bb), len(bb))].topic_code.value_counts().reindex(TOPICS, fill_value=0).to_numpy(); vals.append(jsd_from_counts(xa, xb))
        jsd_rows.append({"source_a": ga, "source_b": gb, "jsd_observed_bits": obs, "bootstrap_ci_low": float(np.quantile(vals,.025)), "bootstrap_ci_high": float(np.quantile(vals,.975)), "bootstrap_reps": 2000, "seed": 42, "method": "within-group document bootstrap; Jensen-Shannon divergence base 2"})
    # Difference requested in A4.
    zecn = next(x for x in jsd_rows if x["source_a"] == "ZH" and x["source_b"] == "EN-CN")["jsd_observed_bits"]; zenc = next(x for x in jsd_rows if x["source_a"] == "ZH" and x["source_b"] == "EN-NC")["jsd_observed_bits"]
    jsd_rows.append({"source_a": "ZH", "source_b": "EN-CN minus EN-NC", "jsd_observed_bits": zecn - zenc, "bootstrap_ci_low": np.nan, "bootstrap_ci_high": np.nan, "bootstrap_reps": 2000, "seed": 42, "method": "difference of observed JSDs; bootstrap difference not retained in this phase"})
    en = d[d.source.eq("WoS")].copy(); lab = en.analysis_group.to_numpy(); topics = en.topic_code.to_numpy(); rng = np.random.default_rng(42); perm=[]
    for _ in range(5000):
        shuf=lab.copy(); rng.shuffle(shuf); xa=np.array([np.sum((topics==t)&(shuf=="EN-CN")) for t in TOPICS]); xb=np.array([np.sum((topics==t)&(shuf=="EN-NC")) for t in TOPICS]); perm.append(jsd_from_counts(xa,xb))
    jsd_perm_rows.append({"source_a":"EN-CN","source_b":"EN-NC","observed_jsd_bits":jsd_from_counts(*topic_counts(d,"EN-CN","EN-NC")),"zero_mean":float(np.mean(perm)),"zero_ci_low":float(np.quantile(perm,.025)),"zero_ci_high":float(np.quantile(perm,.975)),"permutation_p_greater_equal_observed":float(np.mean(np.asarray(perm)>=jsd_from_counts(*topic_counts(d,"EN-CN","EN-NC")))),"reps":5000,"seed":42,"method":"EN label permutation"})
    # A5 aggregated K grid.
    a5=[]
    for k in range(8,19):
        sh=pd.read_excel(SOURCE,sheet_name=f"Shares_k{k}",dtype=object).fillna(0); sh["topic_code"]=sh.topic_code.map(normalize_topic)
        for ga,gb in [("ZH","EN"),("ZH","EN-CN"),("ZH","EN-NC"),("EN-CN","EN-NC")]:
            ca=sh[ga].to_numpy(dtype=float); cb=(sh[gb].to_numpy(dtype=float) if gb!="EN" else sh["EN-CN"].to_numpy(dtype=float)+sh["EN-NC"].to_numpy(dtype=float)); ca=ca.astype(int); cb=cb.astype(int); rho=np.minimum(ca,cb).sum()/(ca.sum()+cb.sum()); rand=min(ca.sum(),cb.sum())/(ca.sum()+cb.sum()); dominant=((ca/(ca+cb+1e-15)>=.9)|(cb/(ca+cb+1e-15)>=.9)); a5.append({"K":k,"review_grid_K":k in [8,10,12,14,16,18],"source_a":ga,"source_b":gb,"sum_min":int(np.minimum(ca,cb).sum()),"rho":rho,"rho_rand":rand,"S_analytic":1-rho/rand if rand else np.nan,"jsd_bits":jsd_from_counts(ca,cb),"single_side_ge90_document_share":float((ca[dominant].sum()+cb[dominant].sum())/(ca.sum()+cb.sum())) if (ca.sum()+cb.sum()) else np.nan,"method":"aggregated Shares_k sheet; point estimates only"})
        # Data-driven dominance blocks for English groups.
        en_cn=sh["EN-CN"].to_numpy(dtype=float); en_nc=sh["EN-NC"].to_numpy(dtype=float); zh=sh["ZH"].to_numpy(dtype=float); en=en_cn+en_nc
        zh_dom=zh/(zh+en+1e-15)>=.9; en_dom=en/(zh+en+1e-15)>=.9
        for eg,ec in [("EN-CN",en_cn),("EN-NC",en_nc)]:
            a5.append({"K":k,"review_grid_K":k in [8,10,12,14,16,18],"source_a":"ZH_dominant_block","source_b":eg,"sum_min":np.nan,"rho":np.nan,"rho_rand":np.nan,"S_analytic":np.nan,"jsd_bits":np.nan,"single_side_ge90_document_share":float(ec[zh_dom].sum()/ec.sum()) if ec.sum() else np.nan,"method":"ZH share >=90% topics; aggregated point estimate"})
            a5.append({"K":k,"review_grid_K":k in [8,10,12,14,16,18],"source_a":"EN_dominant_block","source_b":eg,"sum_min":np.nan,"rho":np.nan,"rho_rand":np.nan,"S_analytic":np.nan,"jsd_bits":np.nan,"single_side_ge90_document_share":float(ec[en_dom].sum()/ec.sum()) if ec.sum() else np.nan,"method":"EN share >=90% topics; aggregated point estimate"})
    a5df=pd.DataFrame(a5)
    # A6 periods and yearly counts.
    period_rows=[]
    for period, mask in [("2019-2022", d.year.between(2019,2022)), ("2023-2026", d.year.between(2023,2026))]:
        sub=d[mask]
        for g in ["ZH","EN-CN","EN-NC"]:
            q=sub[sub.analysis_group.eq(g)]; k=int(q.topic_code.isin(AXIS_MAIN["VALUE"]).sum()); n=len(q); lo,hi=cp_interval(k,n); kt=int(q.topic_code.isin(AXIS_MAIN["TECH"]).sum()); tlo,thi=cp_interval(kt,n); period_rows += [{"period":period,"group":g,"axis":"VALUE","numerator":k,"denominator":n,"share":k/n if n else np.nan,"cp95_low":lo,"cp95_high":hi,"method":"Clopper-Pearson"},{"period":period,"group":g,"axis":"TECH","numerator":kt,"denominator":n,"share":kt/n if n else np.nan,"cp95_low":tlo,"cp95_high":thi,"method":"Clopper-Pearson"}]
    yearly=d.groupby(["year","analysis_group"],dropna=False).size().reset_index(name="n")
    # A7 shared journals and subset comparisons.
    def norm_journal(x):
        x=unicodedata.normalize("NFKC",s(x)).upper().replace("&","AND"); return re.sub(r"[^A-Z0-9]+","",x)
    w=d[d.source.eq("WoS")].copy(); w["journal_norm"]=w.journal.map(norm_journal); ec=set(w[w.analysis_group.eq("EN-CN")].journal_norm); en=set(w[w.analysis_group.eq("EN-NC")].journal_norm); shared=ec&en
    shared_rows=pd.DataFrame([{"journal_norm":j,"journal_example":w[w.journal_norm.eq(j)].journal.iloc[0],"EN_CN_n":int((w.analysis_group.eq("EN-CN")&w.journal_norm.eq(j)).sum()),"EN_NC_n":int((w.analysis_group.eq("EN-NC")&w.journal_norm.eq(j)).sum()),"total_n":int(w.journal_norm.eq(j).sum())} for j in sorted(shared)])
    ws=w[w.journal_norm.isin(shared)]; valsA=ws[ws.analysis_group.eq("EN-CN")].topic_code.isin(AXIS_MAIN["VALUE"]).astype(int).to_numpy(); valsB=ws[ws.analysis_group.eq("EN-NC")].topic_code.isin(AXIS_MAIN["VALUE"]).astype(int).to_numpy(); shared_axis=pd.DataFrame([fisher_row(valsA,valsB,"EN-CN_shared_journals","EN-NC_shared_journals","AXIS_main_VALUE")])
    ca,cb=topic_counts(ws,"EN-CN","EN-NC"); shared_jsd=pd.DataFrame([{"source_a":"EN-CN_shared_journals","source_b":"EN-NC_shared_journals","jsd_observed_bits":jsd_from_counts(ca,cb),"method":"shared-journal subset"}])
    # A8 ecology.
    ecol=[]
    for g in ["ZH","EN-CN","EN-NC"]:
        sub=d[d.analysis_group.eq(g)]; counts=sub.journal.value_counts(); n=len(sub); probs=counts.to_numpy()/n; hhi=float((probs**2).sum()); top5=int(counts.head(5).sum());
        ecol.append({"group":g,"journal_count":int(counts.size),"article_count":n,"top5_articles":top5,"top5_concentration":top5/n if n else np.nan,"HHI":hhi,"top10":"; ".join([f"{idx} ({val})" for idx,val in counts.head(10).items()]),"method":"journal frequency concentration"})
    return {"A1_Topic_Group_Table":a1df,"A1_Paper_Table":p_df,"A2_Axis_Table":axis_table,"A2_Pairwise":pairwise,"A3_Separation_Index":sep_df,"A3_Separation_Topic_Detail":sep_detail_df,"A4_JSD":pd.DataFrame(jsd_rows),"A4_JSD_Permutation":pd.DataFrame(jsd_perm_rows),"A5_Across_K":a5df,"A6_Period_Axis":pd.DataFrame(period_rows),"A6_Year_Group_Counts":yearly,"A7_Shared_Journals":shared_rows,"A7_Shared_Journal_Axis":shared_axis,"A7_Shared_Journal_JSD":shared_jsd,"A8_Journal_Ecology":pd.DataFrame(ecol)}


def write_csvs(tables: dict[str, pd.DataFrame]) -> None:
    for name, df in tables.items():
        df.to_csv(OUT / f"{name}.csv", index=False, encoding="utf-8-sig")
    payload = {name: {"columns": list(df.columns), "rows": df.replace({np.nan: None}).to_dict(orient="records")} for name, df in tables.items()}
    (OUT / "phase_a_payload.json").write_text(json.dumps(payload, ensure_ascii=False, default=str), encoding="utf-8")


def write_docs(d: pd.DataFrame, tables: dict[str, pd.DataFrame], sanity: dict[str, pd.DataFrame]) -> None:
    required = {
        "1427_workbook": SOURCE,
        "main_model_script": ROOT / "work" / "rebuild_latest_1427_corrected.py",
        "raw_embeddings": ROOT / "work" / "new_inputs" / "embeddings_1427.npy",
        "old_corpus": ROOT / "work" / "new_inputs" / "old_corpus.csv",
        "vector_mapping": ROOT / "work" / "new_inputs" / "vector_mapping_1427.csv",
        "old_department_logs": ROOT / "output" / "task5_journal_tier_coded.xlsx",
        "journal_evidence": ROOT / "output" / "task5_journal_tier_coded.xlsx",
        "journal_type_table": ROOT / "output" / "task5_journal_tier_coded.xlsx",
        "stopwords_zh": ROOT / "output" / "final_rebuild_20260925" / "stopwords_zh.txt",
        "old_translation_text": ROOT / "work" / "joint_k12_revision_20260821" / "translation_robustness" / "document_assignments_with_translated_text.csv",
        "old_k12_assignments": ROOT / "work" / "joint_k12_revision_20260821" / "document_topic_assignments_k12.csv",
        "wos_raw_export": ROOT / "work" / "new_inputs" / "wos.xlsx",
    }
    found=[]; missing=[]
    for label,path in required.items():
        row={"item":label,"path":str(path),"exists":path.exists()}
        (found if path.exists() else missing).append(row)
    versions = env_versions()
    log=f"# RUN_LOG\n\n- Started: {pd.Timestamp.now()}\n- Phase completed: Step 0 and Phase A\n- Frozen source: {SOURCE}\n- Corpus: CNKI 896 + WoS 531 = 1,427\n- Groups: ZH 896 / EN-CN 243 / EN-NC 288; EN-CN-strict={int(d.en_cn_strict.sum())}\n- Seeds: {SEEDS}\n- Runtime versions: {json.dumps(versions, ensure_ascii=False)}\n- Topic assignment source: Corpus_Master.topic_code; no model refit in Phase A\n- Disabled content-coding sheets were not read.\n- E5 model revision/commit hash is not recorded in the frozen workbook; it must be resolved before any embedding-refit phase.\n- Phase A tables: {', '.join(tables.keys())}\n"
    (OUT / "RUN_LOG.md").write_text(log, encoding="utf-8")
    missing_lines = [f"- {x['item']}: {x['path']} (missing; needed for later phase; suggested source: prior project output or original export)" for x in missing]
    missing_lines.append("- E5 model revision/commit hash: not recorded in the frozen workbook or rebuild script; required for reproducible embedding-refit phases.")
    (OUT / "MISSING_INPUTS.md").write_text("# MISSING_INPUTS\n\n" + "\n".join(missing_lines) + "\n", encoding="utf-8")
    meta=pd.DataFrame(found+missing)
    meta.to_csv(OUT / "00_File_Inventory.csv", index=False, encoding="utf-8-sig")


def main() -> None:
    parser=argparse.ArgumentParser(); parser.add_argument("--phase", default="A", choices=["A","sanity"]); args=parser.parse_args()
    started=time.time(); d=load_corpus(); sanity=phase_sanity(d); tables={**sanity}
    if args.phase == "A": tables.update(phase_a(d))
    write_csvs(tables); write_docs(d, tables, sanity)
    print(json.dumps({"phase":args.phase,"rows":len(d),"groups":d.analysis_group.value_counts().to_dict(),"en_cn_strict":int(d.en_cn_strict.sum()),"outputs":list(tables),"elapsed_s":round(time.time()-started,2)},ensure_ascii=False))


if __name__ == "__main__":
    main()
