# Recovered historical source

These 25 scripts were recovered from the user's earlier analysis project. Source-file checksums and packaged-file checksums are listed in `../docs/source_provenance.csv`. The only automatic source modifications were a provenance comment and redirection of complete absolute path literals to relative paths or `private_inputs/`. Numerical algorithms, threshold rules and old reporting code were not silently rewritten.

This is an archive, not the recommended execution entry point. Use `../src/reproduce.py` for the tested portable workflow. Historical scripts were syntax-checked; they were not all re-executed. Some scripts perform work when imported. Do not import them merely to inspect a function.

Historical scripts can write into `output/`, `outputs/` and `work/` beneath this historical root, so use a disposable copy when investigating them. They expect a reconstructed historical directory layout. Raw source files and translation caches are intentionally absent.

| Scripts | Historical function | Additional inputs |
|---|---|---|
| `work/rebuild_latest_1427_corrected.py` | Original selected K-grid run and custom topic terms | `work/new_inputs/cnki.xlsx`, `wos.xlsx`, raw E5 vectors; exact historical input sheets |
| `rerun_1427_k15/run_all.py` | Primary frozen-label statistics | Historical final workbook, old/new input mappings and old diagnostic files |
| `rerun_1427_k15/phase_bc.py` | Original stratification and coding reuse | Final workbook; K13 department/country coding evidence and tier payload; old assignments |
| `work/b3_fix.py` | Historical department revision | Source workbook and previous department outputs |
| `work/claude_scripts_2026-09-30/` | Department v3 coding, overrides, MH, standardization, co-word analysis | Master source workbook; intermediate pickles created by these scripts |
| `work/v11_common.py`, `v11_seeds.py` | Full-SVD refit and ten-seed audit | Raw vectors, final workbook, frozen assignments, E5 metadata |
| `work/v11_translation.py` | Paired translation designs | Cached translated source texts, local E5 weights and original seed outputs |
| `work/run_phase_f.py`, `v11_granularity.py` | Historical coherence and K diagnostics | Source texts, tokenization packages, historical F1 caches, per-K term tables |
| `work/task2_anchor_v10.py` | Concept-anchor permutation test | Recorded anchor vectors/matrices and old model/cache paths |
| `work/v11_task7_integrate.py`, `run_c4.py` | Import/verify subjectivity and department analyses | Archived workbooks and completed department-script outputs |
| `work/screen_corpus.py`, `rescreen_processed.py`, `augment_new.py` | Screening and input reconstruction steps | Historical exports and author decisions; not a recreation of platform search |

Run historical code only after reading its actual inputs. The directory table is explanatory, not a guarantee that every external dependency has been restored. Several historical scripts contain obsolete conclusions or method terminology; their preservation does not endorse those statements for the current manuscript.
