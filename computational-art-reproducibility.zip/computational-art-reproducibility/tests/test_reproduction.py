"""Independent mathematical boundaries and frozen manuscript checks."""
import sys
import unittest
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from reproduce import ROOT, load_records, cp, jsd, separation, fisher, group

class TestReproduction(unittest.TestCase):
    def test_distance_boundaries(self):
        self.assertAlmostEqual(jsd([1,0],[0,1]),1)
        self.assertAlmostEqual(jsd([1,2],[2,4]),0)
        self.assertAlmostEqual(separation(np.array([10,0]),np.array([0,20])),1)
        self.assertAlmostEqual(separation(np.array([3,7]),np.array([6,14])),0)

    def test_zero_cell_detection_boundary(self):
        self.assertGreaterEqual(cp(0,182)[1],.02)
        self.assertLess(cp(0,183)[1],.02)
        self.assertEqual(cp(0,243)[0],0)

    def test_frozen_manuscript_counts(self):
        d=load_records(ROOT/'data/derived/records.csv')
        self.assertEqual(int(group(d,'ZH').axis.eq('VALUE').sum()),376)
        self.assertEqual(int(group(d,'EN').axis.eq('VALUE').sum()),10)
        self.assertEqual(int(group(d,'ZH').axis.eq('TECH').sum()),31)
        self.assertEqual(int(group(d,'EN').axis.eq('TECH').sum()),355)
        self.assertEqual(int(group(d,'EN-CN').q2_verified_en.eq('1').sum()),6)
        self.assertEqual(int(group(d,'EN-NC').q2_verified_en.eq('1').sum()),23)
        self.assertEqual(int(d.en_cn_strict.sum()),232)

    def test_exact_fisher_p(self):
        a=np.array([True]*6+[False]*237);b=np.array([True]*23+[False]*265)
        r=fisher(a,b)
        self.assertAlmostEqual(r['p'],.0064470565,places=9)
        self.assertAlmostEqual(r['OR'],.2922855704,places=9)

    def test_clc_definitions_are_distinct(self):
        d=group(load_records(ROOT/'data/derived/records.csv'),'ZH')
        self.assertEqual(int(d.clc_first_J.sum()),391)
        self.assertEqual(int(d.clc_any_J.sum()),736)
        self.assertEqual(int((d.clc_any_J.eq(1)&d.clc_any_TP.eq(1)).sum()),629)

if __name__=='__main__':unittest.main()
