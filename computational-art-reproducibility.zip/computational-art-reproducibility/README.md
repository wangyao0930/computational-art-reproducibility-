# Computational art across publication environments

Reproducibility package for **Are They Studying the Same Computational Art? Problem Structures of Computational Art Scholarship across Chinese- and English-Language Publication Infrastructures**.

This package preserves the frozen **1,427-record, K=15** analysis: ZH=896, EN-CN=243, EN-NC=288. It contains executable statistical analysis, archived numerical embeddings, frozen assignments, coding variables, and 25 recovered historical scripts. This is a local release candidate prepared on 19 October 2026. It has **not** been uploaded, assigned a DOI, or licensed by the authors.

The main entry point recalculates results from record-level inputs. Original bibliographic exports, titles, abstracts, names, and institutional addresses are not included. The historical scripts are retained for provenance; their external inputs and execution environments differ from the portable entry point.

## Run the analysis

Use Python 3.12. From this folder:

```sh
python -m venv .venv
# Windows PowerShell: .venv\Scripts\Activate.ps1
# macOS / Linux: source .venv/bin/activate
python -m pip install -r requirements.txt
python src/verify_integrity.py
python -m unittest discover -s tests -v
python src/reproduce.py
```

The final command writes CSV tables and a run record under `results/`. It uses 2,000 bootstrap replicates, 5,000 distribution permutations, and 10,000 stratified permutations. `--quick` uses 200 draws for a smoke test only. Installation commands are provided for users; an installation from an empty environment and the GitHub Actions job have not been tested on a remote service.

### Refit model stages

```sh
python src/model.py --mode historical-kmeans
python -m pip install -r requirements-model.txt
python src/model.py --mode v11-refit --seed 42 --output results/v11_seed42
```

The first command runs KMeans on the original saved 10-dimensional UMAP coordinates. It reproduced every frozen topic label in local testing. It does **not** rerun the original encoder, PCA, or UMAP.

The second modeling mode uses archived raw E5 vectors, deterministic float64 full SVD, UMAP, and KMeans. It is a v11 sensitivity refit, not a reconstruction of the original frozen fitted model. Topic labels are aligned by maximum-overlap Hungarian matching only when K=15. Use `--k 8` through `--k 18` to explore the recorded K grid; numerical cluster IDs across different K values are not comparable semantic topics.

Original source texts can be re-encoded using `src/encode_texts.py --input private_inputs/texts.csv`, after installing the model requirements. The input schema is `doc_id,title,abstract`. This optional utility has not been executed in this release; it reports differences from archived E5 vectors rather than silently replacing them. It needs access to the recorded model revision or a matching local model directory.

## Contents

| Location | Purpose |
|---|---|
| `src/reproduce.py` | Main topic and axis statistics, intervals, Fisher tests, JSD, periods, strata, standardization, and cached seed/translation analyses |
| `src/model.py` | Historical-coordinate KMeans and separately labeled v11 refits |
| `src/encode_texts.py` | Optional new encoding utility requiring source texts |
| `data/derived/` | Record-level labels, coding variables, concept rules, cached seed/translation assignments and anchor matrices |
| `data/model_inputs/` | Raw E5 vectors, historical postprocessed vectors, and historical UMAP coordinates in frozen record order |
| `data/reference/` | Historical outputs for comparison, explicitly not new runs |
| `historical/` | Recovered code with machine-specific absolute path literals redirected; not a one-command workflow |
| `config/analysis.json` | Frozen corpus, axes, model revision and sampling settings |
| `docs/source_provenance.csv` | Source names, SHA-256 hashes, and packaging changes |
| `docs/verification/` | Results and execution evidence produced during packaging |
| `docs/REPRODUCIBILITY.md` | Coverage, limitations, and differences from the manuscript |
| `docs/RELEASE_CHECKLIST.md` | GitHub/Zenodo release and citation actions |

## What this release establishes

The package reproduces the frozen primary counts, the 29 positive English subjectivity labels across 11 topics, recorded author spot-check agreement, department and journal comparisons, and cross-K/seed/translation summaries from their retained inputs. It does not independently validate the underlying human or AI-assisted judgments. New bootstrap/permutation streams can differ from historical streams; compare point estimates separately from Monte Carlo uncertainty.

Three upstream items remain unavailable in the searched local material: platform-exported search histories, the exact original 86-record shared-object reading list, and the original bilingual dictionary scoring implementation. The codebook and dictionary decisions are retained, but the scoring rule must not be inferred from thresholds alone. The original frozen PCA/UMAP objects were not recovered; v11 objects are different models.

There is also a manuscript discrepancy: **45.0% and 42.9%** are first-CLC-code statistics. Any-code, overlapping J/TP subsets give **44.6% and 43.5%**. Both definitions are exposed in the outputs. See `docs/REPRODUCIBILITY.md` before citing this release as a complete reproduction.

## 中文快速说明

打开本目录即可查看完整代码源。没有 GitHub 账号也能在本地运行；上传步骤见 `docs/RELEASE_CHECKLIST.md`。主要运行入口是 `src/reproduce.py`，不是历史文件夹里的脚本。

当前包可以支撑“分析代码、冻结主题分配和派生分析数据已公开”这一有范围限定的声明；它不能支撑“从平台检索到所有人工阅读环节均已完整复现”。GitHub 地址与 Zenodo DOI 应在实际发布后填入。作者、许可证及正式版本号尚待确认。
