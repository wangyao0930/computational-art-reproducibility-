"""Verify packaged analysis inputs and source files against the local manifest."""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]

def main():
    manifest=json.loads((ROOT/'MANIFEST.json').read_text('utf-8'))
    failures=[]
    for item in manifest['files']:
        p=ROOT/item['path']
        if not p.is_file():failures.append(item['path']+': missing');continue
        if hashlib.sha256(p.read_bytes()).hexdigest()!=item['sha256']:failures.append(item['path']+': changed')
    if failures:raise SystemExit('\n'.join(failures))
    print(f"Verified {len(manifest['files'])} files. This verifies bytes, not scientific validity or authorship.")

if __name__=='__main__':main()
