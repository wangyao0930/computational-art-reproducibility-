"""Optional reconstruction of text encoding; requires lawfully obtained source text.

This is a new release utility, not the recovered original embedding run. The
archived raw embeddings remain the reference. Never substitute regenerated
vectors silently: inspect the differences and resulting topic assignments.
"""
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
from reproduce import ROOT, load_records, require

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--input',type=Path,required=True,help='UTF-8 CSV: doc_id,title,abstract')
    p.add_argument('--model',default='intfloat/multilingual-e5-large',help='Hugging Face ID or local model directory')
    p.add_argument('--device',default='cpu');p.add_argument('--batch-size',type=int,default=4)
    p.add_argument('--output',type=Path,default=ROOT/'results/encoding')
    args=p.parse_args()
    from sentence_transformers import SentenceTransformer
    cfg=json.loads((ROOT/'config/analysis.json').read_text('utf-8'))
    d=load_records(ROOT/'data/derived/records.csv');t=pd.read_csv(args.input,keep_default_na=False,dtype=str)
    require({'doc_id','title','abstract'}.issubset(t.columns),'Need doc_id,title,abstract')
    require(t.doc_id.is_unique and set(t.doc_id)==set(d.doc_id),'Input IDs must match frozen corpus exactly')
    t=t.set_index('doc_id').loc[d.doc_id]
    require(t.title.str.strip().ne('').all() and t.abstract.str.strip().ne('').all(),'No empty title or abstract')
    kwargs={'device':args.device}
    if not Path(args.model).is_dir(): kwargs['revision']=cfg['v11_embedding_revision']
    model=SentenceTransformer(args.model,**kwargs)
    texts=('passage: '+t.title+'. '+t.abstract).tolist()
    vectors=model.encode(texts,batch_size=args.batch_size,normalize_embeddings=True,show_progress_bar=True,convert_to_numpy=True)
    out=args.output.resolve()
    require(out!=ROOT and ROOT/'data' not in out.parents and out!=ROOT/'data','Use a separate output directory')
    out.mkdir(parents=True,exist_ok=True);np.save(out/'regenerated_embeddings.npy',vectors)
    old=np.load(ROOT/'data/model_inputs/e5_embeddings.npy',allow_pickle=False)
    require(vectors.shape==old.shape,'Embedding shape differs')
    report=dict(max_absolute_difference=float(np.max(np.abs(vectors-old))),mean_row_cosine=float(np.mean(np.sum(vectors*old,axis=1)/(np.linalg.norm(vectors,axis=1)*np.linalg.norm(old,axis=1)))),model=args.model,max_seq_length=model.max_seq_length,revision=kwargs.get('revision','local directory; revision not independently verified'),status='comparison_only; not automatic replacement')
    (out/'encoding_comparison.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report))

if __name__=='__main__':main()
