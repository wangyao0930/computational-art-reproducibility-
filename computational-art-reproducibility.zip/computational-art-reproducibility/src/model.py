"""Refit recovered model stages without overwriting the frozen manuscript labels."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import linear_sum_assignment
from sklearn.cluster import KMeans
from sklearn.metrics import adjusted_rand_score
from threadpoolctl import threadpool_limits
from reproduce import ROOT, load_records, require

def postprocess(x):
    x=np.asarray(x,np.float64);mean=x.mean(0);c=x-mean
    _,_,v=np.linalg.svd(c,full_matrices=False);pcs=v[:3].copy()
    pcs*=np.where(pcs[np.arange(3),np.abs(pcs).argmax(1)]<0,-1,1)[:,None]
    residual=c-(c@pcs.T)@pcs
    return residual/np.linalg.norm(residual,axis=1,keepdims=True),mean,pcs

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--mode',choices=['historical-kmeans','v11-refit'],default='historical-kmeans')
    p.add_argument('--seed',type=int,default=42)
    p.add_argument('--k',type=int,default=15)
    p.add_argument('--output',type=Path,default=ROOT/'results/model')
    args=p.parse_args();out=args.output.resolve()
    require(out!=ROOT and ROOT/'data' not in out.parents and out!=ROOT/'data','Use a separate output directory')
    require(8<=args.k<=18,'Recovered grid is K=8..18')
    out.mkdir(parents=True,exist_ok=True)
    d=load_records(ROOT/'data/derived/records.csv');f=d.topic.str[1:].astype(int).to_numpy()
    if args.mode=='historical-kmeans':
        u=np.load(ROOT/'data/model_inputs/historical_umap_10d.npy',allow_pickle=False)
        description='Historical UMAP coordinates reused; KMeans re-executed. This does not reproduce the original encoder/PCA/UMAP fit.'
    else:
        from umap import UMAP
        import joblib
        raw=np.load(ROOT/'data/model_inputs/e5_embeddings.npy',allow_pickle=False)
        require(raw.shape==(1427,1024),'Expected E5 array shape (1427,1024)')
        x,mean,pcs=postprocess(raw)
        np.save(out/'pp_mean.npy',mean);np.save(out/'pp_pcs.npy',pcs)
        um=UMAP(n_neighbors=100,n_components=10,min_dist=0,metric='cosine',random_state=args.seed,low_memory=True)
        u=um.fit_transform(x).astype(np.float32)
        joblib.dump(um,out/'umap.joblib',compress=3)
        description='New deterministic full-SVD/UMAP/KMeans refit from archived raw E5 vectors; separate from frozen historical model.'
    require(u.shape==(1427,10),'Expected UMAP array shape (1427,10)')
    km=KMeans(n_clusters=args.k,n_init=30,random_state=args.seed).fit(u)
    labels=km.labels_;rows=pd.DataFrame({'doc_id':d.doc_id,'cluster':labels,'frozen_topic':d.topic})
    if args.k==15:
        cm=np.zeros((15,15),dtype=int);np.add.at(cm,(f,labels),1)
        rr,cc=linear_sum_assignment(-cm);mapping=dict(zip(cc,rr))
        rows['aligned_topic']=[f'T{mapping[t]:02d}' for t in labels]
    rows.to_csv(out/'assignments.csv',index=False)
    np.save(out/'coordinates.npy',u);np.save(out/'centers.npy',km.cluster_centers_)
    result=dict(mode=args.mode,k=args.k,seed=args.seed,ARI_vs_frozen=float(adjusted_rand_score(f,labels)),exact_label_match=bool(np.array_equal(f,labels)),description=description)
    if args.mode=='v11-refit' and args.k==15:
        archived=pd.read_csv(ROOT/'data/derived/Seed_Assignments.csv')
        s=archived[archived.seed.eq(args.seed)].set_index('doc_id')
        if len(s): result['ARI_vs_archived_v11_same_seed']=float(adjusted_rand_score(s.loc[d.doc_id].cluster,labels))
    (out/'model_report.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result))

if __name__=='__main__':
    with threadpool_limits(limits=4): main()
