"""Recompute manuscript statistics from recovered, frozen record-level inputs.

This release reconstruction does not reassign topics or recreate human coding.
Bootstrap draws are explicitly seeded; intervals may differ from historical runs
which used a different draw order. Archived outputs live in data/reference/.
"""
from __future__ import annotations
import argparse
import hashlib
import itertools
import json
import platform
from importlib.metadata import version
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.spatial.distance import jensenshannon
from scipy.stats import beta, contingency, fisher_exact
from sklearn.metrics import adjusted_rand_score
from statsmodels.stats.contingency_tables import StratifiedTable

ROOT = Path(__file__).resolve().parents[1]
TOPICS = [f'T{i:02d}' for i in range(15)]
VALUE = {'T00', 'T03', 'T13'}
TECH = {'T02', 'T05', 'T08', 'T12'}
GROUPS = ['ZH', 'EN-CN', 'EN-NC', 'EN']

def require(ok, message):
    if not ok:
        raise ValueError(message)

def load_records(path):
    d = pd.read_csv(path, keep_default_na=False, dtype={'doc_id':str, 'topic':str, 'q2_verified_en':str, 'author_spotcheck':str})
    require(len(d)==1427 and d.doc_id.is_unique, 'Expected 1,427 unique records')
    require(d.group.value_counts().to_dict()=={'ZH':896,'EN-NC':288,'EN-CN':243}, 'Wrong corpus groups')
    require(set(d.topic)==set(TOPICS), 'Expected frozen K=15 topic codes')
    expected = np.where(d.topic.isin(VALUE),'VALUE',np.where(d.topic.isin(TECH),'TECH','MIXED'))
    require(np.array_equal(d.axis.to_numpy(),expected),'Axis/topic definitions disagree')
    require(d.year.between(2019,2026).all(),'Year outside reported study window')
    require(d.loc[d.group!='ZH','q2_verified_en'].isin(['0','1','B']).all(),'Missing English review labels')
    return d

def group(d,g):
    return d[d.group.ne('ZH')] if g=='EN' else d[d.group.eq(g)]

def counts(d):
    return d.topic.value_counts().reindex(TOPICS,fill_value=0).to_numpy(dtype=int)

def cp(k,n):
    if n==0: return (np.nan,np.nan)
    return (0.0 if k==0 else float(beta.ppf(.025,k,n-k+1)),1.0 if k==n else float(beta.ppf(.975,k+1,n-k)))

def jsd(a,b):
    a=np.asarray(a,dtype=float);b=np.asarray(b,dtype=float)
    require(a.sum()>0 and b.sum()>0,'JSD requires two nonempty groups')
    return float(jensenshannon(a/a.sum(),b/b.sum(),base=2)**2)

def separation(a,b):
    return float(1-np.minimum(a,b).sum()/min(np.sum(a),np.sum(b)))

def proportion_row(label,y,**extra):
    n=len(y);k=int(np.asarray(y).sum());lo,hi=cp(k,n)
    return dict(label=label,n=n,count=k,share=k/n if n else np.nan,ci_low=lo,ci_high=hi,**extra)

def fisher(a,b):
    a=np.asarray(a,dtype=bool);b=np.asarray(b,dtype=bool)
    t=np.array([[a.sum(),len(a)-a.sum()],[b.sum(),len(b)-b.sum()]],dtype=int)
    rr=contingency.odds_ratio(t,kind='conditional');ci=rr.confidence_interval(.95)
    return dict(a_positive=int(a.sum()),a_n=len(a),b_positive=int(b.sum()),b_n=len(b),OR=float(rr.statistic),OR_low=float(ci.low),OR_high=float(ci.high),p=float(fisher_exact(t).pvalue))

def distribution_test(a,b,reps,boots,seed):
    rng=np.random.default_rng(seed);a=np.asarray(a,int);b=np.asarray(b,int)
    n=int(a.sum());m=int(b.sum());point=jsd(a,b)
    aa=rng.multinomial(n,a/n,size=boots);bb=rng.multinomial(m,b/m,size=boots)
    draws=jensenshannon(aa/n,bb/m,base=2,axis=1)**2
    # Exact aggregate equivalent of shuffling individual group labels, conditional on margins.
    pa=rng.multivariate_hypergeometric(a+b,n,size=reps);pb=a+b-pa
    null=jensenshannon(pa/n,pb/m,base=2,axis=1)**2
    return dict(JSD=point,S=separation(a,b),JSD_low=float(np.quantile(draws,.025)),JSD_high=float(np.quantile(draws,.975)),permutation_p=float((1+np.sum(null>=point-1e-12))/(reps+1)))

def stratified_q2(d,col,reps,seed):
    e=group(d,'EN');tables=[];params=[];observed=expected=0
    for _,s in e.groupby(col,sort=True):
        a=group(s,'EN-CN').q2_verified_en.eq('1');b=group(s,'EN-NC').q2_verified_en.eq('1')
        if not len(a) or not len(b): continue
        t=np.array([[a.sum(),len(a)-a.sum()],[b.sum(),len(b)-b.sum()]],dtype=int)
        tables.append(t);n=t.sum();positive=t[:,0].sum();n1=t[0,:].sum()
        observed+=t[0,0];expected+=positive*n1/n;params.append((positive,n-positive,n1))
    require(bool(tables),'No shared strata')
    model=StratifiedTable(np.stack(tables,axis=2));lo,hi=model.oddsratio_pooled_confint()
    rng=np.random.default_rng(seed);draw=np.zeros(reps)
    for good,bad,sample in params: draw+=rng.hypergeometric(good,bad,sample,size=reps)
    p=(1+np.sum(np.abs(draw-expected)>=abs(observed-expected)-1e-12))/(reps+1)
    return dict(stratum=col,OR=float(model.oddsratio_pooled),OR_low=float(lo),OR_high=float(hi),permutation_p=float(p),informative_or_shared_strata=len(tables))

def standardize(d,collapsed,boots,seed):
    x=d.copy();col='dept_v3'
    if collapsed:
        x['dept_four']=x.dept_v3.replace({'CS':'TECHSIDE','BOTH':'TECHSIDE','STEM':'TECHSIDE'});col='dept_four'
    z=group(x,'ZH');e=group(x,'EN');levels=sorted(set(e[col]));rng=np.random.default_rng(seed)
    rates=np.array([z[z[col].eq(v)].axis.eq('VALUE').mean() for v in levels])
    ns=np.array([z[col].eq(v).sum() for v in levels])
    require((ns>0).all(),'Target department has no source records')
    weight=np.array([e[col].eq(v).mean() for v in levels]);point=float(weight@rates)
    bw=rng.multinomial(len(e),weight,size=boots)/len(e)
    bp=rng.binomial(ns,rates,size=(boots,len(ns)))/ns
    dist=np.sum(bw*bp,axis=1)
    return dict(spec='four_categories' if collapsed else 'six_categories',share=point,ci_low=float(np.quantile(dist,.025)),ci_high=float(np.quantile(dist,.975)),note='Target composition resampled; source outcomes resampled within department; descriptive only')

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,default=ROOT/'results')
    p.add_argument('--quick',action='store_true',help='200 draws for a smoke run, not publication intervals')
    args=p.parse_args();out=args.output.resolve()
    require(out!=ROOT and ROOT/'data' not in out.parents and out!=ROOT/'data','Output must not overwrite source data')
    out.mkdir(parents=True,exist_ok=True)
    cfg=json.loads((ROOT/'config/analysis.json').read_text('utf-8'));d=load_records(ROOT/'data/derived/records.csv')
    reps=200 if args.quick else cfg['permutation_reps'];boots=200 if args.quick else cfg['bootstrap_reps'];sreps=200 if args.quick else cfg['stratified_permutation_reps'];seed=cfg['seed']
    def save(name,rows):
        pd.DataFrame(rows).to_csv(out/f'{name}.csv',index=False,encoding='utf-8')
    topic_rows=[];axis_rows=[]
    for g in GROUPS:
        s=group(d,g)
        for t in TOPICS:
            r=proportion_row(t,s.topic.eq(t),group=g)
            for threshold in [.01,.02,.03]: r[f'void_{threshold:.2f}']=r['ci_high']<threshold
            topic_rows.append(r)
        for axis in ['VALUE','TECH','MIXED']:
            axis_rows.append(proportion_row(axis,s.axis.eq(axis),group=g))
        axis_rows.append(proportion_row('VALUE_wide',s.topic.isin(cfg['wide_value_topics']),group=g))
    save('topic_shares',topic_rows);save('axis_shares',axis_rows)
    pairs=[('ZH','EN'),('ZH','EN-CN'),('ZH','EN-NC'),('EN-CN','EN-NC')]
    save('distribution_comparisons',[dict(a=a,b=b,**distribution_test(counts(group(d,a)),counts(group(d,b)),reps,boots,seed+i)) for i,(a,b) in enumerate(pairs)])
    save('axis_fisher',[dict(a=a,b=b,**fisher(group(d,a).axis.eq('VALUE'),group(d,b).axis.eq('VALUE'))) for a,b in pairs])
    # The direction contrast shares the same bootstrapped ZH vector in both distances.
    rng=np.random.default_rng(seed);z=counts(group(d,'ZH'));c=counts(group(d,'EN-CN'));n=counts(group(d,'EN-NC'))
    zz=rng.multinomial(z.sum(),z/z.sum(),size=boots)/z.sum();cc=rng.multinomial(c.sum(),c/c.sum(),size=boots)/c.sum();nn=rng.multinomial(n.sum(),n/n.sum(),size=boots)/n.sum()
    delta=jensenshannon(zz,cc,base=2,axis=1)**2-jensenshannon(zz,nn,base=2,axis=1)**2
    save('distance_direction',[dict(difference=jsd(z,c)-jsd(z,n),ci_low=np.quantile(delta,.025),ci_high=np.quantile(delta,.975))])
    concept=[]
    for g in GROUPS:
        s=group(d,g);concept.append(proportion_row('dictionary_Q2',s.q2_dictionary.eq(1),group=g))
        if g!='ZH':
            concept.append(proportion_row('review_strict',s.q2_verified_en.eq('1'),group=g))
            concept.append(proportion_row('review_including_framing',s.q2_verified_en.isin(['1','B']),group=g))
    save('subjectivity_shares',concept)
    ec=group(d,'EN-CN');en=group(d,'EN-NC')
    save('subjectivity_tests',[dict(outcome='dictionary',**fisher(ec.q2_dictionary.eq(1),en.q2_dictionary.eq(1))),dict(outcome='strict_review',**fisher(ec.q2_verified_en.eq('1'),en.q2_verified_en.eq('1')))])
    save('subjectivity_mh',[stratified_q2(d,col,sreps,seed) for col in ['dept_v3','topic']])
    e=group(d,'EN');checked=e[e.author_spotcheck.ne('')]
    save('coding_checks',[dict(english_review_n=len(e),strict_positive=int(e.q2_verified_en.eq('1').sum()),strict_topics=int(e[e.q2_verified_en.eq('1')].topic.nunique()),author_check_n=len(checked),author_check_agreement=int((checked.author_spotcheck==checked.q2_verified_en).sum()),interpretation='Verifies recorded decisions; does not independently verify that reading occurred')])
    strata=[]
    for g in GROUPS:
        for dep,s in group(d,g).groupby('dept_v3'):
            strata.append(proportion_row(dep,s.axis.eq('VALUE'),group=g,variable='department'))
    z=group(d,'ZH')
    for col in ['clc_first_J','clc_first_TP','clc_any_J','clc_any_TP','clc_TP_without_J']:
        s=z[z[col].eq(1)];strata.append(proportion_row(col,s.axis.eq('VALUE'),group='ZH',variable='CLC'))
    for label,status in [('CORE_CONFIRMED','是'),('CONFIRMED_NON_CORE','否'),('PENDING','待核')]:
        if label=='CORE_CONFIRMED':m=z.journal_tier_status.eq(status)&z.journal_tier_evidence_complete.eq(1)
        elif label=='CONFIRMED_NON_CORE':m=z.journal_tier_status.eq(status)&z.journal_tier_match_method.eq('complete_coverage_no_match')
        else:m=~((z.journal_tier_status.eq('是')&z.journal_tier_evidence_complete.eq(1))|(z.journal_tier_status.eq('否')&z.journal_tier_match_method.eq('complete_coverage_no_match')))
        s=z[m];strata.append(proportion_row(label,s.axis.eq('VALUE'),group='ZH',variable='tier'))
    s=d[d.en_cn_strict.eq(1)];strata.append(proportion_row('EN-CN-strict',s.axis.eq('VALUE'),group='EN-CN',variable='country'))
    shared=set(ec.journal_id)&set(en.journal_id)
    for g in ['EN-CN','EN-NC']:
        s=group(d,g);s=s[s.journal_id.isin(shared)];strata.append(proportion_row('shared_journals',s.axis.eq('VALUE'),group=g,variable='journal',journals_n=len(shared)))
    save('strata',strata);save('standardization',[standardize(d,c,boots,seed) for c in [False,True]])
    period=[];changes=[];between=[];balanced=[]
    for g in GROUPS:
        s=group(d,g);a=s[s.year<2023];b=s[s.year>=2023]
        ca=counts(a);cb=counts(b)
        changes.append(dict(group=g,**distribution_test(ca,cb,reps,boots,seed)))
        rng=np.random.default_rng(seed)
        diff=rng.multinomial(len(b),cb/len(b),size=boots)/len(b)-rng.multinomial(len(a),ca/len(a),size=boots)/len(a)
        for i,t in enumerate(TOPICS):
            period.append(dict(group=g,topic=t,early_n=len(a),late_n=len(b),early_count=int(ca[i]),late_count=int(cb[i]),early_share=ca[i]/len(a),late_share=cb[i]/len(b),difference=cb[i]/len(b)-ca[i]/len(a),difference_low=np.quantile(diff[:,i],.025),difference_high=np.quantile(diff[:,i],.975)))
    for label,mask in [('2019-2022',d.year<2023),('2023-2026',d.year>=2023)]:
        s=d[mask]
        for a,b in pairs:between.append(dict(period=label,a=a,b=b,**distribution_test(counts(group(s,a)),counts(group(s,b)),reps,boots,seed)))
    # Without-replacement size matching, not a bootstrap with replacement.
    rng=np.random.default_rng(seed);early=d[d.year<2023];late=d[d.year>=2023]
    for a,b in pairs:
        aa=counts(group(late,a));bb=counts(group(late,b));na=len(group(early,a));nb=len(group(early,b))
        da=rng.multivariate_hypergeometric(aa,na,size=boots);db=rng.multivariate_hypergeometric(bb,nb,size=boots)
        jd=jensenshannon(da/na,db/nb,base=2,axis=1)**2;sd=1-np.minimum(da,db).sum(1)/min(na,nb)
        balanced.append(dict(a=a,b=b,draws=boots,sampling='late without replacement, matched to early group sizes',JSD_mean=jd.mean(),JSD_low=np.quantile(jd,.025),JSD_high=np.quantile(jd,.975),S_mean=sd.mean(),S_low=np.quantile(sd,.025),S_high=np.quantile(sd,.975)))
    save('period_topic_changes',period);save('within_group_period_tests',changes);save('between_group_period_tests',between);save('period_size_matching',balanced)
    grid=[]
    for k in range(8,19):
        s=pd.read_csv(ROOT/f'data/reference/Shares_k{k}.csv')
        for a,b in pairs:
            x=s[a].to_numpy();y=(s['EN-CN']+s['EN-NC']).to_numpy() if b=='EN' else s[b].to_numpy()
            grid.append(dict(k=k,a=a,b=b,JSD=jsd(x,y),S=separation(x,y),source='archived cross-K counts'))
    save('cross_k_metrics',grid)
    seeds=pd.read_csv(ROOT/'data/derived/Seed_Assignments.csv');ids=d.doc_id.tolist()
    labs={};seedmetrics=[]
    for seed_id,s in seeds.groupby('seed'):
        require(s.doc_id.is_unique and set(s.doc_id)==set(ids),'Invalid seed assignment IDs')
        s=s.set_index('doc_id').loc[ids];labs[seed_id]=s.cluster.to_numpy()
        require(np.array_equal(s.frozen_topic.to_numpy(),d.topic.to_numpy()),'Frozen seed labels differ')
        dd=d.copy();dd['topic']=s.mapped_topic.to_numpy()
        row=dict(seed=seed_id,ARI_vs_frozen=adjusted_rand_score(d.topic,s.cluster))
        for g in GROUPS:row['VALUE_'+g]=group(dd,g).topic.isin(VALUE).mean()
        row['JSD_ZH_EN']=jsd(counts(group(dd,'ZH')),counts(group(dd,'EN')));row['S_ZH_EN']=separation(counts(group(dd,'ZH')),counts(group(dd,'EN')))
        seedmetrics.append(row)
    save('seed_metrics',seedmetrics)
    save('seed_pairwise_ari',[dict(seed_a=a,seed_b=b,ARI=adjusted_rand_score(labs[a],labs[b])) for a,b in itertools.combinations(sorted(labs),2)])
    trans=[]
    e1a=pd.read_csv(ROOT/'data/derived/E1A_Doc.csv')
    for classifier,s in e1a.groupby('classifier'):
        require(s.doc_id.is_unique and set(s.doc_id)==set(group(d,'ZH').doc_id),'Translation rows incomplete')
        for label in ['original_label','translated_label']:
            c=s[label].value_counts().reindex(TOPICS,fill_value=0).to_numpy()
            trans.append(dict(design='E1A',classifier=classifier,representation=label,JSD_ZH_EN=jsd(c,counts(e)),S_ZH_EN=separation(c,counts(e)),VALUE_ZH=s[label].isin(VALUE).mean()))
    e1b=pd.read_csv(ROOT/'data/derived/E1B_Assignments.csv')
    for seed_id,s in e1b.groupby('seed'):
        require(s.doc_id.is_unique and set(s.doc_id)==set(ids),'Paired translation assignments incomplete')
        dd=d.copy();dd['topic']=s.set_index('doc_id').loc[ids].mapped_topic.to_numpy()
        trans.append(dict(design='E1B',seed=seed_id,JSD_ZH_EN=jsd(counts(group(dd,'ZH')),counts(group(dd,'EN'))),S_ZH_EN=separation(counts(group(dd,'ZH')),counts(group(dd,'EN'))),VALUE_ZH=group(dd,'ZH').topic.isin(VALUE).mean()))
    save('translation_metrics',trans)
    meta=dict(mode='quick' if args.quick else 'full_statistics',bootstrap_reps=boots,permutation_reps=reps,stratified_permutation_reps=sreps,seed=seed,python=platform.python_version(),packages={p:version(p) for p in ['numpy','pandas','scipy','scikit-learn','statsmodels']},records_sha256=hashlib.sha256((ROOT/'data/derived/records.csv').read_bytes()).hexdigest(),scope='Recomputed from frozen labels and archived coding. Cached seed/translation assignments were analyzed, not refitted. Original abstracts and manual judgements were not revalidated.')
    (out/'run_metadata.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
    print(json.dumps(dict(status='completed',records=len(d),output=str(out),mode=meta['mode']),ensure_ascii=False))

if __name__=='__main__': main()
